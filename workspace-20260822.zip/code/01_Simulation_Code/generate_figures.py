
# Global Matplotlib styling for Times New Roman and Black text

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Global Matplotlib styling for Times New Roman and Black text
plt.rcParams['font.sans-serif'] = ['Times New Roman', 'Liberation Serif', 'DejaVu Sans']
plt.rcParams['font.serif'] = ['Times New Roman', 'Liberation Serif', 'DejaVu Serif']
plt.rcParams['font.family'] = 'serif'
plt.rcParams['text.color'] = 'black'
plt.rcParams['axes.labelcolor'] = 'black'
plt.rcParams['xtick.color'] = 'black'
plt.rcParams['ytick.color'] = 'black'
import matplotlib.patches as patches
from matplotlib.lines import Line2D
import numpy as np
import sqlite3, pandas as pd
import os
from matplotlib.ticker import FormatStrFormatter

import sim_main as S

FIG_DIR = '../02_Revised_Deliverables_Figures'
os.makedirs(FIG_DIR, exist_ok=True)

# Exact color codes extracted from original manuscript
C_NORMAL = '#75B956'     # Dark Green
C_WARNING = '#AED6F1'    # Light Yellow/Orange
C_ALERT = '#5392CE'      # Deep Orange
C_CRITICAL = '#B165A6'   # Dark Blue
C_FAILURE = '#C64C3E'    # Crimson Red

C_BG = '#F4F6F7'         # Off-white / light blue-grey background
C_TEXT = '#2C3E50'
C_SHADE = '#D0ECE7'      # Light teal fill for EWM improvement

# Global font & styling setup
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['axes.edgecolor'] = '#BDC3C7'
plt.rcParams['axes.linewidth'] = 0.8
plt.rcParams['grid.color'] = '#E5E8E8'
plt.rcParams['grid.linestyle'] = '--'

# Read database simulation data
con_no = sqlite3.connect('../04_Simulation_Results/no_ew.db')
con_ew = sqlite3.connect('../04_Simulation_Results/ew.db')

df_no = pd.read_sql('SELECT timestamp/3600 as time_h, RI, avg_pressure, delivered, required FROM performance_data', con_no)
df_ew = pd.read_sql('SELECT timestamp/3600 as time_h, RI, avg_pressure, delivered, required FROM performance_data', con_ew)

# ---------------------------------------------------------------------------
# Volumetric resilience index RI_v (Eq. 5 in the manuscript) for sensitivity
# figures: RI_v = V_delivered / V_ideal, where the ideal (uncurtailed nominal)
# demand volume depends on the scenario:
#   - threshold designs & tank scale  -> ideal over [24,48] h at Lambda = 1.0
#   - outage duration d               -> ideal over [24, 24+d] h
#   - relative load factor L          -> ideal(24 h) * L
# Trapezoidal integration of `required` from no_ew.db (scenario-independent,
# since nominal demand is never curtailed by EWM).
# ---------------------------------------------------------------------------
_req_t = df_no['time_h'].values * 3600.0
_req_q = df_no['required'].values

def ideal_volume(t0_h, t1_h):
    m = (_req_t >= t0_h * 3600.0) & (_req_t <= t1_h * 3600.0)
    return float(np.trapezoid(_req_q[m], _req_t[m]))

IDEAL_24H = ideal_volume(24.0, 48.0)

def enrich_riv(df, kind, keycol=None):
    if kind == 'plain':
        df = df.copy(); df['ideal'] = IDEAL_24H
    elif kind == 'faultdur':
        df = df.copy(); df['ideal'] = [ideal_volume(24.0, 24.0 + d / 3600.0) for d in df[keycol]]
    elif kind == 'loadfactor':
        df = df.copy(); df['ideal'] = IDEAL_24H * df[keycol].values
    df['RI_v_no'] = df['deliv_no'] / df['ideal']
    df['RI_v_ew'] = df['deliv_ew'] / df['ideal']
    return df

df_sensor_no = pd.read_sql("SELECT timestamp/3600 as time_h, sensor_id, value FROM sensor_data", con_no)
df_sensor_ew = pd.read_sql("SELECT timestamp/3600 as time_h, sensor_id, value FROM sensor_data", con_ew)

con_no.close()
con_ew.close()

# Extract time series for T1 and T2
df_t1_no = df_sensor_no[df_sensor_no['sensor_id']=='T1']
df_t1_ew = df_sensor_ew[df_sensor_ew['sensor_id']=='T1']
df_t2_no = df_sensor_no[df_sensor_no['sensor_id']=='T2']
df_t2_ew = df_sensor_ew[df_sensor_ew['sensor_id']=='T2']

# ============================================================================
# FIG 1: Network Topology
# ============================================================================

node_coords = {
    'R': (9.2, 1.2), 'P1': (8.2, 2.0), 'P2': (8.2, 1.2), 'J20': (8.2, 1.2),
    'J1': (6.8, 1.2), 'J2': (7.8, 3.2), 'J3': (7.5, 5.0), 'J4': (6.2, 5.2),
    'J5': (5.0, 6.2), 'J6': (3.6, 5.8), 'J7': (2.8, 5.5), 'J8': (2.8, 4.2),
    'J9': (0.5, 2.8), 'J10': (1.5, 1.2), 'J11': (3.0, 0.5), 'J12': (4.8, 1.2),
    'J13': (6.5, 2.2), 'J14': (6.5, 3.5), 'J15': (5.2, 4.2), 'J16': (3.8, 3.2),
    'J17': (2.2, 2.2), 'J18': (4.2, 2.2), 'J19': (5.2, 2.8), 'J21': (6.2, 4.2),
    'J22': (2.2, 1.5), 'T1': (6.2, 4.7), 'T2': (1.8, 3.2)
}

edges = [
    ('R', 'J20'), ('J20', 'J1'), ('J1', 'J2'), ('J1', 'J12'), ('J1', 'J13'),
    ('J2', 'J3'), ('J2', 'J13'), ('J2', 'J14'), ('J3', 'J4'), ('J4', 'J5'),
    ('J4', 'J8'), ('J4', 'J15'), ('J4', 'T1'), ('T1', 'J21'), ('J21', 'J14'),
    ('J5', 'J6'), ('J6', 'J7'), ('J6', 'J8'), ('J7', 'J8'), ('J8', 'J9'),
    ('J8', 'J15'), ('J8', 'J16'), ('J8', 'J17'), ('J9', 'J10'), ('J10', 'J11'),
    ('J10', 'J17'), ('J11', 'J12'), ('J12', 'J18'), ('J13', 'J14'), ('J13', 'J19'),
    ('J14', 'J15'), ('J14', 'J19'), ('J15', 'J16'), ('J15', 'J19'), ('J16', 'J17'),
    ('J16', 'J18'), ('J17', 'J18'), ('J17', 'J22'), ('J17', 'T2'), ('T2', 'J22'),
    ('J18', 'J19')
]

fig, ax = plt.subplots(figsize=(9, 6), facecolor='#FFFFFF')
ax.set_facecolor('#FFFFFF')

for u, v in edges:
    if u in node_coords and v in node_coords:
        x1, y1 = node_coords[u]
        x2, y2 = node_coords[v]
        ax.plot([x1, x2], [y1, y2], color='#888888', lw=1.2, zorder=1)

for name, (x, y) in node_coords.items():
    if name.startswith('J'):
        ax.scatter(x, y, color='#2F5597', s=70, zorder=3)
        ax.text(x - 0.15, y - 0.25, name, fontsize=8, fontweight='bold', color='#1B365D')

rx, ry = node_coords['R']
ax.scatter(rx, ry, color='#C65911', marker='s', s=100, zorder=4)
ax.text(rx + 0.15, ry, 'R', fontsize=9, fontweight='bold', color='#C65911')

for tank in ['T1', 'T2']:
    tx, ty = node_coords[tank]
    ax.scatter(tx, ty, color='#385723', marker='D', s=100, zorder=4)
    ax.text(tx + 0.2, ty, tank, fontsize=9, fontweight='bold', color='#385723')

px, py = node_coords['P1']
ax.scatter(px, py, color='#555555', marker='o', s=80, facecolors='none', edgecolors='#333333', lw=1.5, zorder=4)
ax.text(px, py + 0.25, 'P1', fontsize=8.5, fontweight='bold', color='#333333')

px2, py2 = node_coords['P2']
ax.scatter(px2, py2, color='#555555', marker='o', s=80, facecolors='none', edgecolors='#333333', lw=1.5, zorder=4)
ax.text(px2, py2 - 0.35, 'P2', fontsize=8.5, fontweight='bold', color='#333333')

legend_elements = [
    Line2D([0], [0], marker='o', color='w', label='Demand Nodes', markerfacecolor='#2F5597', markersize=8),
    Line2D([0], [0], marker='s', color='w', label='Reservoir', markerfacecolor='#C65911', markersize=9),
    Line2D([0], [0], marker='D', color='w', label='Tanks', markerfacecolor='#385723', markersize=9),
    Line2D([0], [0], marker='o', color='w', label='Pumps', markerfacecolor='none', markeredgecolor='#333333', markeredgewidth=1.5, markersize=8)
]
ax.legend(handles=legend_elements, loc='upper right', frameon=True, facecolor='#FFFFFF', edgecolor='#BDC3C7', fontsize=8.5)

ax.set_xlim(-0.2, 10.2)
ax.set_ylim(-0.2, 6.8)
ax.axis('off')
plt.tight_layout()

plt.savefig(os.path.join(FIG_DIR, 'Fig1.png'), dpi=300, bbox_inches='tight')
plt.close()


# ============================================================================
# FIG 2: Cyber-Physical Coupling Framework
# ============================================================================
fig, ax = plt.subplots(figsize=(9, 7.2), facecolor=C_BG)
ax.set_facecolor(C_BG)
ax.set_xlim(0, 10)
ax.set_ylim(0, 9.5)
ax.axis('off')

# Cyber Layer
box_cyber_bg = patches.FancyBboxPatch((0.5, 6.4), 9.0, 2.7, boxstyle="round,pad=0.1", fc='#D9E1F2', ec='#8FAADC', lw=1.5, ls='--')
ax.add_patch(box_cyber_bg)
ax.text(5.0, 8.8, 'Cyber Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='#1B365D')

box_scada = patches.FancyBboxPatch((1.2, 6.7), 3.4, 1.8, boxstyle="round,pad=0.1", fc='#2F5597', ec='#1B365D', lw=1.5)
ax.add_patch(box_scada)
ax.text(2.9, 8.1, 'SCADA Server', ha='center', va='center', fontsize=10, fontweight='bold', color='#FFFFFF')
ax.text(2.9, 7.3, '• Risk Classification\n• Graded Early Warning\n• Fast Cyber Sensing (300 s)', ha='left', va='center', fontsize=8.5, color='#FFFFFF')

box_plc = patches.FancyBboxPatch((5.4, 6.7), 3.4, 1.8, boxstyle="round,pad=0.1", fc='#2F5597', ec='#1B365D', lw=1.5)
ax.add_patch(box_plc)
ax.text(7.1, 8.1, 'PLC Network', ha='center', va='center', fontsize=10, fontweight='bold', color='#FFFFFF')
ax.text(7.1, 7.3, '• Tank PLCs\n• Pump PLCs\n• Junction PLCs', ha='left', va='center', fontsize=8.5, color='#FFFFFF')

ax.annotate('', xy=(5.4, 7.7), xytext=(4.6, 7.7), arrowprops=dict(arrowstyle='->', lw=1.2, color='#FFFFFF'))
ax.annotate('', xy=(4.6, 7.1), xytext=(5.4, 7.1), arrowprops=dict(arrowstyle='->', lw=1.2, color='#FFFFFF'))

# Coupling Layer
box_coup_bg = patches.FancyBboxPatch((0.5, 3.4), 9.0, 2.5, boxstyle="round,pad=0.1", fc='#E2EFDA', ec='#A9D18E', lw=1.5, ls='--')
ax.add_patch(box_coup_bg)
ax.text(5.0, 5.5, 'Coupling Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='#274E13')

box_m1 = patches.FancyBboxPatch((1.0, 3.7), 3.8, 1.5, boxstyle="round,pad=0.1", fc='#FFFFFF', ec='#385723', lw=1.2)
ax.add_patch(box_m1)
ax.text(2.9, 4.45, '• State Mapping (H, P → Risk Levels)\n• Temporal Buffer Generation\n• Warning / Alert / Critical Buffer Zones', ha='left', va='center', fontsize=8.0, color='#274E13')

box_m2 = patches.FancyBboxPatch((5.2, 3.7), 3.8, 1.5, boxstyle="round,pad=0.1", fc='#FFFFFF', ec='#385723', lw=1.2)
ax.add_patch(box_m2)
ax.text(7.1, 4.45, '• Graceful Degradation Mechanism\n• Closed-loop Feedback Control\n• Ratchet Anti-chatter Logic', ha='left', va='center', fontsize=8.0, color='#274E13')

# Physical Layer
box_phys_bg = patches.FancyBboxPatch((0.5, 0.3), 9.0, 2.5, boxstyle="round,pad=0.1", fc='#FCE4D6', ec='#F4B183', lw=1.5, ls='--')
ax.add_patch(box_phys_bg)
ax.text(5.0, 2.4, 'Physical Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='#833C0C')

box_p1 = patches.FancyBboxPatch((1.0, 0.6), 3.8, 1.2, boxstyle="round,pad=0.1", fc='#C65911', ec='#833C0C', lw=1.2)
ax.add_patch(box_p1)
ax.text(2.9, 1.4, 'Hydraulic Degradation Process', ha='center', va='center', fontsize=9, fontweight='bold', color='#FFFFFF')
ax.text(2.9, 0.9, '• Tank Level (H) ↓ → Pressure (P) ↓', ha='center', va='center', fontsize=8.0, color='#FFFFFF')

box_p2 = patches.FancyBboxPatch((5.2, 0.6), 3.8, 1.2, boxstyle="round,pad=0.1", fc='#C65911', ec='#833C0C', lw=1.2)
ax.add_patch(box_p2)
ax.text(7.1, 1.4, 'Physical Buffer', ha='center', va='center', fontsize=9, fontweight='bold', color='#FFFFFF')
ax.text(7.1, 0.9, '• Tank Storage  • Pipeline Residual Water', ha='center', va='center', fontsize=8.0, color='#FFFFFF')

ax.annotate('Sensing Dependency', xy=(5.0, 6.4), xytext=(5.0, 5.9), ha='center', va='center', fontsize=8.5, fontweight='bold', color='#1B365D', arrowprops=dict(arrowstyle='<->', lw=1.5, color='#2F5597'))
ax.annotate('Warning Dependency', xy=(5.0, 3.4), xytext=(5.0, 2.8), ha='center', va='center', fontsize=8.5, fontweight='bold', color='#833C0C', arrowprops=dict(arrowstyle='<->', lw=1.5, color='#C65911'))

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig2.png'), dpi=300, bbox_inches='tight')
plt.close()


# ============================================================================
# FIG 3: Co-Simulation Platform Architecture
# ============================================================================
fig, ax = plt.subplots(figsize=(8.5, 7.2), facecolor=C_BG)
ax.set_facecolor(C_BG)
ax.set_xlim(0, 10)
ax.set_ylim(0, 9.5)
ax.axis('off')

box_top_hdr = patches.Rectangle((0.5, 8.5), 9.0, 0.7, fc='#2F5597', ec='#1B365D', lw=1.2)
box_top_body = patches.Rectangle((0.5, 6.5), 9.0, 2.0, fc='#B4C6E7', ec='#1B365D', lw=1.2)
ax.add_patch(box_top_body)
ax.add_patch(box_top_hdr)
ax.text(5.0, 8.85, 'Cyber SCADA Module (Decision Layer)', ha='center', va='center', fontsize=11, fontweight='bold', color='#FFFFFF')
ax.text(1.0, 7.5, '• Real-time State Acquisition (H, P)\n• Pressure Trend Monitoring (300 s)\n• Status Transition Detection\n• Temporal Buffer Calculation', ha='left', va='center', fontsize=8.5, color='#1B365D')
ax.text(5.5, 7.5, '• Graded Risk Classification\n  - Normal\n  - Warning\n  - Alert\n  - Critical\n  - Outlet Failure', ha='left', va='center', fontsize=8.5, color='#1B365D')

box_mid_hdr = patches.Rectangle((0.5, 5.4), 9.0, 0.6, fc='#385723', ec='#274E13', lw=1.2)
box_mid_body = patches.Rectangle((0.5, 3.5), 9.0, 1.9, fc='#A9D18E', ec='#274E13', lw=1.2)
ax.add_patch(box_mid_body)
ax.add_patch(box_mid_hdr)
ax.text(5.0, 5.7, 'Synchronization Database Layer (SQLite)', ha='center', va='center', fontsize=11, fontweight='bold', color='#FFFFFF')

box_db1 = patches.Rectangle((0.8, 3.7), 2.5, 1.5, fc='#C6E0B4', ec='#385723', lw=1)
ax.add_patch(box_db1)
ax.text(2.05, 4.45, '• Physical State Table\n  - Tank Levels (H)\n  - Nodal Pressures (P)\n  - Flow Rates (Q)', ha='center', va='center', fontsize=7.5, color='#274E13')

box_db2 = patches.Rectangle((3.6, 3.7), 2.8, 1.5, fc='#C6E0B4', ec='#385723', lw=1)
ax.add_patch(box_db2)
ax.text(5.0, 4.45, '• Event & Transition Log\n  - Risk Level Changes\n  - Timestamp Records\n  - Duration of Each State', ha='center', va='center', fontsize=7.5, color='#274E13')

box_db3 = patches.Rectangle((6.7, 3.7), 2.5, 1.5, fc='#C6E0B4', ec='#385723', lw=1)
ax.add_patch(box_db3)
ax.text(7.95, 4.45, 'Temporal Buffer & Metrics\nDual Resilience Metrics\n(RI_p, RI_v, V_delivered)', ha='center', va='center', fontsize=7.5, color='#274E13')

box_bot_hdr = patches.Rectangle((0.5, 2.4), 9.0, 0.6, fc='#C65911', ec='#833C0C', lw=1.2)
box_bot_body = patches.Rectangle((0.5, 0.3), 9.0, 2.1, fc='#F8CBAD', ec='#833C0C', lw=1.2)
ax.add_patch(box_bot_body)
ax.add_patch(box_bot_hdr)
ax.text(5.0, 2.7, 'Physical Simulation Module', ha='center', va='center', fontsize=11, fontweight='bold', color='#FFFFFF')

box_wntr = patches.Rectangle((0.8, 0.5), 2.2, 1.7, fc='#F2F2F2', ec='#833C0C', lw=1)
ax.add_patch(box_wntr)
ax.text(1.9, 1.6, 'WNTR / EPANET 2.2\n(300 s timestep)', ha='center', va='center', fontsize=8, fontweight='bold', color='#833C0C')
ax.annotate('', xy=(1.9, 0.8), xytext=(1.9, 1.3), arrowprops=dict(arrowstyle='->', lw=1.5, color='#C65911'))
ax.text(1.9, 0.65, 'PDA Hydraulics', ha='center', va='center', fontsize=7.5, color='#833C0C')

ax.text(4.5, 1.3, '• Governing Equations\n• Source Interruption Scenario (24-48 h)\n• Hydraulic Degradation Process', ha='left', va='center', fontsize=8, color='#833C0C')
ax.text(7.5, 1.3, '• Outputs\n  - Tank Water Levels (H)\n  - Nodal Pressures (P)\n  - Flow Rates (Q)', ha='left', va='center', fontsize=8, color='#833C0C')

ax.annotate('', xy=(3.0, 6.1), xytext=(3.0, 6.5), arrowprops=dict(arrowstyle='->', lw=2, color='#385723'))
ax.annotate('', xy=(7.0, 6.5), xytext=(7.0, 6.1), arrowprops=dict(arrowstyle='->', lw=2, color='#2F5597'))
ax.annotate('', xy=(3.0, 3.0), xytext=(3.0, 3.5), arrowprops=dict(arrowstyle='->', lw=2, color='#C65911'))
ax.annotate('', xy=(7.0, 3.5), xytext=(7.0, 3.0), arrowprops=dict(arrowstyle='->', lw=2, color='#385723'))

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig3.png'), dpi=300, bbox_inches='tight')
plt.close()


# ============================================================================


# FIG 4: Tank Risk State Evolution (equally spaced 1.5m intervals, clean ticks and legends)
# ============================================================================
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 7.8), facecolor=C_BG, gridspec_kw={'height_ratios': [1.1, 1]})
ax1.set_facecolor(C_BG)
ax2.set_facecolor(C_BG)

t_hrs = df_t1_no['time_h'].values

def classify_state(h):
    if h >= 5.0: return 'Normal'
    if h >= 3.5: return 'WARNING'
    if h >= 2.0: return 'ALERT'
    if h >= 0.5: return 'CRITICAL'
    return 'Outlet Failure'

state_colors = {
    'Normal': '#75B956',         # Soft Green
    'WARNING': '#AED6F1',        # Soft Light Blue
    'ALERT': '#5392CE',          # Steel Blue
    'CRITICAL': '#B165A6',       # Amethyst Purple
    'Outlet Failure': '#C64C3E'  # Muted Red
}

t1_no_vals = df_t1_no['value'].values
t1_ew_vals = df_t1_ew['value'].values
t2_no_vals = df_t2_no['value'].values
t2_ew_vals = df_t2_ew['value'].values

y_positions = [4, 3, 2, 1]
y_labels = ['T2 - With EWM', 'T2 - Without EWM', 'T1 - With EWM', 'T1 - Without EWM']
series_data = [t2_ew_vals, t2_no_vals, t1_ew_vals, t1_no_vals]

for idx, (y_pos, vals) in enumerate(zip(y_positions, series_data)):
    for i in range(len(t_hrs)-1):
        st = classify_state(vals[i])
        c = state_colors[st]
        ax1.barh(y_pos, width=t_hrs[i+1]-t_hrs[i], left=t_hrs[i], height=0.55, color=c, edgecolor='none')

ax1.set_yticks(y_positions)
ax1.set_yticklabels(y_labels, fontsize=8.5, fontweight='bold', color='black')
ax1.set_xlim(0, 72)
ax1.set_ylim(0.2, 6.4)
ax1.set_xlabel('Time (h)', fontsize=9, fontweight='bold', color='black')
ax1.text(-0.06, 1.05, '(a)', transform=ax1.transAxes, fontsize=11, fontweight='bold', color='black')

# Adjusted vertical line transparency (alpha=0.35) to prevent blocking main bars!
ax1.axvline(24, color='#2F5597', linestyle='-', lw=1.2, alpha=0.35)
ax1.axvline(48, color='#2F5597', linestyle='-', lw=1.2, alpha=0.35)
ax1.text(24, 0.45, 'Start (24h)', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#1F3A5F')
ax1.text(48, 0.45, 'End (48h)', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#1F3A5F')

legend_patches = [
    patches.Patch(color=state_colors['Normal'], label='Normal (≥ 5.0 m)'),
    patches.Patch(color=state_colors['WARNING'], label='WARNING (3.5–5.0 m)'),
    patches.Patch(color=state_colors['ALERT'], label='ALERT (2.0–3.5 m)'),
    patches.Patch(color=state_colors['CRITICAL'], label='CRITICAL (0.5–2.0 m)'),
    patches.Patch(color=state_colors['Outlet Failure'], label='Outlet Failure (< 0.5 m)')
]
ax1.legend(handles=legend_patches, loc='upper left', ncol=1, fontsize=8, framealpha=0.95, edgecolor='#BDC3C7')


# Subplot (b): Stacked Bar Chart for State Durations
# 直接从数据库按 24-48 h 故障窗口(左闭右开)与 5.0/3.5/2.0/0.5 m 阈值统计,
# 与正文 Table 4 完全一致, 避免硬编码导致图、表脱节。
states_keys = ['Normal', 'WARNING', 'ALERT', 'CRITICAL', 'Outlet Failure']

def compute_durations(df_series):
    seg = df_series[(df_series['time_h'] >= 24.0) & (df_series['time_h'] < 48.0)]
    dur = {k: 0.0 for k in states_keys}
    for v in seg['value']:
        dur[classify_state(v)] += 300 / 3600.0
    return [dur[k] for k in states_keys]

durations_data = {
    'T1 Without EWM': compute_durations(df_t1_no),
    'T1 With EWM':    compute_durations(df_t1_ew),
    'T2 Without EWM': compute_durations(df_t2_no),
    'T2 With EWM':    compute_durations(df_t2_ew),
}

x_cats = ['T1\nWithout EWM', 'T1\nWith EWM', 'T2\nWithout EWM', 'T2\nWith EWM']

bottoms = np.zeros(4)
bar_width = 0.45
x_pos = [1, 2, 3.2, 4.2]

for state_idx, st in enumerate(states_keys):
    vals = [durations_data[k][state_idx] for k in ['T1 Without EWM', 'T1 With EWM', 'T2 Without EWM', 'T2 With EWM']]
    c = state_colors[st]
    bars = ax2.bar(x_pos, vals, bottom=bottoms, width=bar_width, color=c, edgecolor='white', lw=0.5, label=st)
    
    for b_idx, (p, v, b) in enumerate(zip(x_pos, vals, bottoms)):
        if v >= 0.5:
            ax2.text(p, b + v/2.0, f'{v:.2f}h', ha='center', va='center', fontsize=7.5, color='white' if st in ['Normal', 'ALERT', 'CRITICAL', 'Outlet Failure'] else 'black', fontweight='bold')
    
    bottoms += np.array(vals)

ax2.set_xticks(x_pos)
ax2.set_xticklabels(x_cats, fontsize=8.5, fontweight='bold', color='black')
ax2.set_ylabel('Duration (h)', fontsize=9, fontweight='bold', color='black')
ax2.text(-0.06, 1.05, '(b)', transform=ax2.transAxes, fontsize=11, fontweight='bold', color='black')
ax2.set_ylim(0, 32)

ax2.legend(loc='upper right', ncol=2, fontsize=8, framealpha=0.95, edgecolor='#BDC3C7')
ax2.axhline(24.0, color='#888888', linestyle=':', lw=1)

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig4.png'), dpi=300, bbox_inches='tight')
plt.close()

# ============================================================================
# FIG 5: Network average pressure dynamics over the 72 h horizon (MPa)
# ============================================================================
M_TO_MPA = 0.00980665  # 1 m H2O = 0.00980665 MPa

fig, ax = plt.subplots(figsize=(9, 4.8), facecolor='#FFFFFF')
ax.set_facecolor('#FFFFFF')
ax.plot(df_no['time_h'], df_no['avg_pressure'] * M_TO_MPA, '-', color='#C64C3E', lw=2, label='Without EWM')
ax.plot(df_ew['time_h'], df_ew['avg_pressure'] * M_TO_MPA, '-', color='#2E86C1', lw=2, label='With EWM')
ax.axhline(0.10, color='#2F5597', linestyle='--', lw=1.4, label='Critical Pressure (0.10 MPa)')
ax.axvspan(24, 48, color='#D0ECE7', alpha=0.5, label='Water-source outage (24-48 h)')
ax.set_xlabel('Time (h)', fontsize=10, fontweight='bold', color='black')
ax.set_ylabel('Network Average Pressure (MPa)', fontsize=10, fontweight='bold', color='black')
ax.set_xlim(0, 72)
ax.set_ylim(0, None)
ax.grid(True, color='#E5E8E8', linestyle='--')
ax.legend(loc='upper right', fontsize=9, framealpha=0.95, edgecolor='#BDC3C7')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig5.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig5.png generated')

# FIG 6: Dual Metric Bar Chart & Volumetric Accounting (values read from DB)
# ============================================================================
DB_NO = '../04_Simulation_Results/no_ew.db'
DB_EW = '../04_Simulation_Results/ew.db'
T0, T1 = 24 * 3600, 48 * 3600

ri_p_no = S.calc_RI(DB_NO, T0, T1)
ri_p_ew = S.calc_RI(DB_EW, T0, T1)
_, req_no, del_no = S.unmet_demand_volume(DB_NO, T0, T1)
_, req_ew, del_ew = S.unmet_demand_volume(DB_EW, T0, T1)
ri_v_no = del_no / req_no
ri_v_ew = del_ew / req_ew
v_deliv = [del_no, del_ew]
v_unmet = [req_no - del_no, req_ew - del_ew]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.8), facecolor=C_BG)
ax1.set_facecolor(C_BG)
ax2.set_facecolor(C_BG)

# (a) RI_p and RI_v
ax1.bar(0.8, ri_p_no, width=0.35, color='#D4EFDF', edgecolor='none')
ax1.bar(2.0, ri_p_ew, width=0.35, color='#75B956', edgecolor='none', label='Pressure Resilience ($RI_p$)')
ax1.bar(1.2, ri_v_no, width=0.35, color='#D6EAF8', edgecolor='none')
ax1.bar(2.4, ri_v_ew, width=0.35, color='#5392CE', edgecolor='none', label='Volumetric Resilience ($RI_v$)')
ax1.axhline(1.0, color='#2F5597', linestyle=':', lw=1.2, label='Ideal RI = 1.0')

ax1.text(0.8, ri_p_no + 0.02, f'{ri_p_no:.2f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#75B956')
ax1.text(1.2, ri_v_no + 0.02, f'{ri_v_no:.2f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#5392CE')
ax1.text(2.0, ri_p_ew + 0.02, f'{ri_p_ew:.2f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#75B956')
ax1.text(2.4, ri_v_ew + 0.02, f'{ri_v_ew:.2f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#5392CE')

ax1.set_xticks([1.0, 2.2])
ax1.set_xticklabels(['Without EWM', 'With EWM'], fontsize=9.5, fontweight='bold', color='black')
ax1.set_ylabel('Resilience Index', fontsize=9.5, fontweight='bold', color='black')
ax1.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
ax1.text(-0.08, 1.04, '(a)', transform=ax1.transAxes, fontsize=11, fontweight='bold', color='black')
ax1.set_ylim(0, 1.25)
ax1.legend(loc='upper left', fontsize=8, framealpha=0.95, edgecolor='#BDC3C7')

# (b) Volumetric accounting
x_vol = np.array([1, 2.2])
w = 0.35
ax2.bar(x_vol[0] - w/2, v_deliv[0], width=w, color='#E8DAEF', edgecolor='none')
ax2.bar(x_vol[1] - w/2, v_deliv[1], width=w, color='#B165A6', edgecolor='none', label='Delivered Water')
ax2.bar(x_vol[0] + w/2, v_unmet[0], width=w, color='#C64C3E', edgecolor='none')
ax2.bar(x_vol[1] + w/2, v_unmet[1], width=w, color='#FADBD8', edgecolor='none', label='Unmet Demand')

ax2.text(x_vol[0] - w/2, v_deliv[0] + 100, f'{v_deliv[0]:,.1f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#B165A6')
ax2.text(x_vol[1] - w/2, v_deliv[1] + 100, f'{v_deliv[1]:,.1f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#B165A6')
ax2.text(x_vol[0] + w/2, v_unmet[0] + 100, f'{v_unmet[0]:,.1f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#C64C3E')
ax2.text(x_vol[1] + w/2, v_unmet[1] + 100, f'{v_unmet[1]:,.1f}', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#C64C3E')

ax2.set_xticks(x_vol)
ax2.set_xticklabels(['Without EWM', 'With EWM'], fontsize=9.5, fontweight='bold', color='black')
ax2.set_ylabel('Volume (m3)', fontsize=9.5, fontweight='bold', color='black')
ax2.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
ax2.text(-0.08, 1.04, '(b)', transform=ax2.transAxes, fontsize=11, fontweight='bold', color='black')
ax2.set_ylim(0, 9500)
ax2.legend(loc='upper right', fontsize=8, framealpha=0.95, edgecolor='#BDC3C7')

plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig6.png'), dpi=300, bbox_inches='tight')
plt.close()

# FIG 7 & FIG 8: 相位平均 + 加密取点后的敏感性 (出口隔离修复后, 诚实指标)
# ============================================================================
import os as _os
PA_DIR = '../04_Simulation_Results/phase_avg'

def _read(name):
    return pd.read_csv(_os.path.join(PA_DIR, name))

def _err(df, col):
    lo = df[col + '_lo'].values
    hi = df[col + '_hi'].values
    v = df[col].values
    return [v - lo, hi - v]  # 上下误差条

_ready = all(_os.path.exists(_os.path.join(PA_DIR, f)) for f in
             ['threshold.csv', 'diameter.csv', 'duration.csv', 'load.csv'])

if _ready:
    thr = _read('threshold.csv')
    dia = _read('diameter.csv')
    dur = _read('duration.csv')
    lod = _read('load.csv')

    dia['x'] = dia['key'].astype(float)
    dur['x'] = dur['key'].astype(float)
    lod['x'] = lod['key'].astype(float)

    # ---------------- FIG 7: 时间缓冲(出口隔离延迟 dT_iso) ----------------
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 8.5), facecolor='#FFFFFF')
    for a in (ax1, ax2, ax3, ax4):
        a.set_facecolor('#FFFFFF'); a.grid(True, color='#E5E8E8', linestyle='--')

    # (a) 阈值设计
    ax1.errorbar(range(5), thr['dT_iso'], yerr=_err(thr, 'dT_iso'), fmt='o-', color='#2E86C1',
                 lw=2.2, ms=7, capsize=4, label='Isolation delay')
    ax1.axhline(0, color='#C64C3E', linestyle='--', lw=1.2)
    ax1.set_xticks(range(5)); ax1.set_xticklabels(['D1','D2','D3','D4','D5'])
    ax1.set_xlabel('Threshold design', fontsize=10, fontweight='bold')
    ax1.set_ylabel('Outlet-isolation delay (h)', fontsize=10, fontweight='bold')
    ax1.set_title('(a) Threshold design', fontsize=11, fontweight='bold')

    # (b) 水箱直径
    ax2.errorbar(dia['x'], dia['dT_iso'], yerr=_err(dia, 'dT_iso'), fmt='s-', color='#75B956',
                 lw=2.2, ms=7, capsize=4)
    ax2.axhline(0, color='#C64C3E', linestyle='--', lw=1.2)
    ax2.set_xlabel('Tank diameter scale', fontsize=10, fontweight='bold')
    ax2.set_ylabel('Outlet-isolation delay (h)', fontsize=10, fontweight='bold')
    ax2.set_title('(b) Tank storage scale', fontsize=11, fontweight='bold')

    # (c) 断水时长
    ax3.errorbar(dur['x'], dur['dT_iso'], yerr=_err(dur, 'dT_iso'), fmt='^-', color='#B165A6',
                 lw=2.2, ms=7, capsize=4)
    ax3.axhline(0, color='#C64C3E', linestyle='--', lw=1.2)
    ax3.set_xlabel('Outage duration (h)', fontsize=10, fontweight='bold')
    ax3.set_ylabel('Outlet-isolation delay (h)', fontsize=10, fontweight='bold')
    ax3.set_title('(c) Outage duration', fontsize=11, fontweight='bold')

    # (d) 相对负载
    ax4.errorbar(lod['x'], lod['dT_iso'], yerr=_err(lod, 'dT_iso'), fmt='d-', color='#C64C3E',
                 lw=2.2, ms=7, capsize=4)
    ax4.axhline(0, color='#C64C3E', linestyle='--', lw=1.2)
    ax4.set_xlabel('Relative demand load factor', fontsize=10, fontweight='bold')
    ax4.set_ylabel('Outlet-isolation delay (h)', fontsize=10, fontweight='bold')
    ax4.set_title('(d) Relative demand load', fontsize=11, fontweight='bold')

    plt.tight_layout()
    plt.savefig(_os.path.join(FIG_DIR, 'Fig7.png'), dpi=300, bbox_inches='tight')
    plt.close()
    print('Fig7.png generated (phase-averaged, isolation delay)')

    # ---------------- FIG 8: 压力韧性 RIp (无/有 EWM) ----------------
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 8.5), facecolor='#FFFFFF')
    for a in (ax1, ax2, ax3, ax4):
        a.set_facecolor('#FFFFFF'); a.grid(True, color='#E5E8E8', linestyle='--')

    def _panel(ax, x, df, xticks=None, xlabels=None, title='', legend=True):
        ax.errorbar(x, df['ri_p_no'], yerr=_err(df, 'ri_p_no'), fmt='o--', color='#C64C3E',
                    lw=2, ms=6, capsize=4, label='Without EWM')
        ax.errorbar(x, df['ri_p_ew'], yerr=_err(df, 'ri_p_ew'), fmt='s-', color='#2E86C1',
                    lw=2, ms=6, capsize=4, label='With EWM')
        if xticks is not None:
            ax.set_xticks(xticks); ax.set_xticklabels(xlabels)
        ax.set_xlabel(ax.get_xlabel() or '', fontsize=10, fontweight='bold')
        ax.set_ylabel('Pressure resilience RI$_p$', fontsize=10, fontweight='bold')
        ax.set_ylim(-0.05, 1.05)
        ax.set_title(title, fontsize=11, fontweight='bold')
        if legend:
            ax.legend(loc='best', fontsize=8, framealpha=0.95)

    _panel(ax1, range(5), thr, xticks=range(5), xlabels=['D1','D2','D3','D4','D5'], title='(a) Threshold design')
    _panel(ax2, dia['x'], dia, title='(b) Tank storage scale', legend=False)
    _panel(ax3, dur['x'], dur, title='(c) Outage duration', legend=False)
    _panel(ax4, lod['x'], lod, title='(d) Relative demand load', legend=False)
    ax2.set_xlabel('Tank diameter scale', fontsize=10, fontweight='bold')
    ax3.set_xlabel('Outage duration (h)', fontsize=10, fontweight='bold')
    ax4.set_xlabel('Relative demand load factor', fontsize=10, fontweight='bold')

    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'Fig8.png'), dpi=300, bbox_inches='tight')
    plt.close()
    print('Fig8.png generated (phase-averaged, RIp)')

    # 供水量增益摘要(诚实呈现: 基本≈0, 轻载/短时出现过切)
    print('\n--- 相位平均供水量增益 (%) 摘要 ---')
    for name, df in [('threshold', thr), ('diameter', dia), ('duration', dur), ('load', lod)]:
        print(f"  {name}: " + ", ".join(f"{k}={g:+.1f}" for k, g in zip(df['key'], df['gain'])))
else:
    print('phase_avg CSVs 尚未生成, 跳过 Fig 7/8 (先运行 sensitivity_analysis_v2.py)')
