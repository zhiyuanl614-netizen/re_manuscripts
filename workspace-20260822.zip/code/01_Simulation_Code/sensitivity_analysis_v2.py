"""敏感性分析 v2：加密取点 + 4 相位平均 + 出口隔离修复后。

指标(全部在故障窗口 [t0,t1] 内计算):
  RIp      : 压力韧性(代码口径 Pavg/P0, 与正文式(2)取 Pmin=0 一致)
  RIv      : 体积韧性 = Vdel / Videal
  delivered: 累计供水量(m3)
  gain_pct : 供水量增益 (%)
  dT_iso   : 出口隔离延迟 = outlet_time_ew - outlet_time_no (h)
  T_above  : 平均压力 >= 0.10 MPa 的时长 (h)

相位: 断水起始时刻在 24h 基础上平移 phase∈{0,6,12,18}h, 消除 8×3h 需求块对齐伪影。
输出: 各维度相位平均后的 CSV(含 min/max 范围), 供重绘 Fig.7/8。
"""
import os, sqlite3, sys, time
import numpy as np
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '01_Simulation_Code'))
import sim_main as S

INP = os.path.join(os.path.dirname(__file__), '03_Data_Files', 'anytown.inp')
OUT = os.path.join(os.path.dirname(__file__), '04_Simulation_Results', 'phase_avg')
os.makedirs(OUT, exist_ok=True)
TMP = '/tmp/v2'
os.makedirs(TMP, exist_ok=True)
M_TO_MPA = 0.00980665
PHASES = [0, 6, 12, 18]
FAULT_BASE = 24.0

# 阈值设计(与 sensitivity_analysis.py 一致)
DESIGNS = {
    'D1': [('CRITICAL', 1.0, 0.20, 3), ('ALERT', 3.0, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
    'D2': [('CRITICAL', 1.5, 0.20, 3), ('ALERT', 3.25, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
    'D3': [('CRITICAL', 2.0, 0.20, 3), ('ALERT', 3.5, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
    'D4': [('CRITICAL', 2.5, 0.20, 3), ('ALERT', 3.75, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
    'D5': [('CRITICAL', 3.0, 0.20, 3), ('ALERT', 4.0, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
}


def run_config(mode, fault_start_h, fault_duration_h, diameter_scale=1.0,
               threshold_levels=None, intensity_lambda=1.0, tag='x'):
    db = os.path.join(TMP, f'{tag}_{mode}.db')
    if os.path.exists(db):
        os.remove(db)
    fs = int(fault_start_h * 3600)
    fd = int(fault_duration_h * 3600)
    fault = S.WaterSourceInterruption(fs, fd)
    cls = S.NoEWSim if mode == 'no_ew' else S.EWSim
    sim = cls(INP, db, 300, fault_scenario=fault, intensity_lambda=intensity_lambda)
    if abs(diameter_scale - 1.0) > 1e-9:
        for t in sim.tanks:
            sim.wn.get_node(t).diameter *= diameter_scale
    if mode == 'ew' and threshold_levels is not None:
        sim.ews.LEVELS = threshold_levels
        sim.ews.THRESHOLD_MAP = {lv: thr for lv, thr, _, _ in threshold_levels}
        sim.ews.REDUCTION_MAP = {lv: rd for lv, _, rd, _ in threshold_levels}
        sim.ews.REDUCTION_MAP['NORMAL'] = 1.0
    sim.run(fs + fd + 3600)  # 故障 + 1h 恢复
    sim.close()
    t0, t1 = fs, fs + fd
    ri_p = S.calc_RI(db, t0, t1)
    unmet, req, delv = S.unmet_demand_volume(db, t0, t1)
    riv = delv / req if req and req > 0 else None
    conn = sqlite3.connect(db)
    lev = pd.read_sql(f"SELECT timestamp, value FROM sensor_data "
                      f"WHERE sensor_id IN ('T1','T2') AND timestamp>={t0} AND timestamp<={t1}", conn)
    pres = pd.read_sql(f"SELECT timestamp, avg_pressure FROM performance_data "
                       f"WHERE timestamp>={t0} AND timestamp<={t1}", conn)
    conn.close()
    below = lev[lev.value < 0.5]
    out_t = float(below.timestamp.min()) if len(below) else float(t1)
    pres['MPa'] = pres.avg_pressure * M_TO_MPA
    t_above = float((pres.MPa >= 0.10).sum() * 300 / 3600.0)
    os.remove(db) if os.path.exists(db) else None
    return dict(ri_p=ri_p, riv=riv, delivered=delv, out_t=(out_t - fs) / 3600.0,
                t_above=t_above)


def compare(key, **kw):
    """相位平均: 返回 {metric: (mean, lo, hi)} 字典。"""
    rows = {m: [] for m in ['ri_p_no', 'ri_p_ew', 'riv_no', 'riv_ew',
                            'del_no', 'del_ew', 'dT_iso', 'tA_no', 'tA_ew', 'gain']}
    for ph in PHASES:
        n = run_config('no_ew', FAULT_BASE + ph, **kw, tag=f'{key}_p{ph}')
        e = run_config('ew', FAULT_BASE + ph, **kw, tag=f'{key}_p{ph}')
        rows['ri_p_no'].append(n['ri_p']); rows['ri_p_ew'].append(e['ri_p'])
        rows['riv_no'].append(n['riv']); rows['riv_ew'].append(e['riv'])
        rows['del_no'].append(n['delivered']); rows['del_ew'].append(e['delivered'])
        rows['dT_iso'].append(e['out_t'] - n['out_t'])
        rows['tA_no'].append(n['t_above']); rows['tA_ew'].append(e['t_above'])
        g = (e['delivered'] - n['delivered']) / n['delivered'] * 100 if n['delivered'] > 0 else 0.0
        rows['gain'].append(g)
    out = {}
    for m, v in rows.items():
        out[m] = float(np.mean(v))
        out[m + '_lo'] = float(np.min(v))
        out[m + '_hi'] = float(np.max(v))
    return out


def sweep(dim, configs, out_csv, **fixed):
    print(f'--- {dim} ---', flush=True)
    recs = []
    t0 = time.time()
    for i, (key, kw) in enumerate(configs):
        kw = {**fixed, **kw}
        r = compare(key, **kw)
        r.update({'key': key})
        recs.append(r)
        el = time.time() - t0
        print(f'  [{i+1}/{len(configs)}] {key}: RIp {r["ri_p_no"]:.3f}->{r["ri_p_ew"]:.3f}, '
              f'dT_iso {r["dT_iso"]:.2f}h, gain {r["gain"]:.1f}% '
              f'({el:.0f}s elapsed)', flush=True)
    df = pd.DataFrame(recs)
    df.to_csv(out_csv, index=False, encoding='utf-8-sig')
    print(f'  -> {out_csv}\n', flush=True)


if __name__ == '__main__':
    print('=== 敏感性 v2: 加密 + 4相位平均 ===', flush=True)

    # 1) 阈值设计 D1-D5
    sweep('threshold', [('D%d' % (i + 1), {'threshold_levels': lv})
                        for i, (_, lv) in enumerate(sorted(DESIGNS.items()))],
          os.path.join(OUT, 'threshold.csv'),
          fault_duration_h=24.0)

    # 2) 水箱直径 0.6-1.4 步 0.1
    sweep('diameter', [(f'{s:.1f}', {'diameter_scale': s})
                       for s in np.round(np.arange(0.6, 1.41, 0.1), 2)],
          os.path.join(OUT, 'diameter.csv'),
          fault_duration_h=24.0)

    # 3) 断水时长 12-48 步 4
    sweep('duration', [(f'{d}', {'fault_duration_h': float(d)})
                       for d in range(12, 49, 4)],
          os.path.join(OUT, 'duration.csv'))

    # 4) 相对负载 0.6-1.4 步 0.1
    sweep('load', [(f'{l:.1f}', {'intensity_lambda': l})
                   for l in np.round(np.arange(0.6, 1.41, 0.1), 2)],
          os.path.join(OUT, 'load.csv'),
          fault_duration_h=24.0)

    print('ALL DONE', flush=True)
