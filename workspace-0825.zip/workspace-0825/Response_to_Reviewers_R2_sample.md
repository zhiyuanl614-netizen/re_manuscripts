# Detailed Response to Reviewers

**Manuscript ID:** FEM-2026-0130
**Title:** Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective
**Journal:** ENGINEERING Management

---

## Part 1: Response to Reviewer 1

We thank Reviewer 1 for the thorough and constructive comments on our manuscript. The comments have been addressed through targeted revisions to the abstract and keywords, the literature review and research objectives, the explicit modeling assumptions and threshold rationales, the figure and table presentation, the cyber-physical mechanism description, the limitations and future research directions, the conclusions, and the reference list. We respond to each of the seven numbered points in sequence below. For each point we restate the concern, describe the specific changes made to the revised manuscript (section and subsection numbers, table and figure numbers), and quote the corresponding revised text where appropriate.

---

### Comment 1: Abstract and Keywords

**Reviewer Comment:**

> The abstract contains redundant descriptions and lengthy sentences. Please streamline the language, and concisely summarize the research scenario, core methodology, key findings and major innovations.

**Author Response:**

We agree with the Reviewer's comment. The original abstract contained redundant descriptions and lengthy sentences, and the research scenario, methodological contribution, and principal findings were not presented concisely. We have rewritten the abstract accordingly.

The revised abstract is condensed and restructured. Redundant phrasing and nonessential detail have been removed, and the content is organized to reflect four elements: the research scenario, the core methodology, the key findings, and the innovation and engineering implications, as described below.

1. **Research scenario.** The abstract now states the problem precisely: a complete water-source outage affecting an urban water supply cyber-physical system, and frames the study around proactive intervention rather than post-hoc assessment.

2. **Core methodology.** The abstract now states the methodological contribution in explicit terms: a three-layer cyber-physical co-simulation framework that couples pressure-driven hydraulics with SCADA-informed demand management, and that binds graded tank-level warning states to demand retention multipliers under a one-way ratchet. It further introduces two complementary metrics that jointly evaluate pressure compliance and delivered water service.

3. **Key findings.** The abstract now reports the principal results concisely and states their causal interpretation. It identifies that the intervention postpones outlet failure and extends emergency-grade supply, and that the gain arises from the temporal reallocation of a fixed storage volume rather than from water creation. It also notes that the benefit remains positive across varying warning thresholds, storage capacity, outage duration, and demand load, thereby conveying both the magnitude and the generality of the observed improvement.

4. **Major innovations and engineering implications.** The abstract closes by articulating the contribution — overcoming the passive, purely physical-layer limitation of current resilience practice — and its practical relevance, namely providing a foundation for information-mediated emergency dispatch in smart water utilities.

**Keywords.** The keyword list was also revised, consistent with the title of the Reviewer's comment. The original keywords were unordered and partially overlapping. The revised set of six keywords is concise and mutually exclusive, and each keyword corresponds to a distinct element of the revised abstract:

- **Urban water supply** — the system of study;
- **Cyber-physical system** — the coupled architecture;
- **Proactive resilience** — the overarching contribution;
- **Early warning management** — the operational mechanism;
- **Graded demand curtailment** — the executable intervention;
- **Co-simulation** — the evaluation methodology.

The revised abstract and keywords are presented at the beginning of the revised manuscript (Abstract and Keywords sections).

---

### Comment 2: Introduction

**Reviewer Comment:**

> The literature review is superficial. Most references are simply listed without in-depth comparative analysis. Please sort out state-of-the-art studies on water supply CPS, resilience assessment and early warning technologies, and clearly clarify the marginal contributions of this work against existing literature. The three research objectives are scattered. Reorganize and condense them at the end of the introduction to clearly state the problems to be solved, models to be established and mechanisms to be revealed.

**Author Response:**

We agree with the Reviewer's comment. The original Introduction listed a large number of references without sufficient comparative analysis, did not clearly delineate the contribution of this work relative to the existing literature, and presented the research objectives in a scattered manner. We have restructured the Introduction accordingly, and the revision addresses each aspect as follows.

**1. Reorganization of the literature review around three research streams.**

The literature review is now organized into three interconnected streams rather than a list of citations. For each stream we first summarize the primary focus of the state-of-the-art studies, then identify their methodological or operational limitation, and finally explain how that limitation relates to the complete source-interruption scenario addressed in this work.

- **Stream 1: urban water supply cyber-physical systems and cyber monitoring.** The review now groups the existing work on CPS integration, Internet of Things-enabled sensing, and SCADA-based monitoring (Alexandra et al., 2023; Ande et al., 2020; Bhardwaj et al., 2021; Khan et al., 2020; Liao et al., 2025; Mohebbi et al., 2020; Yadav and Paul, 2021; Bonilla et al., 2022). It then distinguishes the work on cybersecurity, anomaly detection, and leak localization (Hassanzadeh et al., 2020; Taormina et al., 2018; Xu et al., 2020; Amin et al., 2013), and concludes that these studies treat the cyber layer largely as an observatory and rarely connect its output to hydraulic control during a physical interruption.

- **Stream 2: resilience assessment and performance evaluation.** The review now separates structural (topological) measures from hydraulic measures (Cai et al., 2021; Meng et al., 2018; Feng et al., 2025; Zhang et al., 2022), and situates them within the reliability and resilience frameworks of Hashimoto et al. (1982), Cimellaro et al. (2010), and the Safe and SuRe approach of Butler et al. (2017). It then identifies two limitations specific to the problem at hand: existing assessments are largely post hoc, and a pressure-only index can overestimate performance under demand reduction, because pressure may be preserved while the delivered volume decreases.

- **Stream 3: early warning and emergency decision support.** The review now groups the work on early warning application and alarm generation (Juan García et al., 2017; Liu and Mijic, 2025) against the passive fail-and-repair paradigm (Holling, 1973; Hosseini et al., 2016), and notes that existing warning applications rarely specify how a warning state is translated into an executable control rule. This stream introduces the central concept of the revised manuscript, the time difference window.

**2. Clarification of the marginal contribution of this study.**

The revised Introduction now states explicitly how this work differs from the existing literature. Whereas prior studies have concentrated on anomaly detection, cybersecurity, and leak localization, or on open-loop resilience assessment and alarm generation, the present study integrates rapid cyber observation with physical hydraulic intervention through SCADA-informed demand management. Early warning management (EWM) is operationalized as a graded demand-management rule that binds warning states to demand retention multipliers, and is therefore an executable intervention rather than a monitoring or alarm function. This distinction is now stated in the Introduction rather than left implicit.

**3. Consolidation of the research objectives.**

The three original objectives, which were previously scattered across the manuscript, have been condensed and reorganized at the end of the Introduction as three concerns that correspond directly to the Reviewer's requested structure of problem, model, and mechanism:

- **The problem to be solved** is the post-outage collapse caused by uncurtailed tank depletion, in which pressure and delivery fail together once storage is exhausted.
- **The model to be established** is a three-layer, weakly coupled co-simulation platform that links an EPANET 2.2 pressure-driven kernel to a SCADA module through a time-synchronized database, and that contains an executable EWM rule binding graded tank-level warning states to demand retention multipliers under a one-way ratchet. The framework is proposed at the conceptual level and is instantiated as this platform, as clarified in Section 2.3.
- **The mechanism to be revealed** is the information-mediated origin of the time difference window, its quantification through the complementary service time and service value metrics, and its operational boundaries under varying warning thresholds, storage capacity, outage duration, and demand load.

These consolidated objectives are presented at the end of the Introduction, following the roadmap paragraph that lists the organization of the remaining sections. The revised Introduction therefore states the problem to be solved, the model and control framework to be established, and the mechanism to be revealed in a single condensed passage.
---

### Comment 3: Materials and Methods

**Reviewer Comment:**

> The current model assumes ideal conditions including error-free sensors, zero communication delay and no data loss. Please add a dedicated section to list all ideal assumptions explicitly, and discuss their potential impacts on simulation results in practical engineering.
>
> The pressure threshold refers to GB 50013-2018, while the water level thresholds for five risk states (Normal, Warning, Alert, Critical, Outlet Failure) are given without explanation. Please specify the basis for threshold division (engineering experience, published literature or numerical trial calculation).

**Author Response:**

We agree with the Reviewer's comment. The original manuscript did not provide a transparent account of its idealized modeling assumptions, and the basis for the tank-level thresholds used to define the five risk states was not explained. Both aspects have been addressed in the revised Materials and Methods, which has been reorganized into five subsections (Sections 2.1–2.5) so that the modeling workflow, control logic, experimental design, resilience metrics, and assumptions are each presented explicitly.

**1. Dedicated section listing all idealized assumptions and their practical implications.**

A dedicated subsection, Section 2.5 "Model Assumptions," has been added. To isolate the effect of the EWM intervention, the co-simulation model makes eleven explicit idealized assumptions, designated A1 to A11, regarding:

- (A1) the fixed 300 s simulation time step;
- (A2) the clipping of sub-zero pressures in the network average;
- (A3) error-free and continuous sensing;
- (A4) lossless and instantaneous communication;
- (A5) instantaneous and uniform execution of demand curtailment;
- (A6) demand-pattern-based value weighting;
- (A7) a tank-only storage anchor;
- (A8) hydraulic symmetry between the two tanks;
- (A9) a deterministic step-function outage;
- (A10) the absence of water quality deterioration; and
- (A11) binary (on/off) pump control.

Each assumption is documented in **Supplementary Table S1** together with its practical engineering impact and the corresponding feasible mitigation. For example, sensor noise or drift may cause premature or delayed EWM triggering, communication congestion or packet loss may delay the demand-reduction command, finite valve actuation time may reduce the immediacy of control execution, deep curtailment may increase water age and stagnation, and real disturbances may involve partial or cascading failures rather than a deterministic total pump shutdown. We also clarify in Section 2.5 the conservative direction of these simplifications: because they act against the intervention rather than in its favor, the reported pressure and Service-value gains are conservative, and their robustness is supported by the multi-factor sensitivity analysis (Section 3.4) and the mass balance audit (η ≈ 1.0006, Section 2.3).

**2. Explicit basis for the water-level risk thresholds.**

The basis for the four tank-level thresholds that define the five operational states (NORMAL, WARNING, ALERT, CRITICAL, and OUTLET FAILURE) is now stated explicitly in a new subsection, Section 2.2.3 "Basis of the Tiered Thresholds," and the corresponding trigger logic and control actions are summarized in Table 1. The revised subsection clarifies that the thresholds do not all derive from a single source:

- The **0.5 m outlet-failure threshold** is based on physical geometry. It corresponds to the crown elevation of the tank outlet pipelines; water levels below this elevation induce vortex formation and air entrainment, which necessitates isolation.
- The **5.0 m WARNING threshold** coincides with the baseline PLC pump activation setpoint, which ensures consistency between routine and emergency operation. A tank level below 5.0 m alone does not trigger demand management while normal pumping remains operational.
- The **3.5 m ALERT threshold** and the **2.0 m CRITICAL threshold** are operational control levels, not statutory water-level requirements. They equally partition the usable water depth between 5.0 m and 0.5 m, thereby providing sequential response windows for graded curtailment.

We also clarify the role of the statutory value in the revised manuscript. The pressure threshold of 0.10 MPa referenced in GB 50013-2018 (MOHURD, 2018) serves only as the emergency service-head floor of the Service time metric (Section 2.4.1). It is not used as the source of the tank-level thresholds, and the numerical values in the two cases are therefore conceptually distinct.

**3. Verification of the threshold selection.**

To examine the robustness of the threshold configuration, a sensitivity experiment has been added (Section 2.2.4 and Section 3.4). Five threshold designs, D1 to D5, are defined, ranging from late and liberal triggering (D1) to early and conservative triggering (D5), with D3 representing the symmetric baseline configuration of 5.0/3.5/2.0/0.5 m. This experiment addresses the question of engineering experience versus numerical trial calculation directly, by showing how the Service time varies monotonically with the threshold design and thereby demonstrating that the symmetric D3 design is a balanced operating point rather than a numerically arbitrary choice.
---

### Comment 4: Results

**Reviewer Comment:**

> There are incomplete labels, missing legends and spelling mistakes (e.g., Critical Threbok should be Critical Threshold) in Figs. 4 and 5. Please check all figures, tables, abbreviations and captions thoroughly to unify the format and eliminate typos.

**Author Response:**

We agree with the Reviewer's comment. The original figures and tables contained incomplete labels, missing legends, and typographical errors, including the misspelled axis label "Critical Threbok." We have conducted a comprehensive check of all figures, tables, abbreviations, variables, captions, legends, axis labels, units, and operational-state labels throughout the revised manuscript, and the presentation has been standardized accordingly.

**1. Correction of the identified error.**

The incorrect label "Critical Threbok" has been corrected to "Critical Threshold" wherever it appears. In addition, the revised figure set no longer uses the ambiguous threshold-label wording that caused the original confusion; the pressure threshold of 0.10 MPa is now denoted explicitly as the emergency supply head in both the figures and the corresponding captions and text.

**2. Completion and standardization of labels and legends.**

The labels and legends in Figs. 4 and 5 have been completed and standardized. In Fig. 4 the warning (W), alert (A), and critical (C) trigger lines are now labeled explicitly, and the two comparative cases are identified consistently as No EWM and EWM. In Fig. 5 the two cases are distinguished by bar shade, with the legend stating that the darker bars denote the EWM case; the two metrics are labeled by their full names, Service value and Service time, which are consistent with the metric definitions given in Section 2.4.

**3. Unification of the five operational-state labels.**

The five operational states are now identified consistently throughout the manuscript, figures, and tables as NORMAL, WARNING, ALERT, CRITICAL, and OUTLET FAILURE, with the corresponding tank-level thresholds of 5.0, 3.5, 2.0, and 0.5 m. This consistent naming is used in Table 1 (trigger logic), in the Results text, and in Figs. 3 and 4, so that the state names, the figure annotations, and the numerical thresholds are mutually consistent.

**4. Systematic check of the remaining figures, tables, and formatting.**

Beyond Figs. 4 and 5, we checked and unified the captions, axis labels, units, and variable names of all figures and tables, including Figs. 1, 3, and 6 and Table 1. In particular:

- Fig. 3 panel labels now state the quantity plotted in each panel ((a) tank T1 water level, (b) tank T2 water level with the 0.5 m outlet isolation threshold, and (c) the nodal pressure map) and include the white dashed contour for the 0.10 MPa emergency threshold.
- Fig. 6 now includes a legend that states that light curves and markers denote the No EWM case and dark curves denote the EWM case, and clarifies that the plotted values are phase averaged over four fault onset offsets with error bars denoting per-phase minimum to maximum ranges.
- Units are given uniformly (m for water level, MPa for pressure, h for time, m³ and m³·pattern for volume and weighted service), and abbreviations and variable names are introduced once at first use.

These revisions have been implemented throughout the revised Results section so that all figures, tables, abbreviations, and captions are internally consistent and free of typographical errors.
---

### Comment 5: Discussion

**Reviewer Comment:**

> The concept of time-based performance compensation is proposed, but the linkage mechanism among cyber sensing layer, control layer and physical hydraulic layer is not decomposed. Combine the CPS three-layer architecture to elaborate the complete working mechanism of EWM.
>
> Expand the discussion on limitations: the model does not take water quality deterioration, negative pressure backflow and dynamic user water demand into account; supplement relevant explanations.
>
> The future research directions (AI, Digital Twin) are too general. Combine the current simulation framework to specify how to integrate Digital Twin technology and realize dynamic threshold adjustment.

**Author Response:**

We agree with the Reviewer's comment. The original Discussion proposed the concept of time-based performance compensation but did not decompose the linkage among the cyber sensing, control, and physical hydraulic layers; the limitations section was not sufficiently developed; and the future directions on AI and Digital Twin were too general. The Discussion has been reorganized into four subsections (Sections 4.1–4.4) and the three aspects of the comment are addressed as follows.

**1. Decomposition of the complete EWM working mechanism within the three-layer CPS architecture (Section 4.2).**

A new subsection, Section 4.2 "Cyber-Physical Mechanism and the Origin of the Time Difference Window," now decomposes the EWM process into the full information–decision–actuation loop within the three-layer architecture. The loop comprises four functional stages, which are mapped onto the three layers as follows. Sensing and control are two functions of the cyber layer, coupling is performed by the coupling layer, and actuation is performed by the physical layer:

- **Sensing (cyber layer).** Samples tank water levels and pump states at 300 s intervals.
- **Control (cyber layer).** Evaluates the tiered thresholds, enforces the one-way ratchet, and issues the demand retention multiplier.
- **Coupling (coupling layer).** The time-synchronized database timestamps every state and exposes it to the decision module, which makes each transition auditable and reproducible.
- **Actuation (physical layer).** Executes the curtailment at the next hydraulic solve, and the resulting state closes the loop.

We note that the architecture remains a three-layer structure (physical, coupling, cyber), and that sensing and control are two functions within the cyber layer rather than two additional layers; the four items above are four functional stages of a single closed loop executed across the three layers.

The revised subsection emphasizes that physical tank storage provides the capacity over which the intervention operates, whereas graded demand management determines how that capacity is allocated during the failure process. It further states that every arrow of the loop is exercised by a logged event, namely the state escalations at 26.08, 28.00, and 30.83 h, and the command execution verified in Section 3.2.

Crucially, Section 4.2 now includes a counterfactual comparison that isolates the causal role of the loop. With identical storage, hydraulics, and protection rules, the network without the loop exhausts its storage at 30.17 h, whereas the network with the loop exhausts it at 34.33 h; the 4.17 h window is therefore information mediated rather than storage driven. This directly resolves the ambiguity raised in the original manuscript, in which the time-based compensation was asserted without decomposing its origin.

**2. Expanded discussion of the limitations (Section 4.4).**

The limitations section has been expanded to address the three processes the Reviewer identified, together with their hydraulic and practical consequences:

- **Water quality deterioration.** Low flow velocities during deep curtailment increase water age and stagnation, and chlorine residuals may decay along the preserved but slow-moving supply paths. Coupling the platform with the water quality solver of EPANET 2.2 would extend the evaluation from quantity resilience to quality resilience, consistent with network-based water quality assessment (Sitzenfrei, 2021) and drinking-water quality guidelines (WHO, 2022).
- **Low- or negative-pressure backflow and contaminant intrusion.** Sub-atmospheric pressures and contaminant intrusion are not modeled, although low- and negative-pressure events are a documented pathway for microbial intrusion through leaks and submerged orifices (Besner et al., 2011), and this concern is reinforced by hydraulic resilience measures that couple water quality considerations (Hou et al., 2023) and by pipe failure probability modeling (Taiwo et al., 2023). Transient surge analysis is therefore identified as necessary before field deployment, even though the outlet guard limits tank drainage.
- **Dynamic user water demand.** Demands are treated as fully controllable and static in pattern, whereas real customers respond to curtailment with behavioral adaptation and rebound. This is now stated explicitly as a boundary of the present analysis.

**3. Concrete pathway for Digital Twin integration and dynamic threshold adjustment (Section 4.4).**

The future direction on Digital Twin is now tied directly to the current co-simulation platform. Because the physical and cyber domains interact only through the time-synchronized database, the simulated telemetry can be replaced by live SCADA feeds without structural change, which is consistent with the state-estimation architectures already demonstrated for water networks (Bonilla et al., 2022) and the role of digital technologies for critical-infrastructure climate resilience (Argyroudis et al., 2022). On this basis, dynamic threshold adjustment is described as a concrete receding-horizon procedure:

- a state estimator updates the storage trajectory in real time;
- a demand forecast projects the depletion rate under the current pattern; and
- the warning thresholds are recomputed online so that the predicted tank level reaches the isolation limit exactly at the expected restoration time.

The revised subsection connects this procedure to the fixed ratchet studied here, noting that the ratchet logic and retention grades carry over unchanged. It further notes that a supply-interruption digital twin that couples remote meter and hydraulic data has already been demonstrated for multi-modal failure analysis (Pesantez et al., 2022), which supports the practical feasibility of the proposed extension, and that machine-learning demand forecasting and adaptive priority weighting through the node weights w_j are the natural next steps. This formulation anchors the future research direction in the current simulation architecture rather than presenting AI and Digital Twin as general, untethered directions.
---

### Comment 6: Conclusions

**Reviewer Comment:**

> Remove repeated content and reorganize the conclusions into three parts: theoretical findings, key simulation results and engineering implications for clearer logic. Add targeted operational suggestions for water supply management departments to enrich the practical guidance of this research.

**Author Response:**

We agree with the Reviewer's comment. The original Conclusions repeated several methodological and interpretative details already presented in the Results and Discussion sections, and did not separate the theoretical findings, the simulation results, and the practical implications into distinct parts. The Conclusions have been reorganized accordingly.

**1. Reorganization into three distinct parts (Section 5).**

Section 5 is now structured as three clearly separated paragraphs, introduced by the labels "Theoretical finding," "Key simulation results," and "Engineering implications," and each part carries a distinct function:

- **Theoretical finding.** The first paragraph states the main theoretical contribution: that proactive resilience in urban water supply cyber-physical systems can be achieved by exploiting the time difference window created by the mismatch between rapid cyber sensing and gradual hydraulic degradation. It then articulates the mechanism within the three-layer linkage, noting that the cyber layer performs both sensing and control and that the physical layer executes graded curtailment, and clarifies that early warning is not merely an alarm output but an executable emergency control mechanism. It concludes with the counterfactual evidence (identical storage fails at 30.17 h without the control loop and at 34.33 h with it) that isolates the claim, so the window is information mediated rather than storage driven. Repeated descriptions of the methodology and the platform are removed; this paragraph contains only the conceptual contribution.

- **Key simulation results.** The second paragraph condenses the principal numerical outcomes into a single summary, without reinstating the intermediate discussion: the postponement of outlet failure from 30.17 h to 34.33 h, the shortening of the outlet-failure duration within the fault window from 17.83 h to 13.67 h, the extension of Service time by 67.6% and the improvement of Service value by 23.0%, the volumetric audit showing a change of only 0.6% in total delivered volume with a 25.5% reduction in the physically unserved volume, and the phase-averaged robustness of the Service time gain over the 264 paired runs.

- **Engineering implications.** The third paragraph provides targeted, operational recommendations for urban water supply management departments, replacing the earlier generic statement about practical value.

**2. Targeted operational suggestions for water supply management departments.**

Following the Reviewer's request, the third paragraph now gives four concrete recommendations that are directly actionable by water supply management departments:

- encode the graded retention schedule into the existing SCADA-to-execution pathway through advanced metering infrastructure, pressure-reducing valves, or equivalent controllable devices, with the retention tiers adopted as pre-agreed curtailment contracts for large users;
- recalibrate the 5.0/3.5/2.0/0.5 m trigger levels to local tank geometry, storage capacity, expected outage duration, and demand load rather than transferring them between networks, because earlier curtailment extends service monotonically but sheds demand earlier and longer;
- replace uniform demand reduction with priority-based allocation that protects hospitals and firefighting capacity before field deployment, for which the node weights of the Service value metric provide the designed entry point; and
- where short-horizon forecasts are available, use a digital twin built on the existing co-simulation platform to recompute the trigger depths and retention multipliers online, so that the predicted tank level reaches the isolation limit exactly at the expected restoration time.

**3. Removal of repeated content and standardization of terminology.**

Repetitive content has been removed. The paragraph no longer restates the platform architecture, the sensitivity procedure, or the discussion of limitations in detail; these remain in Sections 2 and 4. The terminology is now consistent with the rest of the manuscript, using the time difference window, Service time and Service value, the complete 24 h water-source outage, and the graded retention schedule.
---

### Comment 7: Language, Grammar and References

**Reviewer Comment:**

> Proofread the full text to correct spelling errors, grammatical mistakes and awkward long sentences. Unify the expression of professional terms (time-difference buffer / time-difference window).
>
> Sort out the reference list: delete duplicate literature entries, and revise references to comply with the formatting requirements of ENGINEERING Management.

**Author Response:**

We agree with the Reviewer's comment on both aspects. A comprehensive language revision has been applied to the full manuscript, and the reference list has been checked, deduplicated, and reformatted according to the journal requirements.

**1. Full-text language revision.**

The entire manuscript has been proofread and revised, addressing the following:

- **Spelling, punctuation, and grammar.** Spelling errors, punctuation, article use, verb tense, subject–verb agreement, and singular/plural inconsistencies have been corrected throughout the Abstract, Introduction, Methodology, Results, Discussion, and Conclusions.
- **Long and complex sentences.** Excessively long or syntactically complex sentences have been restructured to improve readability, and paragraph-level coherence and transitions have been strengthened.
- **Redundant and awkward expressions.** Redundant, literal, and awkward expressions have been removed, and capitalization, hyphenation, units, symbols, abbreviations, and figure and table captions have been standardized across the manuscript.

**2. Unification of the professional terminology.**

The inconsistent expressions noted by the Reviewer, "time-difference buffer" and "time-difference window," have been unified. In the revised manuscript the terminology describing the mismatch between rapid cyber sensing and gradual hydraulic degradation is now expressed consistently as the **time difference window** throughout, and the hyphenated variants and the alternative "temporal buffer" do not appear. This single term is used in the Abstract, Introduction, Discussion, and Conclusions to denote the additional operating time created by this timescale mismatch. The heading-case form "Time Difference Window" is retained only where the term is introduced as a defined concept.

We note that we also reviewed a related naming pair in the same spirit of consistency, since the manuscript distinguishes the methodological contribution from its software implementation. The term **co-simulation framework** is used for the conceptual contribution (Abstract, Introduction, Discussion, Conclusions), whereas **co-simulation platform** is used for the computational implementation that executes the simulation (Sections 2.3 and 2.4, Fig. 2); this distinction is stated explicitly in Section 2.3, which notes that the framework is instantiated as the platform. Finally, the operational state labels are given consistently as NORMAL, WARNING, ALERT, CRITICAL, and OUTLET FAILURE, and the two resilience metrics are referred to uniformly as Service time and Service value.

**3. Reference list: deduplication and journal-format compliance.**

The reference list has been systematically checked against the in-text citations. The following were carried out:

- **Deduplication.** Duplicate entries have been removed and consolidated. The two records for the same Chinese standard MOHURD (2018) have been merged into a single entry citing the official full title and the standard number GB 50013-2018, and a small number of fragmentary or redundant records have been absorbed into their corresponding principal entries. Entries that were not cited in the revised text, or whose subject matter was not directly relevant to the revised analysis, have been removed rather than retained uncited. Following this, the reference list contains 53 distinct entries, each corresponding to exactly one in-text citation.
- **Citation–reference correspondence.** Each in-text citation has been verified to correspond to one entry in the reference list, and each listed reference to be cited in the manuscript; no orphan citations or uncited references remain. In particular, entries referenced in the Discussion (such as Sirsant et al., 2023; Pesantez et al., 2022; Hu et al., 2023; Cemiloglu et al., 2023) and those added in support of the specific arguments (such as Mohebbi et al., 2020; Xu et al., 2020; Farmani et al., 2005; Walski et al., 2003) have been confirmed against the published source information.
- **Formatting.** The references have been reformatted according to the requirements of ENGINEERING Management, with standardized author names, publication years, article titles, journal titles, volume and issue numbers, page ranges, book and proceedings details, and institutional reports. The Chinese standard is now cited as Ministry of Housing and Urban-Rural Development of China (MOHURD) (2018) with its full title and the standard number GB 50013-2018, and the WHO guideline as World Health Organization (WHO) (2022).

These revisions have been implemented throughout the manuscript.


---

## Part 2: Response to Reviewer 2

We thank Reviewer 2 for the rigorous and constructive comments on our manuscript. The comments have influenced the operational definition of the early warning mechanism, the transparency and fairness of the scenario comparison, the dual-metric resilience formulation that includes unmet demand, the attribution of the time difference window, the multi-factor sensitivity analysis, and the numerical consistency of the reported results. We respond to each of the six numbered concerns in sequence below. For each point we restate the concern, describe the corresponding change in the revised manuscript (section and subsection numbers, table and figure numbers), and quote the revised text where appropriate.

### Comment 1: The Early Warning Mechanism as an Operational Intervention

**Reviewer Comment:**

> The early warning mechanism is not clearly specified as an operational intervention. Sections 2.2–2.4 mainly describe sensing, monitoring, risk classification, and the recording of state transitions. However, it is not clear what concrete action is taken once the system enters the Warning, Alert, or Critical state. Since the source interruption scenario states that the reservoir supply is lost and the tanks receive no replenishment during 24–48 h, the reported increase in RI from 0.22 to 0.84 and the higher maintained pressure cannot be explained by warning signals alone.

**Author Response:**

We agree with the Reviewer's comment. The original manuscript recorded risk states and generated warning signals, but it did not specify the physical action taken on the hydraulic system once a warning state was entered; under a 24–48 h uninterrupted outage, a warning signal alone cannot change the supply. This gap has been closed by defining the EWM as an executable control law rather than a passive alarm system.

**1. The EWM is now defined as an operational intervention.**

Section 2.2.2, "EWM as an Operational Intervention," now states explicitly that each risk state is bound to a specific demand-side action that is executed at the next control step. Once the pumps are physically offline, the tank level is compared with the tiered thresholds and the demand retention multiplier $\gamma$ is updated according to the trigger logic in Table 1. The curtailment is applied uniformly to the scheduled base demand of every junction through the pressure-driven hydraulic relationship

$$q_{j,t} = \gamma \cdot q^{sched}_{j,t}.$$

The intervention is therefore a physical reallocation of demand, not an alarm; it changes the delivered flow that the hydraulic solver receives at the next step, and it is this change, rather than the warning itself, that sustains pressure and postpones outlet failure.

**2. The graded action and its hydraulic effect are made explicit.**

Table 1 now specifies the demand retention multiplier and the resulting hydraulic action for each of the five operational states. Under the baseline design D3, entry into the WARNING, ALERT, CRITICAL, and OUTLET FAILURE states is associated with retention multipliers of 0.70, 0.40, 0.20, and 0 (physical outlet closure), respectively, corresponding to level-1 to level-3 curtailment and the final isolation of the tank outlet. Each state is tied to a measurable hydraulic consequence rather than to a flag, which makes the mechanism that produces the resilience gain explicit.

**3. Two safeguards that define the control law.**

The control law is further specified by two safeguards. First, a one-way ratchet ($\gamma_t \le \gamma_{t-1}$ within the fault window) prevents control chattering: escalation is immediate, and downgrade occurs only when the fault ends at $t = 48$ h, at which time demands recover to 100%. Second, the local PLC logic is retained; under normal pumping the PLC refills the tanks by hysteresis, with pump activation at $H \le 5.0$ m and shutdown at $H \ge 8.0$ m, and demand-side management is initiated only after a confirmed pump trip, so routine level fluctuations never trigger curtailment.

**4. The comparative cases are separated by exactly one controlled variable.**

The relationship between the two cases is stated in Section 2.2.5, which we address in detail under Comment 2. The baseline case keeps $\gamma \equiv 1.00$, whereas the EWM case applies the state-dependent schedule of Table 1; all other hydraulic and control rules are identical. This step removes the ambiguity identified by the Reviewer, in which a warning signal was recorded but no physical action was described, and makes clear that the reported gain originates from the executed demand management.
