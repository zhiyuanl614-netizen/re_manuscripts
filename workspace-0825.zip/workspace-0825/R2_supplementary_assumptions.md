# Supplementary Material for Manuscript FEM-2026-0130 (Revision R2)

> Title: Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective
> Journal: ENGINEERING Management
>
> This file corresponds to **Supplementary Table S1**, the complete table of idealized modeling assumptions, practical impacts, and engineering mitigation options referenced by Section 2.5 of the main manuscript. The main text retains a dedicated "Model Assumptions" section that discusses the three assumptions most relevant to the reported results; the full per-assumption detail is provided here to keep the main text concise.

---

## Supplementary Table S1. Idealized modeling assumptions, practical impacts, and engineering mitigation options.

| # | Domain | Idealized assumption | Practical impact | Engineering mitigation |
|---|---|---|---|---|
| A1 | Temporal resolution | Sensing and control act on the 300 s step; event times are recorded at step boundaries. | Sub-step dynamics below 5 min are unresolved. For example, the two tanks isolate within the same step, and sub-step interpolation gives a stagger of 1.6 to 2.6 min. | Finer SCADA polling or event-triggered reporting. |
| A2 | Pressure aggregation | Nodal gauge pressures below zero, which arise at zero-demand junctions in a drained network under PDA, are clipped at zero in the network average. | The average pressure is slightly conservative during deep degradation. | Reporting of per-junction statistics, as in the nodal pressure maps (Figs. 3(c) and 4(d)). |
| A3 | Cyber sensing | Error-free and continuous telemetry of tank levels and pump states. | Measurement noise or drift could shift trigger times by minutes. | Local Kalman filtering and redundant sensing at tanks. |
| A4 | Communication | Zero latency and no packet loss between SCADA and PLCs. | Delayed curtailment commands on the order of seconds to minutes. | Edge-computing PLCs with autonomous threshold evaluation. |
| A5 | Control execution | Curtailment is applied instantaneously and uniformly at all junctions. | Real valve and meter actuation requires finite time, and uniform shedding ignores user heterogeneity. | AMI-enabled smart meters and pressure-reducing valves with preset emergency routines; priority grading through $w_j$. |
| A6 | Value weighting | Service value is weighted by the normalized demand pattern α(t) rather than by economic loss functions. | The value ranking follows system-wide demand blocks rather than user-specific criticality. | Socioeconomic weighting schemes in $w_j$. |
| A7 | Storage anchor | $S^{*}$ counts tank storage only; pipe volume is excluded from the value ceiling. | The ceiling slightly understates the available water, and $R_w$ is slightly conservative. | Extension of the anchor with pipe storage estimation. |
| A8 | Hydraulic symmetry | T1 and T2 share identical settings and exhibit equalized drawdown through the looped network. | Site-specific asymmetries would stagger the two isolations. | Network-specific calibration and per-tank reporting, as in Figs. 4(b) and 4(c). |
| A9 | Disturbance | Deterministic step-function total outage of 24 to 48 h. | Real outages may be partial or cascading. | Multi-factor scans, including durations of 12 to 48 h (Section 3.4). |
| A10 | Water quality | No water quality deterioration, such as chlorine decay or water age increase, during emergency supply. | Low velocities under curtailment may increase stagnation. | Limitation of the CRITICAL state duration and post-event flushing. |
| A11 | Pump control | Pumps are binary (on or off) without variable speed operation. | Variable-frequency-drive-based pressure management is not explored. | Extension of the action set with pump speed modulation. |

---

## Notes on the three assumptions discussed in the main text (Section 2.5)

- **A8 (Hydraulic symmetry)** governs the simultaneity of the two tank isolations and is directly observable in the results (Figs. 3(a, b) and 4(b, c)).
- **A9 (Disturbance)** defines the canonical outage and is tested against outage durations of 12 to 48 h, storage scales of 0.6× to 1.4×, and demand loads of 0.6× to 1.4× (Section 3.4, Fig. 6).
- **A2, A6, A7 (pressure and value metrics)** all act directionally against the intervention; the corresponding simplifications make the reported resilience and Service-value gains conservative rather than optimistic.
