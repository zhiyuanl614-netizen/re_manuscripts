import re
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def add_text_para(doc, text, style=None, bold=False, italic=False, size=11, align=None, space_after=6):
    p = doc.add_paragraph()
    if align: p.alignment = align
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    run.font.name = 'Times New Roman'
    p.paragraph_format.space_after = Pt(space_after)
    return p

def add_heading(doc, text, level=1, size=None):
    sizes = {0:14,1:13,2:12,3:11.5}
    h = doc.add_heading('', level=max(level,1))
    run = h.add_run(text)
    run.bold = True
    run.font.name = 'Times New Roman'
    run.font.size = Pt(sizes.get(level,12) if size is None else size)
    run.font.color.rgb = RGBColor(0,0,0)
    return h

doc = Document()
# set base style font
style = doc.styles['Normal']
style.font.name = 'Times New Roman'
style.font.size = Pt(11)

# ---- Title ----
add_text_para(doc, 'Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective', bold=True, size=14, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
add_text_para(doc, 'Manuscript ID FEM-2026-0130 (Revision R2)  |  Journal: ENGINEERING Management', italic=True, size=10, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
add_text_para(doc, 'Revision marking: text in blue is revised or newly written in this revision; equations are provided in plain text for final formatting in the equation editor.', size=9, italic=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=12)

# ---- Abstract ----
add_heading(doc, 'Abstract', 1)
abs_txt = open('R2_abstract_FINAL.txt',encoding='utf-8').read().strip()
add_text_para(doc, abs_txt, size=11, space_after=8)
add_text_para(doc, 'Keywords: Urban water supply; Cyber-physical system; Proactive resilience; Early warning management; Graded demand curtailment; Co-simulation.', bold=False, italic=True, size=10, space_after=12)

# ---- 1. Introduction ----
intro = open('R2_introduction_polished.md',encoding='utf-8').read()
add_heading(doc, '1. Introduction', 1)
# skip the header comment block until first '## 1. Introduction'
body = intro[intro.find('## 1. Introduction'):]
# remove the '## ' on the heading line
lines = body.split('\n')
for ln in lines:
    if ln.strip().startswith('## '):
        continue
    txt=ln.strip()
    if txt:
        add_text_para(doc, txt, size=11, space_after=6)

# ---- 2. Materials and Methods ----
meth = open('R2_methods_polished.md',encoding='utf-8').read()
add_heading(doc, '2. Materials and Methods', 1)
mbody = meth[meth.find('## 2. Materials and Methods'):]
# We need to insert a real table for Table 1. We'll process line by line, building Table 1 when marker seen.
tbl1_rows = [
 ('Risk state','Trigger ($S_{pump}=0$)','Retention $\\gamma$','Operational action and hydraulic effect'),
 ('NORMAL','$H_{tank} \\ge 5.0$ m','1.00','Regular supply; 100% of nominal demand is delivered.'),
 ('WARNING','$H_{tank} < 5.0$ m','0.70','Level 1 curtailment; 30% of nonessential demand is shed, which slows the initial storage depletion.'),
 ('ALERT','$H_{tank} < 3.5$ m','0.40','Level 2 curtailment; 60% is shed, which preserves pressure above the emergency supply head.'),
 ('CRITICAL','$H_{tank} < 2.0$ m','0.20','Level 3 curtailment; 80% is shed, which maintains the minimum emergency head and prevents tank dry out.'),
 ('OUTLET FAILURE','$H_{tank} < 0.5$ m','0 (physical closure)','The tank outlet is closed to prevent vortex formation, cavitation, and air entrainment; no further supply is possible.'),
]
lines = mbody.split('\n')
skip_mode = False
for ln in lines:
    s = ln.strip()
    if s.startswith('## '):
        continue
    if s.startswith('**Table 1.') :
        # add table
        t = doc.add_table(rows=len(tbl1_rows), cols=4)
        t.style = 'Table Grid'
        for i,row in enumerate(tbl1_rows):
            for j,cell in enumerate(row):
                c = t.cell(i,j)
                c.text = ''
                pr = c.paragraphs[0]
                tr = pr.add_run(cell)
                tr.font.size = Pt(9)
                tr.font.name='Times New Roman'
                if i==0: tr.bold=True
        doc.add_paragraph()
        skip_mode=True
        continue
    if s.startswith('|--') or (skip_mode and s.startswith('|')):
        continue
    if s.startswith('|') and 'Risk state' in s:
        continue
    if skip_mode and s.startswith('**'):
        # after table we may hit markdown table header rows
        pass
    if skip_mode and s.startswith('Two safeguards'):
        skip_mode=False
        add_text_para(doc, s, size=11, space_after=6)
        continue
    # math blocks $$...$$ -> keep as plain text lines
    if s.startswith('$$') :
        add_text_para(doc, s.replace('$$',''), size=11, italic=True, space_after=4)
        continue
    if s.startswith('#') and s.startswith('###'):
        add_heading(doc, s.lstrip('#').strip(), 2)
        continue
    if s:
        add_text_para(doc, s, size=11, space_after=6)

# ---- 3. Results ----
res = open('R2_results_polished.md',encoding='utf-8').read()
add_heading(doc, '3. Results and Analysis', 1)
rb = res[res.find('## 3. Results and Analysis'):]
for ln in rb.split('\n'):
    s=ln.strip()
    if s.startswith('## ') or s.startswith('# ') or s.startswith('>') or s.startswith('#') :
        continue
    if s.startswith('###'):
        add_heading(doc, s.lstrip('#').strip(), 2); continue
    if s.startswith('|') or s.startswith('---') or s.startswith('*(约'):
        continue
    if s:
        add_text_para(doc, s, size=11, space_after=6)

# ---- 4. Discussion ----
dis = open('R2_discussion_polished.md',encoding='utf-8').read()
add_heading(doc, '4. Discussion', 1)
db = dis[dis.find('## 4. Discussion'):]
for ln in db.split('\n'):
    s=ln.strip()
    if s.startswith('## ') or s.startswith('# ') or s.startswith('>'):
        continue
    if s.startswith('###'):
        add_heading(doc, s.lstrip('#').strip(), 2); continue
    if s.startswith('|') or s.startswith('---') or s.startswith('*(约'):
        continue
    if s:
        add_text_para(doc, s, size=11, space_after=6)

# ---- 5. Conclusions ----
con = open('R2_conclusions_polished.md',encoding='utf-8').read()
add_heading(doc, '5. Conclusions', 1)
cb = con[con.find('## 5. Conclusions'):]
for ln in cb.split('\n'):
    s=ln.strip()
    if s.startswith('## ') or s.startswith('# ') or s.startswith('>'):
        continue
    if s.startswith('|') or s.startswith('---') or s.startswith('*(约'):
        continue
    if s:
        # bold the section labels
        if s.startswith('**'):
            add_text_para(doc, s.replace('**',''), bold=False, size=11, space_after=6)
        else:
            add_text_para(doc, s, size=11, space_after=6)

# ---- References ----
doc.add_page_break()
add_heading(doc, 'References', 1)
for ref in open('R2_final_references.txt',encoding='utf-8').read().strip().split('\n'):
    if ref.strip():
        p=doc.add_paragraph()
        r=p.add_run(ref.strip()); r.font.size=Pt(10); r.font.name='Times New Roman'
        p.paragraph_format.space_after=Pt(4)

doc.save('Manuscript_R2_polished.docx')
print('saved Manuscript_R2_polished.docx')
