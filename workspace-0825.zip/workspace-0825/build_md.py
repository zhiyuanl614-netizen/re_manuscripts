import os, re

def load(f): return open(f,encoding='utf-8').read()

ABS = load('R2_abstract_FINAL.txt').strip()
KEYWORDS = 'Urban water supply; Cyber-physical system; Proactive resilience; Early warning management; Graded demand curtailment; Co-simulation.'

def section(file, startmark, title):
    txt = load(file)
    body = txt[txt.find(startmark):]
    # drop audit table markers & header comment block
    # remove the trailing cross-ref audit table if present
    m = re.search(r'\n---\n### 交叉引用核对表.*?\Z', body, re.S)
    if m: body = body[:m.start()]
    out=[]
    for ln in body.split('\n'):
        s=ln.strip()
        if s.startswith('## '): continue
        if s.startswith('>') or s.startswith('*(约'): continue
        if s.startswith('|') or s.startswith('---'): continue
        if '交叉引用核对' in s or '文中引用' in s: continue
        out.append(s)
    return '\n'.join(out)

# Table 1 markdown
TBL1 = """**Table 1.** Operational trigger logic and demand management actions of the EWM (baseline design D3).

| Risk state | Trigger ($S_{pump}=0$) | Retention $\\gamma$ | Operational action and hydraulic effect |
|---|---|---|---|
| NORMAL | $H_{tank} \\ge 5.0$ m | 1.00 | Regular supply; 100% of nominal demand is delivered. |
| WARNING | $H_{tank} < 5.0$ m | 0.70 | Level 1 curtailment; 30% of nonessential demand is shed, which slows the initial storage depletion. |
| ALERT | $H_{tank} < 3.5$ m | 0.40 | Level 2 curtailment; 60% is shed, which preserves pressure above the emergency supply head. |
| CRITICAL | $H_{tank} < 2.0$ m | 0.20 | Level 3 curtailment; 80% is shed, which maintains the minimum emergency head and prevents tank dry out. |
| OUTLET FAILURE | $H_{tank} < 0.5$ m | 0 (physical closure) | The tank outlet is closed to prevent vortex formation, cavitation, and air entrainment; no further supply is possible. |
"""

# Insert Fig image + caption into methods section (Fig1 after 2.1 text, Fig2 after 2.3)
methods = section('R2_methods_polished.md','## 2. Materials and Methods','2. Materials and Methods')

FIG1 = """
![Fig. 1](figures/Fig1.png)

**Fig. 1.** Topology of the Anytown water distribution network, showing junction nodes, pipelines, reservoir R, pumps P1 and P2, and storage tanks T1 and T2.
"""
FIG2 = """
![Fig. 2](figures/Fig2.png)

**Fig. 2.** Architecture of the integrated cyber-physical co-simulation platform. The hierarchical, weakly coupled structure executes the sequence of hydraulics and state write, risk assessment, command issuance, and curtailment enforcement at each 300 s step.
"""
# Insert FIG1 right after the 2.1 first paragraph ends (before 'The diurnal demand'), FIG2 after 2.3 module (ii) description
methods = methods.replace('The tanks therefore operate as hydraulically parallel units whose drawdown is equalized by the looped topology (Assumption A8, Supplementary Table S1). SCADA continuously records tank water levels, nodal pressures, and pump statuses.',
    'The tanks therefore operate as hydraulically parallel units whose drawdown is equalized by the looped topology (Assumption A8, Supplementary Table S1). SCADA continuously records tank water levels, nodal pressures, and pump statuses.\n'+FIG1)
methods = methods.replace('**Sequential execution protocol.**', FIG2+'\n\n**Sequential execution protocol.**')

# Results: insert Fig3..6 at start of each subsection body (after the heading)
results = section('R2_results_polished.md','## 3. Results and Analysis','3. Results and Analysis')
FIG3 = """
![Fig. 3](figures/Fig3.png)

**Fig. 3.** Baseline failure evolution under No EWM. (a) Water level of tank T1. (b) Water level of tank T2, with the 0.5 m outlet isolation threshold and the failure time of 30.17 h in both panels. (c) Nodal pressure map of all junctions ordered by index over time. The white dashed contour marks the 0.10 MPa emergency threshold.
"""
FIG4 = """
![Fig. 4](figures/Fig4.png)

**Fig. 4.** EWM activation and graded control process. (a) Decision trace with warning bands, the ratchet schedule of the demand retention factor, and the outlet failure interval from 34.33 to 48.00 h. (b) Water level of tank T1 under No EWM and EWM. (c) Water level of tank T2 under the two cases, with the warning (W), alert (A), and critical (C) trigger lines and both failure times in panels (b) and (c). (d) Nodal pressure map under EWM.
"""
FIG5 = """
![Fig. 5](figures/Fig5.png)

**Fig. 5.** Dual metric comparison between No EWM and EWM for the canonical scenario. (a) Service value, the fraction of the storage value ceiling captured. (b) Service time, the duration above the 0.10 MPa emergency threshold. Darker bars denote the EWM case in both panels.
"""
FIG6 = """
![Fig. 6](figures/Fig6.png)

**Fig. 6.** Sensitivity of Service time to (a) warning threshold design, (b) tank diameter scale, (c) outage duration, and (d) relative demand load. Values are phase averaged over four fault onset offsets, and error bars denote per phase minimum to maximum ranges. Light curves and markers denote No EWM, and dark curves denote EWM.
"""
results = results.replace('### 3.1 Baseline Failure Evolution under Source Interruption (Fig. 3)',
    '### 3.1 Baseline Failure Evolution under Source Interruption (Fig. 3)\n'+FIG3)
results = results.replace('### 3.2 EWM Activation and Graded Control Process (Fig. 4)',
    '### 3.2 EWM Activation and Graded Control Process (Fig. 4)\n'+FIG4)
results = results.replace('### 3.3 Comparative Resilience Performance (Fig. 5)',
    '### 3.3 Comparative Resilience Performance (Fig. 5)\n'+FIG5)
results = results.replace('### 3.4 Sensitivity and Robustness Analysis (Fig. 6)',
    '### 3.4 Sensitivity and Robustness Analysis (Fig. 6)\n'+FIG6)

# Replace the $$...$$ discrete math blocks with $$ ... $$ for display
def fix_math(txt):
    # convert inline $x$ and $$...$$ — leave as is but ensure display blocks separated
    txt = re.sub(r'\$\$(.*?)\$\$', lambda m: '\n$$\n'+m.group(1).strip()+'\n$$\n', txt, flags=re.S)
    return txt

intro = section('R2_introduction_polished.md','## 1. Introduction','1. Introduction')
disc  = section('R2_discussion_polished.md','## 4. Discussion','4. Discussion')
conc  = section('R2_conclusions_polished.md','## 5. Conclusions','5. Conclusions')

REFS = load('R2_final_references.txt').strip()

md = f"""# Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective

**Manuscript ID FEM-2026-0130 (Revision R2)  |  Journal: ENGINEERING Management**

*Equations are given in LaTeX notation for final formatting in the equation editor. Figures are embedded and may be re-sized or re-numbered at production.*

---

## Abstract
{ABS}

**Keywords:** {KEYWORDS}

---

## 1. Introduction
{intro}

---

## 2. Materials and Methods
{methods}

{TBL1}

---

## 3. Results and Analysis
{results}

---

## 4. Discussion
{disc}

---

## 5. Conclusions
{conc}

---

## References
{REFS}
"""
open('Manuscript_R2_polished.md','w',encoding='utf-8').write(md)
print('MD written, chars:', len(md))
