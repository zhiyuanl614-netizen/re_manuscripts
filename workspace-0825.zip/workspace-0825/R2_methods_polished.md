# R2 修改稿 · Materials and Methods 润色版（Section 2）— 含表格

> 依据：审稿人 1 Comment 3（假设专节+阈值依据）；审稿人 2 Comment 1/2/3/4/5。
> 方法学对齐 Ref-A（输入→处理→输出、模块职责、公式伴随释义）与 Ref-B（前提话术、量化对照）。
> 语言：无破折号、短断言、术语先定义后使用。保留全部关键数据与表格。交叉引用已核对并统一。

---

## 2. Materials and Methods

This section describes the study object and its demand pattern (Section 2.1), specifies the fault scenario and the early warning management (EWM) intervention as an executable control law (Section 2.2), documents the co-simulation platform used for closed-loop evaluation (Section 2.3), defines the dual resilience metrics (Section 2.4), and states the idealized assumptions and their practical implications (Section 2.5).

### 2.1 Study Object

The proposed framework is validated on the Anytown water distribution benchmark network (Walski et al., 1987; Farmani et al., 2005; Siew et al., 2016). As shown in Fig. 1, the physical system comprises 22 junctions, of which 19 carry nonzero base demands, 43 pipelines, one source reservoir (R), a pumping station with two identical parallel pumps (P1 and P2), and two elevated storage tanks (T1 and T2). The tanks sit on opposite sides of the network so that they shave peak loads and stabilize nodal pressures. The two tanks share identical hydraulic settings, with a base elevation of 66.54 m, an internal diameter of 9.95 m, a maximum water depth of 10.67 m, and an initial level of 3.051 m before the disturbance. The tanks therefore operate as hydraulically parallel units whose drawdown is equalized by the looped topology (Assumption A8, Supplementary Table S1). SCADA continuously records tank water levels, nodal pressures, and pump statuses.

The diurnal demand follows an eight-block pattern with a three-hour duration per block and multipliers of (0.7, 0.6, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9), with a peak in the 09:00-12:00 block. This specification follows the benchmark load definition (Walski et al., 1987) and the standard practice of representing 24 h usage through hourly demand multipliers in extended period simulation (Do et al., 2016; Creaco et al., 2020), as adopted in recent smart grid calibration studies (Chew et al., 2022). The pattern is normalized to a unit daily mean, which yields the value weight α(t) ∈ [0.60, 1.30]. The normalized pattern serves two purposes. It drives the scheduled demands and, in Section 2.4.2, weights the service value of delivered water.

### 2.2 Fault Scenario and Early Warning Management

#### 2.2.1 Water Source Interruption Scenario

The disruption is a total water source interruption. All pumps are physically tripped by a SCADA override ($S_{pump}=0$) during $t \in [24, 48]$ h of a 72 h horizon, after which the network is supplied only by gravity discharge from the two tanks. Two comparative cases are simulated. The baseline case (No EWM) keeps demands unrestricted, whereas the intervention case (EWM) activates the early warning logic of Section 2.2.2. All other hydraulic and control rules are identical between the two cases (fairness control, Section 2.2.5).

#### 2.2.2 EWM as an Operational Intervention

The EWM is an active control law rather than a passive alarm system. Each risk state is bound to a specific demand-side action that is executed at the next control step. Once the pumps are physically offline, the tank level $H_{tank}$ is compared with the tiered thresholds, and the demand retention multiplier $\gamma$ is updated according to Table 1. The curtailment is applied uniformly to the scheduled base demand of every junction, so that $q_{j,t} = \gamma \cdot q^{sched}_{j,t}$. No zonal or priority-based differentiation is implemented in the present model ($w_j \equiv 1$), and priority grading is retained as a designed extension point.

**Table 1.** Operational trigger logic and demand management actions of the EWM (baseline design D3).

| Risk state | Trigger ($S_{pump}=0$) | Retention $\gamma$ | Operational action and hydraulic effect |
|---|---|---|---|
| NORMAL | $H_{tank} \ge 5.0$ m | 1.00 | Regular supply; 100% of nominal demand is delivered. |
| WARNING | $H_{tank} < 5.0$ m | 0.70 | Level 1 curtailment; 30% of nonessential demand is shed, which slows the initial storage depletion. |
| ALERT | $H_{tank} < 3.5$ m | 0.40 | Level 2 curtailment; 60% is shed, which preserves pressure above the emergency supply head. |
| CRITICAL | $H_{tank} < 2.0$ m | 0.20 | Level 3 curtailment; 80% is shed, which maintains the minimum emergency head and prevents tank dry out. |
| OUTLET FAILURE | $H_{tank} < 0.5$ m | 0 (physical closure) | The tank outlet is closed to prevent vortex formation, cavitation, and air entrainment; no further supply is possible. |

Two safeguards define the control law. First, a one-way ratchet ($\gamma_t \le \gamma_{t-1}$ within the fault window) prevents control chattering: escalation is immediate, and downgrade occurs only when the fault ends at $t = 48$ h, at which time demands recover to 100%. Second, the local PLC logic is retained. Under normal pumping, the PLC refills the tanks by hysteresis, with pump activation at $H \le 5.0$ m and shutdown at $H \ge 8.0$ m. Demand-side management is initiated only after a confirmed pump trip, so routine level fluctuations never trigger curtailment. The tank outlet guard at 0.5 m applies in both cases as a physical protection rule.

#### 2.2.3 Basis of the Tiered Thresholds

The 5.0/3.5/2.0/0.5 m configuration, defined as the symmetric design D3, combines physical constraints, operational conventions, and numerical verification. First, the 0.5 m outlet failure threshold corresponds to the crown elevation of the tank outlet pipelines; water levels below this elevation induce vortex formation and air entrainment, which necessitates isolation. Second, the WARNING threshold of 5.0 m coincides with the baseline PLC pump activation setpoint, which ensures consistency between routine and emergency operation. Third, the ALERT threshold (3.5 m) and the CRITICAL threshold (2.0 m) equally partition the usable depth between 5.0 m and 0.5 m, so that curtailment is introduced progressively.

These thresholds are operational rules rather than statutory levels. The statutory emergency service head of 0.10 MPa specified in GB 50013-2018 (MOHURD, 2018) serves only as the pressure threshold of the Service time metric (Section 2.4.1). The sensitivity of the conclusions to this configuration is verified numerically with designs D1 to D5 (Section 3.4).

#### 2.2.4 Sensitivity Experimental Design

To test robustness beyond the canonical scenario, one-factor scans are conducted across four dimensions: warning threshold design (D1 to D5), tank diameter (0.6× to 1.4×), outage duration (12 to 48 h), and relative demand load (0.6× to 1.4×). Each configuration is evaluated at four fault onset phases (0, 6, 12, and 18 h offsets against the 3 h demand blocks), which yields 264 paired runs. Results are reported as phase-averaged means with per-phase minimum-to-maximum ranges (Section 3.4).

#### 2.2.5 Fairness Control

Both cases are evaluated under strictly identical conditions: the same WNTR and EPANET 2.2 solver in pressure-driven analysis (PDA) mode, the same topology, roughness, elevations, and initial levels (3.051 m), the same timestep (Δt = 300 s), the same disruption window (24 to 48 h), the same outlet closure rule (below 0.5 m), and the same baseline system head (51.95 m, approximately 0.51 MPa). The abrupt baseline pressure collapse is not an imposed binary failure rule. It emerges from the PDA solution under unrestricted full demand once the tanks are isolated, and the same rule applies to the EWM case. The single controlled variable is the demand multiplier: $\gamma \equiv 1.00$ in the baseline, compared with the state-dependent schedule of Table 1 in the EWM case.

### 2.3 Co-simulation Platform

The evaluation is performed on a hierarchical, weakly coupled cyber-physical co-simulation platform implemented in Python 3.13 (Fig. 2). The architecture comprises three modules.

**(i) Physical simulation module (WNTR and EPANET 2.2).** The hydraulic kernel (Klise et al., 2017; Rossman et al., 2020; Walski et al., 2003) solves the network equations in pressure-driven mode over a fixed timestep of Δt = 300 s for a 72 h horizon, which corresponds to 864 steps per run. The module produces the state trajectory of tank levels $H$, nodal pressures $P$, and pump flows $Q$ under the scenario of Section 2.2.1. The delivered nodal flow follows the pressure-driven relationship

$$q_{j}(t) = \begin{cases} q^{sched}_{j}(t), & H_j \ge H^{req} \\ q^{sched}_{j}(t)\left(\frac{H_j - H^{min}}{H^{req} - H^{min}}\right)^{\alpha_{exp}}, & H^{min} < H_j < H^{req} \\ 0, & H_j \le H^{min} \end{cases}$$

where $H_j$ is the nodal head, $H^{req}$ is the required service head, $H^{min}$ is the minimum service head, and $\alpha_{exp}$ is the pressure exponent.

**(ii) Time-synchronized SQLite database (coupling layer).** The physical and cyber domains exchange information exclusively through a SQLite database, which ensures consistent and fully auditable information mapping. The database contains a physical state table ($H$, $P$, and $Q$), an event and transition log with timestamps for early warning records and control actions, and performance records of delivered and required flows at each step, from which the metrics of Section 2.4 are computed. This weak coupling lets the time difference window between cyber perception and hydraulic degradation be measured directly from the event logs.

**(iii) Cyber SCADA module.** The module emulates an industrial monitoring framework. It performs real-time state acquisition, the multi-stage risk assessment of Table 1 including the ratchet constraint, and the issuance of demand retention commands.

**Sequential execution protocol.** Each 300 s step executes four operations. (1) The WNTR kernel invokes EPANET 2.2 and writes the resulting states to the database. (2) The cyber module retrieves the states and performs risk assessment to determine the operational level. (3) State transitions are timestamped and the updated demand retention multiplier is issued. (4) The curtailment is applied to the scheduled demands of the next hydraulic solve. The loop proceeds to 72 h, after which the resilience metrics are computed directly from the database. Platform fidelity is verified by a mass balance audit: the ratio of delivered volume to storage depletion remains at η ≈ 1.0006 across runs, which confirms that the coupling introduces no artificial gains in water volume.

### 2.4 Resilience Evaluation Metrics

To distinguish pressure maintenance from actual water delivery, a minimal dual metric framework is adopted, consisting of Service time ($T_{press}$, temporal dimension) and Service value ($R_w$, service value dimension). This distinction builds on reliability indicators evaluated under pressure-driven models (Liserra et al., 2014) and on pressure-dependent resilience assessment (Roach and Kapelan, 2017). The figure axes use these names. Both metrics are computed from the co-simulation database and are therefore fully reproducible.

#### 2.4.1 Service Time ($T_{press}$)

Service time quantifies how long emergency-grade supply is physically sustained.

$$T_{press} = \int_{t_d}^{t_r} I\left(\bar{P}(t) \ge P_{min}\right)\, dt$$

where $I(\cdot)$ is the indicator function, $\bar{P}(t)$ is the network average nodal pressure, $t_d = 24$ h is the fault initiation time, $t_r$ is the restoration time, and $P_{min} = 0.10$ MPa is the emergency service threshold specified in GB 50013-2018 (approximately 10.2 m).

#### 2.4.2 Service Value ($R_w$)

A duration-only index cannot distinguish water delivered during critical high-demand periods from water consumed in low-value night hours. Service value is therefore defined as the demand-weighted delivered service normalized by the value ceiling of the available storage:

$$R_w = \frac{W}{S^{*} \cdot \alpha_{max}} = \frac{\int_{t_d}^{t_r}\sum_j w_j \, q_{del,j}(t)\cdot\alpha(t)\,dt}{S^{*}\cdot\alpha_{max}}$$

The numerator $W$ weights each delivered cubic meter by the demand pattern value α(t) of its delivery timing, using the normalized Anytown factors with α ∈ [0.60, 1.30] and a unit daily mean. The node weights $w_j$ equal unity in this study and constitute a designed extension point for priority-graded dispatch. The denominator is the storage value ceiling. Here $S^{*}$ is the usable tank storage at fault onset (the volume above the 0.05 m minimum level, 1,156.4 m³ in the baseline case, captured from the SCADA record at runtime), and $\alpha_{max} = 1.30$ is the highest demand block weight. The metric therefore satisfies $R_w \in [0, 1]$ by construction.

Because the anchor is physical and scenario adaptive, and is recomputed for every fault onset phase, tank scale, and demand load, it cannot be inflated by demand suppression. Curtailing demand only removes volume from the numerator, so pressure preservation without water delivery cannot increase $R_w$.

#### 2.4.3 Reporting Rules

Three reporting rules apply. First, $T_{press}$ serves as the robustness metric and is scanned across the four sensitivity dimensions (Section 3.4). Second, $R_w$ is reported for the canonical alignment, in which the fault onset occurs at 24 h, and is interpreted as the fraction of the storage value potential actually captured; cross-scenario comparison is made only through the within-scenario EWM-versus-baseline change. Third, sensitivity results are phase-averaged over the four fault onset offsets with per-phase ranges disclosed, which eliminates alignment artifacts between the fault onset and the 3 h demand blocks.

### 2.5 Model Assumptions

To isolate the effect of the EWM intervention, the co-simulation model adopts a set of idealized assumptions concerning the fixed 300 s time step, the clipping of sub-zero pressures in the network average, error-free and continuous sensing, lossless and instantaneous communication, the instantaneous and uniform execution of demand curtailment, demand-pattern-based value weighting, a tank-only storage anchor, hydraulic symmetry between the two tanks, a deterministic step-function outage, the absence of water quality deterioration, and binary (on/off) pump control. The complete list, together with the practical impact and the feasible engineering mitigation for each assumption, is provided in Supplementary Table S1 (assumptions A1 to A11). These simplifications act against the intervention rather than in its favour: the resulting pressure and Service-value gains are conservative, and their robustness is verified by the multi-factor sensitivity analysis (Section 3.4) and the mass balance audit (η ≈ 1.0006, Section 2.3).

---

### 交叉引用核对表（润色版 vs 文献语境）

| 文中引用 | 指向 | 核对结果 |
|---|---|---|
| (Assumption A8, Supplementary Table S1) | A8 = Hydraulic symmetry（equalized drawdown），已移至 SI | ✅ 编号一致，指向 SI |
| in Section 2.4.2 | 服务价值的 α(t) 加权 | ✅ 已由 2.4 精确为 2.4.2 |
| (Section 2.2.2) | EWM 激活逻辑 | ✅ 准确 |
| (fairness control, Section 2.2.5) | 公平控制 | ✅ 准确 |
| (Section 2.4.1) | Service time 指标 | ✅ 准确 |
| (Section 3.4) | 敏感性分析 | ✅ 准确 |
| (Section 2.5) + (Section 2.2.5) | 理想假设专节 / 公平控制 | ✅ 准确 |
| Table 1（保留正文） | EWM 触发逻辑表 | ✅ 保留在正文 |
| Supplementary Table S1 | 完整假设明细 A1–A11（含影响+缓解） | ✅ 已移入 SI |
