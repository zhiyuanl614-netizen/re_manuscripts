# Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective

**Manuscript ID FEM-2026-0130 (Revision R2)  |  Journal: ENGINEERING Management**

*Equations are given in LaTeX notation for final formatting in the equation editor. Figures are embedded and may be re-sized or re-numbered at production.*

---

## Abstract
Proactive resilience of urban water supply systems under a complete water-source outage is an important but challenging task that supports emergency dispatch and service continuity. Despite growing research on water supply cyber-physical systems and on resilience assessment, existing studies largely stop at retroactive evaluation and seldom translate early warning perception into executable control actions. Such control actions are needed to exploit the mismatch between fast cyber sensing and slow hydraulic degradation. To address this limitation, this study proposes a three-layer cyber-physical co-simulation framework. This framework couples pressure-driven hydraulics with SCADA-informed demand management and binds graded tank-level warning states to demand retention multipliers under a one-way ratchet. Moreover, the framework introduces two complementary metrics that jointly evaluate pressure compliance and delivered water service. A case study of the Anytown benchmark network under a complete 24-hour water-source outage was conducted, which demonstrated the efficacy of the proposed framework. The results showed that the intervention postpones outlet failure and extends emergency-grade supply, and that the gain stems from the temporal reallocation of a fixed storage rather than from water creation. The benefit remains positive across varied warning thresholds, storage capacity, outage duration, and demand load. The proposed framework can overcome the passive, purely physical-layer limitation of current resilience practice and provide a foundation for information-mediated emergency dispatch in smart water utilities.

**Keywords:** Urban water supply; Cyber-physical system; Proactive resilience; Early warning management; Graded demand curtailment; Co-simulation.

---

## 1. Introduction

Urban water supply systems are critical lifeline infrastructure, and their digital transformation is converting them into cyber-physical systems (CPS). Reservoirs, pumping stations, distribution mains, and storage tanks are increasingly integrated with supervisory control and data acquisition (SCADA) systems, programmable logic controllers, and wireless sensing (Alexandra et al., 2023; Ande et al., 2020; Bhardwaj et al., 2021; Khan et al., 2020; Liao et al., 2025; Mohebbi et al., 2020; Yadav and Paul, 2021), and this trajectory extends toward network-scale digital twins that synchronize hydraulic models with live telemetry (Bonilla et al., 2022). The integration is deeper than instrumentation. It creates a structural opportunity to act on information about a degrading network before the failure is physically complete.

Research on urban water supply CPS has concentrated on perception rather than action. One stream advances cybersecurity, anomalous-condition detection, and leak localization (Hassanzadeh et al., 2020; Taormina et al., 2018; Xu et al., 2020), with experimental demonstrations of stealthy deception attacks on water SCADA confirming both the severity of the threat and the feasibility of telemetry-level detection (Amin et al., 2013). These studies strengthen detection and diagnosis, yet they typically treat the cyber layer as an observatory, and rarely link its output to hydraulic control during a physical interruption. A second stream develops optimization and predictive control of distribution networks, including economic model-predictive operation of pumps and tanks (Wang et al., 2017) and resilience platforms that couple simulation engines with disruption and repair modeling (Klise et al., 2017). These approaches are powerful under normal operation, but emergency operation under a total source loss follows fixed protection logic rather than graded, warning-informed dispatch. The gap between the two streams is therefore specific: cyber observation and proactive operational resilience remain separate stages rather than one closed loop.

Resilience assessment of water distribution networks has matured in parallel, yet its indicators are not designed for demand-managed emergencies. Topological measures capture structural connectivity (Cai et al., 2021; Meng et al., 2018), whereas hydraulic measures relate performance to pressure service (Feng et al., 2025; Zhang et al., 2022); classical frameworks formalized reliability against threshold standards (Hashimoto et al., 1982) and resilience as functional integration across failure and recovery (Cimellaro et al., 2010). Butler et al. (2017) organized this thinking into the Safe and SuRe approach and argued explicitly for planned interventions rather than passive capacity. Two limitations persist for the problem addressed here. First, assessments are typically post hoc, describing consequences rather than improving them. Second, a pressure-only assessment can overestimate performance under demand reduction, because pressure can be preserved while the volume delivered to users decreases. Emergency evaluation therefore needs to join pressure compliance with delivered water service in one metric framework.

The underused resource is the timescale mismatch between cyber sensing and hydraulic deterioration. SCADA telemetry reports system states within seconds, whereas tank drawdown and head loss develop over hours, so deteriorating conditions can be detected before irreversible failure occurs (Arghandeh et al., 2016; Hassanzadeh et al., 2020). Existing early warning applications, however, remain at alarm generation and risk-state classification (Juan García et al., 2017; Liu and Mijic, 2025); they rarely specify how a warning state is translated into an executable control rule. Meanwhile, current practice for catastrophic source interruptions still follows a passive fail-and-repair paradigm (Holling, 1973; Hosseini et al., 2016), during which unregulated demand rapidly depletes emergency storage and produces pressure decay, air binding, and extensive service interruption (He et al., 2024; Wu and Li, 2021). When warning states are bound to timely demand actions, this mismatch yields an additional operating window. We define that window as the *time difference window*, the extra service time obtained by intervening in a slow hydraulic degradation process through rapid cyber observation.

Unlike studies of anomaly detection, open-loop resilience assessment, or alarm generation, this study integrates rapid cyber observation, dual-metric evaluation, and graded emergency dispatch under a complete source interruption. Three concerns organize the work, condensed from the gaps above. First, the problem to be solved is the post-outage collapse caused by uncurtailed tank depletion, in which pressure and delivery fail together once storage is exhausted. Second, the model to be established is a three-layer, weakly coupled co-simulation platform linking an EPANET 2.2 pressure-driven kernel to a SCADA module through a time-synchronized database, and within it an executable early warning management (EWM) rule that binds graded tank-level warning states to demand retention multipliers under a one-way ratchet. The mechanism to be revealed is the information-mediated origin of the time difference window, its quantification through metrics that join pressure compliance with delivered water, and its operational boundaries under varying warning thresholds, storage capacity, outage duration, and demand load. Together these objectives support the transition of urban water utilities from post-event repair toward proactive resilience management.

The remainder of this paper is organized as follows. Section 2 describes the study object, the fault scenario, and the EWM intervention, and documents the co-simulation platform, the resilience metrics, and the idealized assumptions. Section 3 presents the baseline failure evolution, the graded control process, the comparative performance, and the sensitivity analysis. Section 4 discusses the mechanism, the cyber-physical origin of the time difference window, the engineering selection of thresholds, and the limitations and future directions. Section 5 concludes the paper.


---

## 2. Materials and Methods

This section describes the study object and its demand pattern (Section 2.1), specifies the fault scenario and the early warning management (EWM) intervention as an executable control law (Section 2.2), documents the co-simulation platform used for closed-loop evaluation (Section 2.3), defines the dual resilience metrics (Section 2.4), and states the idealized assumptions and their practical implications (Section 2.5).

### 2.1 Study Object

The proposed framework, implemented as the co-simulation platform described in Section 2.3, is validated on the Anytown water distribution benchmark network (Walski et al., 1987; Farmani et al., 2005; Siew et al., 2016). As shown in Fig. 1, the physical system comprises 22 junctions, of which 19 carry nonzero base demands, 43 pipelines, one source reservoir (R), a pumping station with two identical parallel pumps (P1 and P2), and two elevated storage tanks (T1 and T2). The tanks sit on opposite sides of the network so that they shave peak loads and stabilize nodal pressures. The two tanks share identical hydraulic settings, with a base elevation of 66.54 m, an internal diameter of 9.95 m, a maximum water depth of 10.67 m, and an initial level of 3.051 m before the disturbance. The tanks therefore operate as hydraulically parallel units whose drawdown is equalized by the looped topology (Assumption A8, Supplementary Table S1). SCADA continuously records tank water levels, nodal pressures, and pump statuses.

![Fig. 1](figures/Fig1.png)

**Fig. 1.** Topology of the Anytown water distribution network, showing junction nodes, pipelines, reservoir R, pumps P1 and P2, and storage tanks T1 and T2.


The diurnal demand follows an eight-block pattern with a three-hour duration per block and multipliers of (0.7, 0.6, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9), with a peak in the 09:00-12:00 block. This specification follows the benchmark load definition (Walski et al., 1987) and the standard practice of representing 24 h usage through hourly demand multipliers in extended period simulation (Do et al., 2016; Creaco et al., 2020), as adopted in recent smart grid calibration studies (Chew et al., 2022). The pattern is normalized to a unit daily mean, which yields the value weight α(t) ∈ [0.60, 1.30]. The normalized pattern serves two purposes. It drives the scheduled demands and, in Section 2.4.2, weights the service value of delivered water.

### 2.2 Fault Scenario and Early Warning Management

#### 2.2.1 Water Source Interruption Scenario

The disruption is a total water source interruption. All pumps are physically tripped by a SCADA override ($S_{pump}=0$) during $t \in [24, 48]$ h of a 72 h horizon, after which the network is supplied only by gravity discharge from the two tanks. Two comparative cases are simulated. The baseline case (No EWM) keeps demands unrestricted, whereas the intervention case (EWM) activates the early warning logic of Section 2.2.2. All other hydraulic and control rules are identical between the two cases (fairness control, Section 2.2.5).

#### 2.2.2 EWM as an Operational Intervention

The EWM is an active control law rather than a passive alarm system. Each risk state is bound to a specific demand-side action that is executed at the next control step. Once the pumps are physically offline, the tank level $H_{tank}$ is compared with the tiered thresholds, and the demand retention multiplier $\gamma$ is updated according to Table 1. The curtailment is applied uniformly to the scheduled base demand of every junction, so that $q_{j,t} = \gamma \cdot q^{sched}_{j,t}$. No zonal or priority-based differentiation is implemented in the present model ($w_j \equiv 1$), and priority grading is retained as a designed extension point.

**Table 1.** Operational trigger logic and demand management actions of the EWM (baseline design D3).


Two safeguards define the control law. First, a one-way ratchet ($\gamma_t \le \gamma_{t-1}$ within the fault window) prevents control chattering: escalation is immediate, and downgrade occurs only when the fault ends at $t = 48$ h, at which time demands recover to 100%. Second, the local PLC logic is retained. Under normal pumping, the PLC refills the tanks by hysteresis, with pump activation at $H \le 5.0$ m and shutdown at $H \ge 8.0$ m. Demand-side management is initiated only after a confirmed pump trip, so routine level fluctuations never trigger curtailment. The tank outlet guard at 0.5 m applies in both cases as a physical protection rule.

#### 2.2.3 Basis of the Tiered Thresholds

The 5.0/3.5/2.0/0.5 m configuration, defined as the symmetric design D3, combines physical constraints, operational conventions, and numerical verification. First, the 0.5 m outlet failure threshold corresponds to the crown elevation of the tank outlet pipelines; water levels below this elevation induce vortex formation and air entrainment, which necessitates isolation. Second, the WARNING threshold of 5.0 m coincides with the baseline PLC pump activation setpoint, which ensures consistency between routine and emergency operation. Third, the ALERT threshold (3.5 m) and the CRITICAL threshold (2.0 m) equally partition the usable depth between 5.0 m and 0.5 m, so that curtailment is introduced progressively.

These thresholds are operational rules rather than statutory levels. The statutory emergency service head of 0.10 MPa specified in GB 50013-2018 (MOHURD, 2018) serves only as the pressure threshold of the Service time metric (Section 2.4.1). The sensitivity of the conclusions to this configuration is verified numerically with designs D1 to D5 (Section 3.4).

#### 2.2.4 Sensitivity Experimental Design

To test robustness beyond the canonical scenario, one-factor scans are conducted across four dimensions: warning threshold design (D1 to D5), tank diameter (0.6× to 1.4×), outage duration (12 to 48 h), and relative demand load (0.6× to 1.4×). Each configuration is evaluated at four fault onset phases (0, 6, 12, and 18 h offsets against the 3 h demand blocks), which yields 264 paired runs. Results are reported as phase-averaged means with per-phase minimum-to-maximum ranges (Section 3.4).

#### 2.2.5 Fairness Control

Both cases are evaluated under strictly identical conditions: the same WNTR and EPANET 2.2 solver in pressure-driven analysis (PDA) mode, the same topology, roughness, elevations, and initial levels (3.051 m), the same timestep (Δt = 300 s), the same disruption window (24 to 48 h), the same outlet closure rule (below 0.5 m), and the same baseline system head (51.95 m, approximately 0.51 MPa). The abrupt baseline pressure collapse is not an imposed binary failure rule. It emerges from the PDA solution under unrestricted full demand once the tanks are isolated, and the same rule applies to the EWM case. The single controlled variable is the demand multiplier: $\gamma \equiv 1.00$ in the baseline, compared with the state-dependent schedule of Table 1 in the EWM case.

### 2.3 Co-simulation Platform

The framework proposed in this study is instantiated as the co-simulation platform described below. The evaluation is performed on a hierarchical, weakly coupled cyber-physical co-simulation platform implemented in Python 3.13 (Fig. 2). The architecture comprises three modules.

**(i) Physical simulation module (WNTR and EPANET 2.2).** The hydraulic kernel (Klise et al., 2017; Rossman et al., 2020; Walski et al., 2003) solves the network equations in pressure-driven mode over a fixed timestep of Δt = 300 s for a 72 h horizon, which corresponds to 864 steps per run. The module produces the state trajectory of tank levels $H$, nodal pressures $P$, and pump flows $Q$ under the scenario of Section 2.2.1. The delivered nodal flow follows the pressure-driven relationship

$$q_{j}(t) = \begin{cases} q^{sched}_{j}(t), & H_j \ge H^{req} \\ q^{sched}_{j}(t)\left(\frac{H_j - H^{min}}{H^{req} - H^{min}}\right)^{\alpha_{exp}}, & H^{min} < H_j < H^{req} \\ 0, & H_j \le H^{min} \end{cases}$$

where $H_j$ is the nodal head, $H^{req}$ is the required service head, $H^{min}$ is the minimum service head, and $\alpha_{exp}$ is the pressure exponent.

**(ii) Time-synchronized SQLite database (coupling layer).** The physical and cyber domains exchange information exclusively through a SQLite database, which ensures consistent and fully auditable information mapping. The database contains a physical state table ($H$, $P$, and $Q$), an event and transition log with timestamps for early warning records and control actions, and performance records of delivered and required flows at each step, from which the metrics of Section 2.4 are computed. This weak coupling lets the time difference window between cyber perception and hydraulic degradation be measured directly from the event logs.

**(iii) Cyber SCADA module.** The module emulates an industrial monitoring scheme. It performs real-time state acquisition, the multi-stage risk assessment of Table 1 including the ratchet constraint, and the issuance of demand retention commands.


![Fig. 2](figures/Fig2.png)

**Fig. 2.** Architecture of the integrated cyber-physical co-simulation platform. The hierarchical, weakly coupled structure executes the sequence of hydraulics and state write, risk assessment, command issuance, and curtailment enforcement at each 300 s step.


**Sequential execution protocol.** Each 300 s step executes four operations. (1) The WNTR kernel invokes EPANET 2.2 and writes the resulting states to the database. (2) The cyber module retrieves the states and performs risk assessment to determine the operational level. (3) State transitions are timestamped and the updated demand retention multiplier is issued. (4) The curtailment is applied to the scheduled demands of the next hydraulic solve. The loop proceeds to 72 h, after which the resilience metrics are computed directly from the database. Platform fidelity is verified by a mass balance audit: the ratio of delivered volume to storage depletion remains at η ≈ 1.0006 across runs, which confirms that the coupling introduces no artificial gains in water volume.

### 2.4 Resilience Evaluation Metrics

To distinguish pressure maintenance from actual water delivery, a minimal dual metric framework is adopted, consisting of Service time ($T_{press}$, temporal dimension) and Service value ($R_w$, service value dimension). This distinction builds on reliability indicators evaluated under pressure-driven models (Liserra et al., 2014) and on pressure-dependent resilience assessment (Roach and Kapelan, 2017). The figure axes use these names. Both metrics are computed from the co-simulation database and are therefore fully reproducible.

#### 2.4.1 Service Time ($T_{press}$)

Service time quantifies how long emergency-grade supply is physically sustained.

$$T_{press} = \int_{t_d}^{t_r} I\left(\bar{P}(t) \ge P_{min}\right)\, dt$$

where $I(\cdot)$ is the indicator function, $\bar{P}(t)$ is the network average nodal pressure, $t_d = 24$ h is the fault initiation time, $t_r$ is the restoration time, and $P_{min} = 0.10$ MPa is the emergency service threshold specified in GB 50013-2018 (approximately 10.2 m).

#### 2.4.2 Service Value ($R_w$)

A duration-only index cannot distinguish water delivered during critical high-demand periods from water consumed in low-value night hours. Service value is therefore defined as the demand-weighted delivered service normalized by the value ceiling of the available storage:

$$R_w = \frac{W}{S^{*} \cdot \alpha_{max}} = \frac{\int_{t_d}^{t_r}\sum_j w_j \, q_{del,j}(t)\cdot\alpha(t)\,dt}{S^{*}\cdot\alpha_{max}}$$

The numerator $W$ weights each delivered cubic meter by the demand pattern value α(t) of its delivery timing, using the normalized Anytown factors with α ∈ [0.60, 1.30] and a unit daily mean. The node weights $w_j$ equal unity in this study and constitute a designed extension point for priority-graded dispatch. The denominator is the storage value ceiling. Here $S^{*}$ is the usable tank storage at fault onset (the volume above the 0.05 m minimum level, 1,156.4 m³ in the baseline case, captured from the SCADA record at runtime), and $\alpha_{max} = 1.30$ is the highest demand block weight. The metric therefore satisfies $R_w \in [0, 1]$ by construction.

Because the anchor is physical and scenario adaptive, and is recomputed for every fault onset phase, tank scale, and demand load, it cannot be inflated by demand suppression. Curtailing demand only removes volume from the numerator, so pressure preservation without water delivery cannot increase $R_w$.

#### 2.4.3 Reporting Rules

Three reporting rules apply. First, $T_{press}$ serves as the robustness metric and is scanned across the four sensitivity dimensions (Section 3.4). Second, $R_w$ is reported for the canonical alignment, in which the fault onset occurs at 24 h, and is interpreted as the fraction of the storage value potential actually captured; cross-scenario comparison is made only through the within-scenario EWM-versus-baseline change. Third, sensitivity results are phase-averaged over the four fault onset offsets with per-phase ranges disclosed, which eliminates alignment artifacts between the fault onset and the 3 h demand blocks.

### 2.5 Model Assumptions

To isolate the effect of the EWM intervention, the co-simulation model adopts a set of idealized assumptions concerning the fixed 300 s time step, the clipping of sub-zero pressures in the network average, error-free and continuous sensing, lossless and instantaneous communication, the instantaneous and uniform execution of demand curtailment, demand-pattern-based value weighting, a tank-only storage anchor, hydraulic symmetry between the two tanks, a deterministic step-function outage, the absence of water quality deterioration, and binary (on/off) pump control. The complete list, together with the practical impact and the feasible engineering mitigation for each assumption, is provided in Supplementary Table S1 (assumptions A1 to A11). These simplifications act against the intervention rather than in its favour: the resulting pressure and Service-value gains are conservative, and their robustness is verified by the multi-factor sensitivity analysis (Section 3.4) and the mass balance audit (η ≈ 1.0006, Section 2.3).


---

## 3. Results and Analysis

### 3.1 Baseline Failure Evolution under Source Interruption (Fig. 3)

![Fig. 3](figures/Fig3.png)

**Fig. 3.** Baseline failure evolution under No EWM. (a) Water level of tank T1. (b) Water level of tank T2, with the 0.5 m outlet isolation threshold and the failure time of 30.17 h in both panels. (c) Nodal pressure map of all junctions ordered by index over time. The white dashed contour marks the 0.10 MPa emergency threshold.


Under No EWM, the network degrades from cyclic operation to complete collapse within a single control step once the storage is exhausted (Fig. 3(a, b)). In normal operation the PLC cycles tank levels between 5.0 m and 8.0 m; after the pumps trip at 24 h, the tanks drain in parallel and their levels remain within 0.29 m, averaging 0.09 m over the outage. This follows from the identical tank settings and the equalizing effect of the looped topology (Assumption A8, Supplementary Table S1). Both tanks close their outlets at 30.17 h in the same 300 s step, and interpolation within the step gives a stagger of only 2.6 min; the outlet valves then close to prevent air entrainment and cavitation. The simultaneity is therefore a physical result of symmetric drawdown rather than a modeling artifact (Section 4.2).


Nodal pressures remain above the 0.10 MPa emergency threshold at every junction until isolation (Fig. 3(c)). Before isolation, pressures degrade non-uniformly in magnitude, but all 22 junctions stay above the threshold. Upon outlet closure the network average pressure falls from 0.44 MPa to 0.00 MPa within one step, and every junction crosses the threshold at 30.25 h. No spatial sequence of failure exists, because the whole network is fed by the same two tanks. The interruption spans the morning peak block (09:00 to 12:00, 33 to 36 h), and pressures recover network-wide at 48.08 h once pumping resumes. The baseline Service time therefore equals 6.17 h, the interval between fault initiation and outlet failure.


### 3.2 EWM Activation and Graded Control Process (Fig. 4)

![Fig. 4](figures/Fig4.png)

**Fig. 4.** EWM activation and graded control process. (a) Decision trace with warning bands, the ratchet schedule of the demand retention factor, and the outlet failure interval from 34.33 to 48.00 h. (b) Water level of tank T1 under No EWM and EWM. (c) Water level of tank T2 under the two cases, with the warning (W), alert (A), and critical (C) trigger lines and both failure times in panels (b) and (c). (d) Nodal pressure map under EWM.


The EWM converts the warning states into three graded curtailment actions without control chattering (Fig. 4(a)). After the pumps trip at 24 h, the logic escalates to WARNING at 26.08 h when the T2 level falls to 4.97 m, to ALERT at 28.00 h at 3.48 m, and to CRITICAL at 30.83 h when the T1 level reaches 2.00 m. The one-way ratchet holds each state for the remainder of the outage, so the event is governed by exactly three transitions. The demand retention multiplier follows 1.00, 0.70, 0.40, and 0.20, returns to 1.00 at 48.00 h, and is zeroed over the final interval, because the closed outlets remove the ability to supply regardless of the command.


The curtailment commands are executed faithfully and convert directly into storage preservation (Fig. 4(b, c)). In each segment the delivered volume matches or slightly exceeds the scheduled curtailed demand, and the accumulated shortfall before outlet failure is 0 m³. The drawdown rate of both tanks falls after each trigger, and outlet failure is postponed from 30.17 h to 34.33 h, an extension of 4.17 h, with a within-step stagger of 1.6 min. Graded curtailment consequently delays the network-wide pressure collapse by the same interval and restores partial coverage of the morning peak (Fig. 4(d)). All junctions remain above the threshold until 34.42 h, recovery occurs at 48.08 h, and during the peak block the EWM case delivers 97.9 m³, about 9% of the block requirement, whereas the baseline delivers none.


### 3.3 Comparative Resilience Performance (Fig. 5)

![Fig. 5](figures/Fig5.png)

**Fig. 5.** Dual metric comparison between No EWM and EWM for the canonical scenario. (a) Service value, the fraction of the storage value ceiling captured. (b) Service time, the duration above the 0.10 MPa emergency threshold. Darker bars denote the EWM case in both panels.


The EWM improves both resilience metrics substantially (Fig. 5). Service time increases from 6.17 h to 10.33 h, a relative extension of 67.6%, and Service value increases from 0.50 to 0.61, an improvement of 23.0% in time-weighted service. The weighted delivered service W rises from 745.3 to 916.2 m³·pattern, while both cases share the same storage value ceiling of 1,503.4 m³·pattern, the product of the onset storage S* = 1,156.4 m³ and the maximum block weight α_max = 1.30. Under this anchor the baseline captures 49.6% of the fixed storage value potential and the EWM case captures 60.9%. The two metrics are therefore complementary rather than redundant, because Service time measures pressure compliance and Service value measures delivery weighted by timing.


The volumetric audit confirms that the gain arises from temporal reallocation rather than water creation. Total delivered volume is nearly unchanged, at 1,095.2 m³ (No EWM) and 1,088.3 m³ (EWM), a difference of 0.6%. Within this nearly fixed volume, the physically unserved portion, the demand not delivered after outlet failure, decreases from 5,295.3 to 3,947.3 m³, and the morning peak block receives partial coverage. The EWM therefore trades a marginal reduction in total throughput for a 4.17 h postponement of failure and a redistribution of delivery toward high-value blocks. This dual accounting of pressure compliance and delivered service follows recent evaluations of water-cutoff response measures using pressure-driven analysis (Madiziyire et al., 2025). The magnitude of the Service value gain depends on the alignment between fault onset and demand blocks, so Service value is reported for the canonical alignment according to the reporting rules of Section 2.4.3.


### 3.4 Sensitivity and Robustness Analysis (Fig. 6)

![Fig. 6](figures/Fig6.png)

**Fig. 6.** Sensitivity of Service time to (a) warning threshold design, (b) tank diameter scale, (c) outage duration, and (d) relative demand load. Values are phase averaged over four fault onset offsets, and error bars denote per phase minimum to maximum ranges. Light curves and markers denote No EWM, and dark curves denote EWM.


Service time remains positive in sign across all four dimensions (Fig. 6). Earlier thresholds monotonically extend the EWM Service time (Fig. 6(a)); from the latest liberal design D1 to the earliest conservative design D5, it increases from 7.54 h to 10.94 h, because earlier curtailment reliably extends pressure compliance. The baseline stays at 4.27 h, since the threshold designs affect only the EWM logic, so D3 is a balanced compromise rather than a sharp optimum. The benefit also grows as passive storage becomes less adequate (Fig. 6(b)): the Service time gain increases from +1.98 h at a tank diameter of 0.6× to +10.10 h at 1.4×. Under the most storage-constrained condition the EWM more than doubles the Service time from 1.44 h to 3.42 h, so the gain is largest where passive storage is least able to buffer the disruption.


The EWM provides a stable emergency window regardless of outage length (Fig. 6(c)). For outages of 16 h and longer the baseline Service time saturates at 4.27 h, because the tanks are fully drained before the outage ends, whereas the EWM gain remains stable at about +5.1 h across this range. The gain stays positive across the full range of demand loads (Fig. 6(d)), rising from 5.58 h to 14.19 h at a load of 0.6× and from 2.73 h to 6.40 h at 1.4×. The largest relative extension occurs under light load, where unrestricted consumption would otherwise deplete storage most rapidly. Taken together, these results support the EWM as a dependable duration-extending intervention, and the threshold response indicates that warning levels should be calibrated to local tank capacity, outage duration, and demand load rather than transferred between networks.


---

## 4. Discussion

This study established a weakly coupled cyber-physical co-simulation framework that converts early warning perception into graded demand curtailment, and quantified its effect on proactive resilience under a total water source interruption. Three findings emerge. First, early warning management (EWM) does not create water; it reallocates a fixed storage in time, extending Service time by 67.6% and Service value by 23.0% at a volumetric cost of only 0.6%. Second, the 4.17 h time difference window is information mediated rather than storage driven, because identical storage fails at 30.17 h without the control loop and at 34.33 h with it. Third, the Service time gain is robust in sign across four sensitivity dimensions, whereas the Service value gain depends on the alignment between fault onset and demand blocks. These findings position graded early warning as a middle-based intervention, situated between the capacity enhancement of supply-side measures and the hardening of physical infrastructure.


### 4.1 Mechanism of Resilience Enhancement: Service Redistribution

The EWM reallocates a fixed volume of stored water in time rather than augmenting it. The volumetric audit shows that total delivered volume changes by only 0.6% between the two cases, whereas the physically unserved volume after outlet failure decreases by 25.5%, from 5,295.3 to 3,947.3 m³. Each escalation removes demand from the near term and preserves storage for later use, so the same water is delivered under a different schedule. This schedule shift buys a 4.17 h postponement of system failure and partial coverage, 97.9 m³ or about 9%, of the morning peak block that the baseline misses entirely.


The redistribution interpretation refines the way resilience gains are usually attributed. Threshold-based indices in the tradition of Hashimoto et al. (1982) and integral-based frameworks in the tradition of Cimellaro et al. (2010) measure performance against a reference trajectory, but they do not distinguish volumetric gains from temporal ones. With the storage value ceiling held common at 1,503.4 m³·pattern, the baseline captures 49.6% of the value potential and the EWM case captures 60.9%, an improvement of 23.0% in time-weighted service against a throughput loss of 0.6%. The finding echoes the intervention taxonomy of Butler et al. (2017), in which reliability, resilience, and sustainability are pursued through planned actions rather than passive capacity, and it quantifies the exchange rate between marginal quantity and substantial timing value. Recent reviews of water distribution reliability likewise emphasize that conventional indices overlook the service value delivered under degraded conditions rather than the hydraulic state alone (Sirsant et al., 2023), a distinction also formalized in resilience-based performance metrics (Roach et al., 2018).


### 4.2 Cyber-Physical Mechanism and the Origin of the Time Difference Window

The tank storage is the source of the water, but the time difference window itself is produced by the cyber-physical loop. The linkage among the three layers decomposes into four functional stages. Sensing and control are two functions of the cyber layer: sensing acquires tank levels and pump states at 300 s intervals, and control evaluates the tiered thresholds, enforces the one-way ratchet, and issues the demand retention multiplier. The coupling layer, the time-synchronized database, timestamps every state and exposes it to the decision module, which makes each transition auditable and reproducible. The physical layer executes the curtailment at the next hydraulic solve, and the resulting state closes the loop. Every arrow of this loop is exercised by a logged event, namely the escalations at 26.08, 28.00, and 30.83 h, and the command execution verified earlier.


The counterfactual isolates the causal role of the loop. With identical storage, hydraulics, and protection rules, the network without the loop exhausts its storage at 30.17 h, whereas the network with the loop exhausts it at 34.33 h. The 4.17 h window is therefore information mediated, which is the defining property of proactive rather than passive resilience. This addresses the concern, raised for cyber-physical water studies generally, that timing benefits may derive from physical storage alone. The auditable coupling also matters for security. Deception attacks on water SCADA telemetry have been demonstrated experimentally by Amin et al. (2013), and a coupling layer that timestamps every state transition provides the traceability needed to detect inconsistent sensing and control histories. In the same spirit as the resilience platform of Klise et al. (2017), the weak coupling makes the window measurable, and the mass balance audit is a direct output of the database rather than external bookkeeping.


### 4.3 Engineering Practice and Threshold Selection

The graded thresholds are calibratable operating parameters rather than universal constants. The monotone response shows that earlier curtailment extends the EWM Service time from 7.54 h under D1 to 10.94 h under D5, at the cost of shedding demand earlier and longer, so utilities face an explicit trade-off between extension and acceptability. The symmetric design D3 is a balanced point on this curve rather than an optimum. The gain grows with storage scarcity, stabilizes for outages beyond 16 h, and persists across demand loads, so calibration parallels the practice of adjusting demand multipliers to local monitoring data rather than transferring them between networks (Do et al., 2016; Creaco et al., 2020; Chew et al., 2022). Recent resilience assessments of urban water systems under critical component failures likewise support component-specific calibration and recovery prioritization (Liu et al., 2023; Liu et al., 2020).


Deployment requires only infrastructure that most utilities already possess or are acquiring. The EWM consumes standard SCADA telemetry of tank levels and pump states; the demand-side action can be enacted through advanced metering infrastructure and pressure-reducing valves with preset emergency routines (Section 2.5, A5); and the retention grades of Table 1 provide natural contractual tiers for pre-agreed curtailment agreements with large users. The fixed ratchet schedule also offers a transparent and verifiable operating rule, an advantage over receding-horizon schemes such as economic model predictive control (Wang et al., 2017), whose optimality is harder to audit under emergency conditions. Recent real-time scheduling studies confirm that proactive, prediction-driven pump and demand control is increasingly feasible in practice (Hu et al., 2023; Cemiloglu et al., 2023). The node weights w_j, held at unity, are the designed entry point for priority grading of hospitals and firefighting loads.


### 4.4 Limitations and Future Perspectives

The findings are bounded by the idealized assumptions, of which three deserve emphasis. First, water quality is held constant, so low flow velocities during deep curtailment increase water age and stagnation, and chlorine residuals may decay along the preserved but slow-moving supply paths; coupling the platform with the water quality solver of EPANET 2.2 (Rossman et al., 2020) would extend the evaluation from quantity to quality resilience, consistent with network-based water quality assessment (Sitzenfrei, 2021) and drinking-water quality guidelines (WHO, 2022). Second, sub-atmospheric pressures and contaminant intrusion are not modeled, and low and negative pressure events are a documented pathway for microbial intrusion through leaks and submerged orifices (Besner et al., 2011), while hydraulic resilience that couples water quality considerations reinforces this concern (Hou et al., 2023) and pipe failure probability modeling frames the associated damage limit (Taiwo et al., 2023). Transient surge analysis is therefore required before field deployment even though the outlet guard limits tank drainage. Third, demands are treated as fully controllable and static in pattern, whereas real customers respond to curtailment with behavioral adaptation and rebound.


The co-simulation platform itself outlines the path toward a deployable digital twin. Because the physical and cyber domains interact only through the time-synchronized database, the simulated telemetry can be replaced by live SCADA feeds without structural change, following the state-estimation architectures already demonstrated for water networks (Bonilla et al., 2022) and the broader value of digital technologies for critical-infrastructure climate resilience (Argyroudis et al., 2022). On this basis, dynamic threshold adjustment becomes concrete rather than aspirational: a state estimator updates the storage trajectory in real time, a demand forecast projects the depletion rate under the current pattern, and the warning thresholds are recomputed online so that the predicted tank level reaches the isolation limit exactly at the expected restoration time. This receding-horizon formulation connects the fixed ratchet studied here with the predictive-control tradition of water network operation (Wang et al., 2017), while the ratchet logic and retention grades carry over unchanged.


A supply-interruption digital twin that couples remote meter and hydraulic data has already been demonstrated for multi-modal failure analysis (Pesantez et al., 2022), which supports the practical feasibility of the proposed extension. In combination with machine-learning demand forecasting, the same loop supports adaptive priority weighting through w_j and, with malicious sensing addressed by traceable coupling, a defensible foundation for adaptive risk management in operational settings. This extension remains consistent with the mechanism established here: cyber sensing provides a fast observation channel, the hydraulic network remains the slow physical process, and the digital twin dynamically adjusts how the time difference window is used when the forecasted stress differs from the fixed D3 condition. Broader water-quality digital twins, priority user allocation, and integrated backflow-risk modeling are important extensions beyond the present scope.


---

## 5. Conclusions

**Theoretical finding.** The main theoretical contribution of this study is that proactive resilience in urban water supply cyber-physical systems can be achieved by exploiting the time difference window created by the mismatch between rapid cyber sensing and gradual hydraulic degradation. Within the three-layer linkage, the cyber layer performs both sensing and control: SCADA sensing reports tank levels and pump states, and the control logic converts these observations into a state-dependent demand retention multiplier under a one-way ratchet, while the physical layer executes graded curtailment. Tank storage provides the physical capacity over which the intervention operates, whereas early warning management determines how that capacity is allocated during the failure process. Early warning is therefore not merely an alarm output. It is an executable emergency control mechanism. The counterfactual comparison isolates this claim, because identical storage fails at 30.17 h without the control loop and at 34.33 h with it, so the 4.17 h window is information mediated rather than storage driven.


**Key simulation results.** On the Anytown benchmark network under a complete 24 h water-source outage, EWM postpones outlet failure from 30.17 h to 34.33 h in both parallel tanks and shortens the outlet failure duration within the fault window from 17.83 h to 13.67 h. Service time extends by 67.6%, from 6.17 h to 10.33 h, and Service value improves by 23.0%, from 0.50 to 0.61, against a storage value ceiling of 1,503.4 m³·pattern shared by both cases. The volumetric audit attributes the gain to temporal reallocation: total delivered volume changes by only 0.6%, from 1,095.2 m³ to 1,088.3 m³, while the physically unserved volume after outlet failure decreases by 25.5%, and the morning peak block regains partial coverage of 97.9 m³. Phase-averaged scans over 264 paired runs confirm that the Service time gain remains positive across threshold designs, tank scales, outage durations of 12 to 48 h, and demand loads of 0.6× to 1.4×, with the largest relative extension under storage-constrained and light-load conditions.


**Engineering implications.** For urban water supply management departments, the graded retention schedule should first be encoded into the existing SCADA-to-execution pathway through advanced metering infrastructure, pressure-reducing valves, or equivalent controllable devices, with the retention tiers adopted as pre-agreed curtailment contracts for large users. Second, the 5.0, 3.5, 2.0, and 0.5 m trigger levels should be recalibrated to local tank geometry, storage capacity, expected outage duration, and demand load rather than transferred between networks, because earlier curtailment extends service monotonically but sheds demand earlier and longer. Third, uniform demand reduction should be replaced by priority-based allocation that protects hospitals and firefighting capacity before field deployment, for which the node weights of the Service value metric provide the designed entry point. Fourth, where short-horizon forecasts are available, a digital twin built on the existing co-simulation platform can recompute the trigger depths and retention multipliers online so that the predicted tank level reaches the isolation limit exactly at the expected restoration time. Water quality deterioration, localized backflow risks, and sensing and communication uncertainties should be resolved before large-scale deployment.


---

## References
Alexandra, C, Daniell, K A, Guillaume, J, Saraswat, C, Feldman, H R (2023). Cyber-physical systems in water management and governance. Current Opinion in Environmental Sustainability, 62: 101290.
Amin, S, Litrico, X, Sastry, S, Bayen, A M (2013). Cyber security of water SCADA systems Part I: Analysis and experimentation of stealthy deception attacks. IEEE Transactions on Control Systems Technology, 21(5): 1963–1970.
Ande, R, Adebisi, B, Hammoudeh, M, Saleem, J (2020). Internet of Things: Evolution and technologies from a security perspective. Sustainable Cities and Society, 54: 101728.
Arghandeh, R, Von Meier, A, Mehrmanesh, L, Mili, L (2016). On the definition of cyber-physical resilience in power systems. Renewable and Sustainable Energy Reviews, 58: 1060–1069.
Argyroudis, S A, Mitoulis, S A, Chatzi, E, Baker, J W, Brilakis, I, Gkoumas, K, Linkov, I (2022). Digital technologies can enhance climate resilience of critical infrastructure. Climate Risk Management, 35: 100387.
Besner, M C, Prévost, M, Regli, S (2011). Assessing the public health risk of microbial intrusion events in distribution systems: Conceptual model, available data, and challenges. Water Research, 45(3): 961–979.
Bhardwaj, A, Gupta, A, Khatri, S K (2021). Cyber-physical system security in smart water networks: A review. IEEE Transactions on Industrial Informatics, 17(10): 7125–7136.
Bonilla, C A, Zanfei, A, Brentan, B, Montalvo, I, Izquierdo, J (2022). A digital twin of a water distribution system by using graph convolutional networks for pump speed-based state estimation. Water, 14(4): 514.
Butler, D, Ward, S, Sweetapple, C, Astaraie-Imani, M, Diao, K, Farmani, R, Fu, G (2017). Reliable, resilient and sustainable water management: The Safe and SuRe approach. Global Challenges, 1(1): 63–77.
Cai, B, Zhang, Y, Wang, H, Liu, Y, Ji, R, Gao, C, Liu, J (2021). Resilience evaluation methodology of engineering systems with dynamic Bayesian networks. Reliability Engineering & System Safety, 209: 107464.
Cemiloglu, A, Zhu, L, Ugurenver, A, Nanehkaran, Y A (2023). Optimal exploitation of urban water supply networks based on pressure management with the non-dominated sorting differential evolution (NSDE) algorithm. Water, 15(14): 2583.
Chew, A W Z, Wu, Z Y, Walski, T, Meng, X, Cai, J, Pok, J, Kalfarisi, R (2022). Daily model calibration with water loss estimation and localization using continuous monitoring data in water distribution networks. Journal of Water Resources Planning and Management, 148(5): 04022012.
Cimellaro, G P, Reinhorn, A M, Bruneau, M (2010). Framework for analytical quantification of disaster resilience. Engineering Structures, 32(11): 3639–3649.
Creaco, E, De Paola, F, Fiorillo, D, Giugni, M (2020). Bottom-up generation of water demands to preserve basic statistics and rank cross-correlations of measured time series. Journal of Water Resources Planning and Management, 146(1): 06019011.
Do, N C, Simpson, A R, Deuerlein, J W, Piller, O (2016). Calibration of water demand multipliers in water distribution systems using genetic algorithms. Journal of Water Resources Planning and Management, 142(11): 04016044.
Farmani, R, Walters, G A, Savic, D A (2005). Trade-off between total cost and reliability for Anytown water distribution network. Journal of Water Resources Planning and Management, 131(3): 161–171.
Feng, Q, Wu, Q, Hai, X, Ren, Y, Wen, C, Wang, Z (2025). Deep reinforcement learning based resilience optimization for infrastructure networks restoration with multiple crews. Frontiers of Engineering Management, 12(1): 141–153.
Hashimoto, T, Stedinger, J R, Loucks, D P (1982). Reliability, resiliency, and vulnerability criteria for water resource system performance evaluation. Water Resources Research, 18(1): 14–20.
Hassanzadeh, A, Rasekh, A, Galelli, S, Aghashahi, M, Taormina, R, Ostfeld, A, Banks, M K (2020). A review of cybersecurity incidents in the water sector. Journal of Environmental Engineering, 146(5): 03120003.
He, S, Zhou, Y, Yang, Y, Liu, T, Zhou, Y, Li, J, Guan, X (2024). Cascading failure in cyber-physical systems: A review on failure modeling and vulnerability analysis. IEEE Transactions on Cybernetics, 54(12): 7936–7954.
Holling, C S (1973). Resilience and stability of ecological systems. Annual Review of Ecology and Systematics, 4(1): 1–23.
Hosseini, S, Barker, K, Ramirez-Marquez, J E (2016). A review of definitions and measures of system resilience. Reliability Engineering & System Safety, 145: 47–61.
Hou, B, Huang, J, Miao, H, Zhao, X, Wu, S (2023). Seismic resilience evaluation of water distribution systems considering hydraulic and water quality performance. International Journal of Disaster Risk Reduction, 93: 103756.
Hu, S, Gao, J, Zhong, D, Wu, R, Liu, L (2023). Real-time scheduling of pumps in water distribution systems based on exploration-enhanced deep reinforcement learning. Systems, 11(2): 56.
Juan-García, P, Butler, D, Comas, J, Darch, G, Sweetapple, C, Thornton, A, Corominas, L (2017). Resilience theory incorporated into urban wastewater systems management: State of the art. Water Research, 115: 149–161.
Khan, R, Zakarya, M, Balasubramanian, V, Jan, M A, Menon, V G (2020). Smart sensing enabled decision support system for water scheduling in orange orchard. IEEE Sensors Journal, 21(16): 17492–17499.
Klise, K A, Bynum, M, Moriarty, D, Murray, R (2017). A software framework for assessing the resilience of drinking water systems to disasters with an example earthquake case study. Environmental Modelling & Software, 95: 420–431.
Liao, C, Chen, X, Gao, Z (2025). Toward smart charging, synergistic infrastructure and storable grid for coordinated power and transportation systems. Frontiers of Engineering Management, 12(3): 704–709.
Liserra, T, Maglionico, M, Ciriello, V, Di Federico, V (2014). Evaluation of reliability indicators for WDNs with demand-driven and pressure-driven models. Water Resources Management, 28(5): 1201–1217.
Liu, L, Mijic, A (2025). Performance-based resilience assessment in integrated water systems: Challenges and opportunities. Journal of Hydrology, 630: 134042.
Liu, W, Song, Z, Ouyang, M, Li, J (2020). Recovery-based seismic resilience enhancement strategies of water distribution networks. Reliability Engineering & System Safety, 203: 107088.
Liu, Z, Xu, W, Wang, Y (2023). Resilience assessment and enhancement of urban water supply systems under critical component failures. Frontiers of Engineering Management, 10(2): 245–258.
Madiziyire, S, Stagner, J, Carriveau, R, Biswas, N, Johnson, K, Fisk, A (2025). Evaluation of response measures for water cutoffs using pressure driven analysis simulations. Water Research, 268: 124737.
Meng, F, Fu, G, Farmani, R, Sweetapple, C, Butler, D (2018). Topological ranking of water distribution networks for resilience assessment. Water Research, 129: 316–328.
Ministry of Housing and Urban-Rural Development of China (MOHURD) (2018). Standard for Outdoor Water Supply Engineering (GB 50013-2018). China Architecture & Building Press, Beijing, China.
Mohebbi, S, Zhang, Q, Wells, E C, Zhao, T, Nguyen, H, Li, M, Ou, X (2020). Cyber-physical-social interdependencies and organizational resilience: A review of water, transportation, and cyber infrastructure systems and processes. Sustainable Cities and Society, 62: 102327.
Pesantez, J E, Alghamdi, F, Sabu, S, Mahinthakumar, G, Berglund, E Z (2022). Using a digital twin to explore water infrastructure impacts during the COVID-19 pandemic. Sustainable Cities and Society, 77: 103520.
Roach, T, Kapelan, Z (2017). Infrastructure resilience assessment using pressure dependent hydraulic modeling of water distribution networks. Water Resources Management, 31(11): 3505–3519.
Roach, T, Kapelan, Z, Ledbetter, R (2018). Resilience-based performance metrics for water resources management under uncertainty. Advances in Water Resources, 116: 18–28.
Rossman, L A, Woo, H, Tryby, M, Shang, F, Janke, R, Haxton, T (2020). EPANET 2.2 user manual. EPA/600/R-20/133, U.S. Environmental Protection Agency, Cincinnati, OH.
Siew, C, Tanyimboh, T T, Seyoum, A G (2016). Penalty-free multi-objective evolutionary approach to optimization of Anytown water distribution network. Water Resources Management, 30(11): 3671–3688.
Sirsant, S, Hamouda, M A, Shaaban, M F (2023). Advances in assessing the reliability of water distribution networks: A bibliometric analysis and scoping review. Water, 15(5): 986.
Sitzenfrei, R (2021). Using complex network analysis for water quality assessment in large water distribution systems. Water Research, 201: 117359.
Taiwo, R, Ben Seghier, M E A, Zayed, T (2023). Toward sustainable water infrastructure: The state of the art for modeling the failure probability of water pipes. Water Resources Research, 59(4): e2022WR033256.
Taormina, R, Galelli, S, Tippenhauer, N O, Salomons, E, Ostfeld, A, Eliades, D G, Aghashahi, M, Sundararajan, R, Pourahmadi, M, Banks, M K, Ohar, Z (2018). Battle of the attack detection algorithms: Disclosing cyber attacks on water distribution networks. Journal of Water Resources Planning and Management, 144(8): 04018048.
Walski, T M, Brill, E D, Gessler, J, Goulter, I C, Jeppson, R M, Lansey, K, Ormsbee, L (1987). Battle of the network models: Epilogue. Journal of Water Resources Planning and Management, 113(2): 191–203.
Walski, T M, Chase, D V, Savic, D A, Grayman, W, Beckwith, S, Koelle, E (2003). Advanced Water Distribution Modeling and Management. Haestad Methods, Waterbury, CT, USA.
Wang, Y, Puig, V, Cembrano, G (2017). Non-linear economic model predictive control of water distribution networks. Journal of Process Control, 56: 23–34.
Wu, G, Li, Z S (2021). Cyber-Physical Power System (CPPS): A review on measures and optimization methods of system resilience. Frontiers of Engineering Management, 8(4): 503–518.
World Health Organization (WHO) (2022). Guidelines for Drinking-Water Quality: Fourth Edition Incorporating the First and Second Addenda. World Health Organization, Geneva, Switzerland.
Xu, W, Zhou, X, Xin, K, Boxall, J, Yan, H, Tao, T (2020). Disturbance extraction for burst detection in water distribution networks using pressure measurements. Water Resources Research, 56(5): e2019WR025526.
Yadav, G, Paul, K (2021). Architecture and security of SCADA systems: A review. International Journal of Critical Infrastructure Protection, 34: 100433.
Zhang, C, Chen, R, Wang, S, Dui, H, Zhang, Y (2022). Resilience efficiency importance measure for the selection of a component maintenance strategy to improve system performance recovery. Reliability Engineering & System Safety, 217: 108070.
