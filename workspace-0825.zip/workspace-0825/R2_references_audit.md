# R2 修改稿 · 参考文献核查报告（Reference Audit）

> 目的：① 确认参考文献来源真实性（拒绝虚假编造）；② 确认正文是否引用；③ 检出重复与冗余文献。
> 说明：原 R2 参考列表含约 75 条。本次已对"新增文献 + 全部残缺/可疑/重复条目"完成联网验真；其余绝大多数为权威期刊/专著（Nature、Water Research、Reliability Eng & Syst Safety、JWRPM、ASCE、IEEE、MDPI Water 等），来源可信。建议对**标注 **待作者复核*** 的条目**逐个到期刊官网/DOI 复核后正式采用。

---

## 一、需要修正的问题（重复、残缺、自注未落实）— 必须处理

### A1. 碎片化残缺条目（4 条，非独立文献，byproduct of merge/export）
| 列表中的残缺条 | 实为哪篇的残片 | 处理 |
|---|---|---|
| `Banks, M K (2020). A review of cybersecurity incidents in the water sector. J. Environ. Eng.` | `Hassanzadeh, A, Rasekh, A, Galelli, S, Aghashahi, M, Taormina, R, Ostfeld, A, **Banks, M K** (2020)` | 删除此残条，作者并入 Hassanzadeh 条目 |
| `Corominas, L (2017). Resilience theory incorporated into urban wastewater systems management... Water Research` | `Juan-García, P, Butler, D, Comas, J, Darch, G, Sweetapple, C, Thornton, A, **Corominas, L** (2017)` | 删除此残条（Juan-García 完整条目见 A4） |
| `Linkov, I (2022). Digital technologies can enhance climate resilience... Climate Risk Management` | `Argyroudis, S A, Mitoulis, S A, Chatzi, E, Baker, J W, Brilakis, I, Gkoumas, K, ..., **Linkov, I** (2022)` | 删除此残条，作者并入 Argyroudis |
| `Ohar, Z (2018). Battle of the attack detection algorithms... JWRPM` | `Taormina, R, Galelli, S, Tippenhauer, N O, Salomons, E, Ostfeld, A, Eliades, D G, ..., **Ohar, Z** (2018)` | 删除此残条，作者并入 Taormina |

### A2. 重复条目
| 重复对 | 处理 |
|---|---|
| `Ministry of Housing and Urban-Rural Development of China (MOHURD) (2018). Standard for Outdoor Water Supply Engineering (GB 50013-2018)` 与 `MOHURD (2018). Code for design of outdoor water supply engineering (GB 50013-2018)` | 同一国标，保留**一条**（建议统一为 MOHURD 官方全称格式），删另一条 |
| `Zou, X Y, Peng, X Y, Zhao, X X, Chang, C P (2023)... Natural Hazards` 在列表**末尾出现两次** | 保留一条 |

### A3. 作者自注未落实
> R2 顶部自注："R1 源表 64 条，移除重复 4 条（R1-C7）：Zhang C 2022 / Zhang J 2024 / Zhang Y 2025 / Zou 2023"
- 但 **Zhang C (2022)** 仍在列表，且正文引言仍引用 `Zhang et al., 2022`（"Feng et al., 2025; Zhang et al., 2022"）。
- **若正文保留该引用** → 不应删 Zhang 2022；**若删** → 需同步删除正文引用处，否则出现"正文引用无对应条目"。
- Zhang J 2024、Zhang Y 2025、Zou 2023 在列表中（均未见正文引用，见 B 区），可与自注一致删除。

### A4. 正文已引用、但列表缺失（需补齐）
- **`Juan García, P, Butler, D, Comas, J, Darch, G, Sweetapple, C, Thornton, A, Corominas, L. (2017). Resilience theory incorporated into urban wastewater systems management: State of the art. Water Research, 115: 149–161.`** （引言引用 `Juan García et al., 2017`）。作者自注已标"待作者补齐"。

---

## 二、正文引用核对（哪些被引用 / 哪些冗余未引用）

### B1. 正文已引用 ✅（共约 34 条，全部在列表中有对应）
Alexandra 2023；Amin 2013；Ande 2020；Arghandeh 2016；Besner 2011；Bhardwaj 2021；Bonilla 2022；Butler 2017；Cai 2021；Chew 2022；Cimellaro 2010；Creaco 2020；Do 2016；Feng 2025；Hashimoto 1982；Hassanzadeh 2020；He S 2024；Holling 1973；Hosseini 2016；Juan García 2017（**缺条目**，见 A4）；Khan 2020；Klise 2017；Liao 2025；Liu L & Mijic 2025；Meng 2018；MOHURD 2018；Rossman 2020；Siew 2016；Taormina 2018；Walski 1987；Wang Y 2017；Wu & Li Z S 2021；Yadav & Paul 2021；Zhang C 2022（见 A3）。
> 注：讨论中**新增**的 4 篇（Sirsant 2023、Hu 2023、Cemiloglu 2023、Pesantez 2022）不在原 R2 列表，需**补入**参考列表。

### B2. 列表有、但正文**未引用** 🔴（冗余，需决定"删"或"补引用"）
以下条目在润色后正文各节**均未出现**：
Bai 2021；Boltz 2019；Casal-Campos 2018；Chen B 2025；Chen Z 2025；Creaco(Franchini, Walski) 2016；Cui 2022；Farmani 2005；Garcia-Perez 2023；He Z 2023；Hou 2023；Jiang 2025；Khattak 2024；Liserra 2014；Liu D 2019；Liu L, Zhou et al. 2023；Liu W 2020；Liu Z 2023；Madiziyire 2025；Mignot & Dewals 2022；Mohebbi 2020；Moreno-Sader 2019；Ostfeld & Salomons 2004；Roach & Kapelan 2017；Roach, Kapelan & Ledbetter 2018；Sadien 2024；Savic & Banyard 2024；Sitzenfrei 2021；Sun 2022；Taiwo 2023；Walski (Chase et al.) 2003；Wang B & Shen 2023；Wardropper & Brookfield 2022；WHO 2022；Xu 2020；Zhang J 2024；Zhang Y 2025；Zou 2023；+ 残缺条（Banks/Corominas/Linkov/Ohar，见 A1）。
> **处理取向**：A3/Zhang J 2024、Zhang Y 2025、Zou 2023 及**残余碎片条**建议直接删除；其余列表有但未引用的**权威文献**，建议二选一：① 在 corresponding 段落补引（增强文献对话，呼应审稿人1"综述要深入"），② 直接删除以得到干净的"引用-列表一一对应"。
> **Reminder**：若删除，需确保正文无任何残余引用；若补引，需在相应段落补一句与该文献相关的论述。

---

## 三、来源真实性判定（拒绝编造）

### C1. 已联网验真为真实存在的**新增文献**（讨论节建议补入）
| 条目 | 已验证出处 |
|---|---|
| Sirsant, S, Hamouda, M A, Shaaban, M F (2023). Advances in assessing the reliability of water distribution networks: A bibliometric analysis and scoping review. *Water*, 15(5): 986. | ✅ MDPI Water 15(5):986, DOI 10.3390/w15050986 |
| Pesantez, J E, Alghamdi, F, Sabu, S, Mahinthakumar, G, Berglund, E Z (2022). Using a digital twin to explore water infrastructure impacts during the COVID-19 pandemic. *Sustainable Cities and Society*, 77: 103520. | ✅ Elsevier, DOI 10.1016/j.scs.2021.103520 |
| Hu, S, Gao, J, Zhong, D, Wu, R, Liu, L (2023). Real-time scheduling of pumps in water distribution systems based on exploration-enhanced deep reinforcement learning. *Systems*, 11(2): 56. | ✅ MDPI Systems 11(2):56 |
| Cemiloglu, A, et al. (2023). Optimal exploitation of urban water supply networks based on pressure management with the NSDE algorithm. *Water*, 15(14): 2583. | ✅ MDPI Water 15(14):2583 |
> ⚠️ 四篇均为真实文献，**建议正式引用前**到期刊官网/DOI 复核作者全名顺序与页码（尤其 Cemiloglu 的完整作者列表与页码，我按命中信息给出，未逐一核对全部作者）。

### C2. 原列表真实性总体判断
- **绝大多数为学术界公认的权威文献**（Nature、Nature Communications、Water Research、Reliability Engineering & System Safety、Journal of Water Resources Planning and Management (ASCE)、Environmental Science & Technology、IEEE Trans.、MDPI Water/Systems、Elsevier 等），**来源可信、非编造**。
- **建议作者复核的条目（标注"待复核"）**：
  - `Savic & Banyard (Eds) (2024). Water Supply and Distribution Systems.` — **正文缺出版社/出版地**，需补齐（Emerald Group Publishing）或确认；
  - `Hassanzadeh, A, ... (2020)` — 期刊名：主流出处为 *Journal of Environmental Engineering (ASCE)*；文中若列作 *Nature Reviews Earth & Environment* 请以原始出处为准统一；
  - 个别作者名是否有连字符/缩写差异（如 `Moreno-Sader`、`Casal-Campos`、`Garcia-Perez`、`Duenas-Osorio`、`Prévost`），建议全篇统一。

---

## 四、行动建议（按优先级）

1. **删除 4 条碎片残条**（Banks/Corominas/Linkov/Ohar）→ 修正对应四条完整文献的作者列表。
2. **合并 2 处重复**：MOHURD 2018（删一条）、Zou 2023（删重复的一条）。
3. **补齐 Juan-García et al. 2017 完整条目**（正文已引）。
4. **把讨论新增的 4 篇文献补入列表**（Sirsant/Pesantez/Hu/Cemiloglu），并给它们完整的卷期页信息。
5. **处理作者自注**：明确 Zhang C 2022 是否保留（保留则正文引用即可，不保留则删除正文引用）；按自注删除 Zhang J 2024、Zhang Y 2025、Zou 2023（若不再引用）。
6. **清理「列表有但未引用」的权威文献**：二选一（补引用 or 删除），最终形成「正文引用 ↔ 列表条目」严格一一对应。
7. 统一作者名拼写/连字符、补齐 Savic & Banyard 出版社、统一 Hassanzadeh 期刊名。

> **验证边界声明**：我对本次核心问题（重复、残缺、缺失、新增文献验真、抽查权威出处）已严格核实；但**未能逐条对全部 75 条做逐篇联网 full-text 比对**。正式的最终版本建议配合期刊官方 DOI/官网核对一遍，尤其上面标注"待复核"与"建议复核"的条目。
