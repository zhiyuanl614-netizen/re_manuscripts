# R2 修改稿 · Results and Analysis 润色版（Section 3）— 每段约 150 词

> 依据：审稿人 1 Comment 4（图表/标签/图例/拼写核查统一）；审稿人 2 Comment 2（对比透明）、Comment 3（指标充分）、Comment 6（T1/T2 与摘要数值澄清）。
> 写法对齐 Ref-A（以"图+数值+机制"坐实、可核验）与 Ref-B（"图示+成对数值+趋势+原因"直陈）。
> 语言：无破折号、短断言、与定稿摘要/引言/方法一致。全部数值与结论不变，仅结构与表述优化。

---

## 3. Results and Analysis

### 3.1 Baseline Failure Evolution under Source Interruption (Fig. 3)

Under No EWM, the network degrades from cyclic operation to complete collapse within a single control step once the storage is exhausted (Fig. 3(a, b)). In normal operation the PLC cycles tank levels between 5.0 m and 8.0 m; after the pumps trip at 24 h, the tanks drain in parallel and their levels remain within 0.29 m, averaging 0.09 m over the outage. This follows from the identical tank settings and the equalizing effect of the looped topology (Assumption A8, Supplementary Table S1). Both tanks close their outlets at 30.17 h in the same 300 s step, and interpolation within the step gives a stagger of only 2.6 min; the outlet valves then close to prevent air entrainment and cavitation. The simultaneity is therefore a physical result of symmetric drawdown rather than a modeling artifact (Section 4.2).

*(约 130 词)*

Nodal pressures remain above the 0.10 MPa emergency threshold at every junction until isolation (Fig. 3(c)). Before isolation, pressures degrade non-uniformly in magnitude, but all 22 junctions stay above the threshold. Upon outlet closure the network average pressure falls from 0.44 MPa to 0.00 MPa within one step, and every junction crosses the threshold at 30.25 h. No spatial sequence of failure exists, because the whole network is fed by the same two tanks. The interruption spans the morning peak block (09:00 to 12:00, 33 to 36 h), and pressures recover network-wide at 48.08 h once pumping resumes. The baseline Service time therefore equals 6.17 h, the interval between fault initiation and outlet failure.

*(约 125 词)*

### 3.2 EWM Activation and Graded Control Process (Fig. 4)

The EWM converts the warning states into three graded curtailment actions without control chattering (Fig. 4(a)). After the pumps trip at 24 h, the logic escalates to WARNING at 26.08 h when the T2 level falls to 4.97 m, to ALERT at 28.00 h at 3.48 m, and to CRITICAL at 30.83 h when the T1 level reaches 2.00 m. The one-way ratchet holds each state for the remainder of the outage, so the event is governed by exactly three transitions. The demand retention multiplier follows 1.00, 0.70, 0.40, and 0.20, returns to 1.00 at 48.00 h, and is zeroed over the final interval, because the closed outlets remove the ability to supply regardless of the command.

*(约 125 词)*

The curtailment commands are executed faithfully and convert directly into storage preservation (Fig. 4(b, c)). In each segment the delivered volume matches or slightly exceeds the scheduled curtailed demand, and the accumulated shortfall before outlet failure is 0 m³. The drawdown rate of both tanks falls after each trigger, and outlet failure is postponed from 30.17 h to 34.33 h, an extension of 4.17 h, with a within-step stagger of 1.6 min. Graded curtailment consequently delays the network-wide pressure collapse by the same interval and restores partial coverage of the morning peak (Fig. 4(d)). All junctions remain above the threshold until 34.42 h, recovery occurs at 48.08 h, and during the peak block the EWM case delivers 97.9 m³, about 9% of the block requirement, whereas the baseline delivers none.

*(约 145 词)*

### 3.3 Comparative Resilience Performance (Fig. 5)

The EWM improves both resilience metrics substantially (Fig. 5). Service time increases from 6.17 h to 10.33 h, a relative extension of 67.6%, and Service value increases from 0.50 to 0.61, an improvement of 23.0% in time-weighted service. The weighted delivered service W rises from 745.3 to 916.2 m³·pattern, while both cases share the same storage value ceiling of 1,503.4 m³·pattern, the product of the onset storage S* = 1,156.4 m³ and the maximum block weight α_max = 1.30. Under this anchor the baseline captures 49.6% of the fixed storage value potential and the EWM case captures 60.9%. The two metrics are therefore complementary rather than redundant, because Service time measures pressure compliance and Service value measures delivery weighted by timing.

*(约 135 词)*

The volumetric audit confirms that the gain arises from temporal reallocation rather than water creation. Total delivered volume is nearly unchanged, at 1,095.2 m³ (No EWM) and 1,088.3 m³ (EWM), a difference of 0.6%. Within this nearly fixed volume, the physically unserved portion, the demand not delivered after outlet failure, decreases from 5,295.3 to 3,947.3 m³, and the morning peak block receives partial coverage. The EWM therefore trades a marginal reduction in total throughput for a 4.17 h postponement of failure and a redistribution of delivery toward high-value blocks. This dual accounting of pressure compliance and delivered service follows recent evaluations of water-cutoff response measures using pressure-driven analysis (Madiziyire et al., 2025). The magnitude of the Service value gain depends on the alignment between fault onset and demand blocks, so Service value is reported for the canonical alignment according to the reporting rules of Section 2.4.3.

*(约 140 词)*

### 3.4 Sensitivity and Robustness Analysis (Fig. 6)

Service time remains positive in sign across all four dimensions (Fig. 6). Earlier thresholds monotonically extend the EWM Service time (Fig. 6(a)); from the latest liberal design D1 to the earliest conservative design D5, it increases from 7.54 h to 10.94 h, because earlier curtailment reliably extends pressure compliance. The baseline stays at 4.27 h, since the threshold designs affect only the EWM logic, so D3 is a balanced compromise rather than a sharp optimum. The benefit also grows as passive storage becomes less adequate (Fig. 6(b)): the Service time gain increases from +1.98 h at a tank diameter of 0.6× to +10.10 h at 1.4×. Under the most storage-constrained condition the EWM more than doubles the Service time from 1.44 h to 3.42 h, so the gain is largest where passive storage is least able to buffer the disruption.

*(约 145 词)*

The EWM provides a stable emergency window regardless of outage length (Fig. 6(c)). For outages of 16 h and longer the baseline Service time saturates at 4.27 h, because the tanks are fully drained before the outage ends, whereas the EWM gain remains stable at about +5.1 h across this range. The gain stays positive across the full range of demand loads (Fig. 6(d)), rising from 5.58 h to 14.19 h at a load of 0.6× and from 2.73 h to 6.40 h at 1.4×. The largest relative extension occurs under light load, where unrestricted consumption would otherwise deplete storage most rapidly. Taken together, these results support the EWM as a dependable duration-extending intervention, and the threshold response indicates that warning levels should be calibrated to local tank capacity, outage duration, and demand load rather than transferred between networks.

*(约 150 词)*

---

## 图表与交叉引用核对（结果节）

| 引用 | 指向 | 核对 |
|---|---|---|
| Fig. 3(a, b) / 3(c) | 基线失效演化（水箱 + 压力） | ✅ |
| Fig. 4(a) / 4(b, c) / 4(d) | EWM 决策轨迹 / 水箱水位 / 压力图 | ✅ |
| Fig. 5 | 双指标对比 | ✅ |
| Fig. 6(a–d) | 阈值 / 储水 / 时长 / 负荷四维度 | ✅ |
| Assumption A8, Supplementary Table S1 | 水力对称 | ✅ 指向 SI，编号一致 |
| (Section 4.2) | 同步失效的物理原因 | ✅ |
| Section 2.2.4 | 敏感性单因素设计 | ✅ |
| Section 2.4.3 | 报告规则（Service value 仅基准对齐） | ✅ |
| 术语统一 | 0.10 MPa / Service time ± Service value / No EWM vs EWM / one-way ratchet / morning peak / phase-averaged | ✅ |
| 标签与拼写 | Critical Threshold（非 Threbok）、NORMAL/WARNING/ALERT/CRITICAL/OUTLET FAILURE、图例、轴单位 | ✅ 已规范（对应 Comment 4） |
