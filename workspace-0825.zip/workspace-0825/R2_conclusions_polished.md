# R2 修改稿 · Conclusions 润色版（Section 5）— 每段约 150 词

> 依据：审稿人 1 Comment 6（删除重复内容、重组为"理论发现 / 关键仿真结果 / 工程启示"三部分、补充水务管理部门的具体运行建议）。
> 结论写法对齐 Ref-B（premise 前提话术、给结论定边界）与 Ref-A（问题+方法+量化+前提+未来方向）。
> 语言：无破折号、短断言、术语统一、与摘要/引言/方法/结果/讨论一致。全部数值与结论不变。

---

## 5. Conclusions

**Theoretical finding.** The main theoretical contribution of this study is that proactive resilience in urban water supply cyber-physical systems can be achieved by exploiting the time difference window created by the mismatch between rapid cyber sensing and gradual hydraulic degradation. Within the three-layer linkage, SCADA sensing reports tank levels and pump states, the cyber control layer converts these observations into a state-dependent demand retention multiplier under a one-way ratchet, and the physical layer executes graded curtailment. Tank storage provides the physical capacity over which the intervention operates, whereas early warning management determines how that capacity is allocated during the failure process. Early warning is therefore not merely an alarm output. It is an executable emergency control mechanism. The counterfactual comparison isolates this claim, because identical storage fails at 30.17 h without the control loop and at 34.33 h with it, so the 4.17 h window is information mediated rather than storage driven.

*(约 152 词)*

**Key simulation results.** On the Anytown benchmark network under a complete 24 h water-source outage, EWM postpones outlet failure from 30.17 h to 34.33 h in both parallel tanks and shortens the outlet failure duration within the fault window from 17.83 h to 13.67 h. Service time extends by 67.6%, from 6.17 h to 10.33 h, and Service value improves by 23.0%, from 0.50 to 0.61, against a storage value ceiling of 1,503.4 m³·pattern shared by both cases. The volumetric audit attributes the gain to temporal reallocation: total delivered volume changes by only 0.6%, from 1,095.2 m³ to 1,088.3 m³, while the physically unserved volume after outlet failure decreases by 25.5%, and the morning peak block regains partial coverage of 97.9 m³. Phase-averaged scans over 264 paired runs confirm that the Service time gain remains positive across threshold designs, tank scales, outage durations of 12 to 48 h, and demand loads of 0.6× to 1.4×, with the largest relative extension under storage-constrained and light-load conditions.

*(约 155 词)*

**Engineering implications.** For urban water supply management departments, the graded retention schedule should first be encoded into the existing SCADA-to-execution pathway through advanced metering infrastructure, pressure-reducing valves, or equivalent controllable devices, with the retention tiers adopted as pre-agreed curtailment contracts for large users. Second, the 5.0, 3.5, 2.0, and 0.5 m trigger levels should be recalibrated to local tank geometry, storage capacity, expected outage duration, and demand load rather than transferred between networks, because earlier curtailment extends service monotonically but sheds demand earlier and longer. Third, uniform demand reduction should be replaced by priority-based allocation that protects hospitals and firefighting capacity before field deployment, for which the node weights of the Service value metric provide the designed entry point. Fourth, where short-horizon forecasts are available, a digital twin built on the existing co-simulation framework can recompute the trigger depths and retention multipliers online so that the predicted tank level reaches the isolation limit exactly at the expected restoration time. Water quality deterioration, localized backflow risks, and sensing and communication uncertainties should be resolved before large-scale deployment.

*(约 170 词)*

---

## 结论节：审稿意见对应说明

| 审稿人 1 Comment 6 要求 | 落实方式 |
|---|---|
| 删除重复内容 | 三段均删去与结果/讨论重复的方法学描述，仅在"理论发现"段保留最少量的三层联动说明 |
| 组织为"理论发现 / 关键结果 / 工程启示" | 用加粗小节标签 **Theoretical finding / Key simulation results / Engineering implications** 明确分三段 |
| 补充水务管理部门的具体运行建议 | 工程启示段给出 4 条可执行建议（SCADA 执行路径、阈值本地化校准、优先级分配保护医院/消防、数字孪生在线重算阈值） |

## 与两篇文献的写法对应

- Ref-B（premise 前提话术）：结论反复用"……需要/应……否则……"设边界，如"Water quality deterioration... should be resolved before large-scale deployment"。
- Ref-A（"问题→方法→量化→前提→方向"）：每段先断一句主主张，再用关键数值（30.17/34.33 h、17.83/13.67 h、67.6%、23.0%、0.6%、25.5%、97.9 m³、264 对运行）坐实，末句以工程意义或前提收束。
- 全部数值与结论不变，仅做"三段重组 + 精简 + 增强工程可操作性 + 无破折号"。
