# R2 修改稿 · Discussion 润色版（Section 4）— 每段约 150 词

> 依据：审稿人 1 Comment 5（分解 cyber-感知-控制-物理水层完整 EWM 机制、点明前提、扩展局限、具体化数字孪生/AI）；审稿人 2 Comment 4（明确时间差窗口的信息介导归属）。
> 写作要点：Discussion 以**机制论证与文献对话为主**，**仅在必要处保留图片引用**（此处仅 4.2 反事实对比一处）；增强与近年权威文献的互动；无破折号、短断言、术语统一、数据不变。

---

## 4. Discussion

This study established a weakly coupled cyber-physical co-simulation framework that converts early warning perception into graded demand curtailment, and quantified its effect on proactive resilience under a total water source interruption. Three findings emerge. First, early warning management (EWM) does not create water; it reallocates a fixed storage in time, extending Service time by 67.6% and Service value by 23.0% at a volumetric cost of only 0.6%. Second, the 4.17 h time difference window is information mediated rather than storage driven, because identical storage fails at 30.17 h without the control loop and at 34.33 h with it. Third, the Service time gain is robust in sign across four sensitivity dimensions, whereas the Service value gain depends on the alignment between fault onset and demand blocks. These findings position graded early warning as a middle-based intervention, situated between the capacity enhancement of supply-side measures and the hardening of physical infrastructure.

*(约 138 词)*

### 4.1 Mechanism of Resilience Enhancement: Service Redistribution

The EWM reallocates a fixed volume of stored water in time rather than augmenting it. The volumetric audit shows that total delivered volume changes by only 0.6% between the two cases, whereas the physically unserved volume after outlet failure decreases by 25.5%, from 5,295.3 to 3,947.3 m³. Each escalation removes demand from the near term and preserves storage for later use, so the same water is delivered under a different schedule. This schedule shift buys a 4.17 h postponement of system failure and partial coverage, 97.9 m³ or about 9%, of the morning peak block that the baseline misses entirely.

*(约 110 词)*

The redistribution interpretation refines the way resilience gains are usually attributed. Threshold-based indices in the tradition of Hashimoto et al. (1982) and integral-based frameworks in the tradition of Cimellaro et al. (2010) measure performance against a reference trajectory, but they do not distinguish volumetric gains from temporal ones. With the storage value ceiling held common at 1,503.4 m³·pattern, the baseline captures 49.6% of the value potential and the EWM case captures 60.9%, an improvement of 23.0% in time-weighted service against a throughput loss of 0.6%. The finding echoes the intervention taxonomy of Butler et al. (2017), in which reliability, resilience, and sustainability are pursued through planned actions rather than passive capacity, and it quantifies the exchange rate between marginal quantity and substantial timing value. Recent reviews of water distribution reliability likewise emphasize that conventional indices overlook the service value delivered under degraded conditions rather than the hydraulic state alone (Sirsant et al., 2023), a distinction also formalized in resilience-based performance metrics (Roach et al., 2018).

*(约 152 词)*

### 4.2 Cyber-Physical Mechanism and the Origin of the Time Difference Window

The tank storage is the source of the water, but the time difference window itself is produced by the cyber-physical loop. The linkage among the three layers decomposes as follows. The sensing layer samples tank levels and pump states at 300 s intervals. The coupling layer, the time-synchronized database, timestamps every state and exposes it to the decision module, which makes each transition auditable and reproducible. The control layer evaluates the tiered thresholds, enforces the one-way ratchet, and issues the demand retention multiplier. The physical layer executes the curtailment at the next hydraulic solve, and the resulting state closes the loop. Every arrow of this loop is exercised by a logged event, namely the escalations at 26.08, 28.00, and 30.83 h, and the command execution verified earlier.

*(约 128 词)*

The counterfactual isolates the causal role of the loop. With identical storage, hydraulics, and protection rules, the network without the loop exhausts its storage at 30.17 h, whereas the network with the loop exhausts it at 34.33 h. The 4.17 h window is therefore information mediated, which is the defining property of proactive rather than passive resilience. This addresses the concern, raised for cyber-physical water studies generally, that timing benefits may derive from physical storage alone. The auditable coupling also matters for security. Deception attacks on water SCADA telemetry have been demonstrated experimentally by Amin et al. (2013), and a coupling layer that timestamps every state transition provides the traceability needed to detect inconsistent sensing and control histories. In the same spirit as the resilience platform of Klise et al. (2017), the weak coupling makes the window measurable, and the mass balance audit is a direct output of the database rather than external bookkeeping.

*(约 150 词)*

### 4.3 Engineering Practice and Threshold Selection

The graded thresholds are calibratable operating parameters rather than universal constants. The monotone response shows that earlier curtailment extends the EWM Service time from 7.54 h under D1 to 10.94 h under D5, at the cost of shedding demand earlier and longer, so utilities face an explicit trade-off between extension and acceptability. The symmetric design D3 is a balanced point on this curve rather than an optimum. The gain grows with storage scarcity, stabilizes for outages beyond 16 h, and persists across demand loads, so calibration parallels the practice of adjusting demand multipliers to local monitoring data rather than transferring them between networks (Do et al., 2016; Creaco et al., 2020; Chew et al., 2022). Recent resilience assessments of urban water systems under critical component failures likewise support component-specific calibration and recovery prioritization (Liu et al., 2023; Liu et al., 2020).

*(约 122 词)*

Deployment requires only infrastructure that most utilities already possess or are acquiring. The EWM consumes standard SCADA telemetry of tank levels and pump states; the demand-side action can be enacted through advanced metering infrastructure and pressure-reducing valves with preset emergency routines (Section 2.5, A5); and the retention grades of Table 1 provide natural contractual tiers for pre-agreed curtailment agreements with large users. The fixed ratchet schedule also offers a transparent and verifiable operating rule, an advantage over receding-horizon schemes such as economic model predictive control (Wang et al., 2017), whose optimality is harder to audit under emergency conditions. Recent real-time scheduling studies confirm that proactive, prediction-driven pump and demand control is increasingly feasible in practice (Hu et al., 2023; Cemiloglu et al., 2023). The node weights w_j, held at unity, are the designed entry point for priority grading of hospitals and firefighting loads.

*(约 150 词)*

### 4.4 Limitations and Future Perspectives

The findings are bounded by the idealized assumptions, of which three deserve emphasis. First, water quality is held constant, so low flow velocities during deep curtailment increase water age and stagnation, and chlorine residuals may decay along the preserved but slow-moving supply paths; coupling the platform with the water quality solver of EPANET 2.2 (Rossman et al., 2020) would extend the evaluation from quantity to quality resilience, consistent with network-based water quality assessment (Sitzenfrei, 2021) and drinking-water quality guidelines (WHO, 2022). Second, sub-atmospheric pressures and contaminant intrusion are not modeled, and low and negative pressure events are a documented pathway for microbial intrusion through leaks and submerged orifices (Besner et al., 2011), while hydraulic resilience that couples water quality considerations reinforces this concern (Hou et al., 2023) and pipe failure probability modeling frames the associated damage limit (Taiwo et al., 2023). Transient surge analysis is therefore required before field deployment even though the outlet guard limits tank drainage. Third, demands are treated as fully controllable and static in pattern, whereas real customers respond to curtailment with behavioral adaptation and rebound.

*(约 145 词)*

The co-simulation platform itself outlines the path toward a deployable digital twin. Because the physical and cyber domains interact only through the time-synchronized database, the simulated telemetry can be replaced by live SCADA feeds without structural change, following the state-estimation architectures already demonstrated for water networks (Bonilla et al., 2022) and the broader value of digital technologies for critical-infrastructure climate resilience (Argyroudis et al., 2022). On this basis, dynamic threshold adjustment becomes concrete rather than aspirational: a state estimator updates the storage trajectory in real time, a demand forecast projects the depletion rate under the current pattern, and the warning thresholds are recomputed online so that the predicted tank level reaches the isolation limit exactly at the expected restoration time. This receding-horizon formulation connects the fixed ratchet studied here with the predictive-control tradition of water network operation (Wang et al., 2017), while the ratchet logic and retention grades carry over unchanged.

*(约 140 词)*

A supply-interruption digital twin that couples remote meter and hydraulic data has already been demonstrated for multi-modal failure analysis (Pesantez et al., 2022), which supports the practical feasibility of the proposed extension. In combination with machine-learning demand forecasting, the same loop supports adaptive priority weighting through w_j and, with malicious sensing addressed by traceable coupling, a defensible foundation for adaptive risk management in operational settings. This extension remains consistent with the mechanism established here: cyber sensing provides a fast observation channel, the hydraulic network remains the slow physical process, and the digital twin dynamically adjusts how the time difference window is used when the forecasted stress differs from the fixed D3 condition. Broader water-quality digital twins, priority user allocation, and integrated backflow-risk modeling are important extensions beyond the present scope.

*(约 132 词)*

---

## 讨论节：审稿意见与文献对照

| 内容 | 对应审稿意见 | 引用增强 |
|---|---|---|
| EWM 不增水、只重排固定储水 | R2 C1/C3 | Butler 2017, Hashimoto 1982, Cimellaro 2010, **Sirsant 2023(新)** |
| 时间差窗口信息介导、三层联动 | R1 C5、R2 C4 | Amin 2013, Klise 2017 |
| 阈值可校准、D1–D5 | R1 C3/C5 | Do 2016, Creaco 2020, Chew 2022 |
| 部署路径、主动实调度 | R1 C5 | Wang 2017, **Hu 2023(新)**, **Cemiloglu 2023(新)** |
| 局限（水质/负压/需求动态） | R1 C5 | Rossman 2020, Besner 2011 |
| 数字孪生落地 | R1 C5(具体化) | Bonilla 2022, **Pesantez 2022(新)**, Wang 2017 |
