# R2 修改稿段落结构与语言润色指南
## ——基于两篇参考文献的深入剖析

> 分析对象：
> 1. **Ref-A**（李楠团队）：Wang, Magoua & Li, *Modeling cascading failure of interdependent critical infrastructure systems using HLA-based co-simulation*, **Automation in Construction** 133 (2022) 104008.
> 2. **Ref-B**：Yu, Guo, Wu, Qiao & Sun, *Early warning and proactive control strategies for power blackouts caused by gas network malfunctions*, **Nature Communications** 15:4714 (2024).

这两篇论文之所以是理想的"范文"：**Ref-B 与 R2 的核心论点几乎一一对应**（时间失配/储气缓冲、预警、"主动控制 vs 被动控制"、缓冲介导、时间维度+空间维度双指标）；**Ref-A 与 R2 属于同一领域的"系统构建类"论文**（耦合协同仿真架构、域模型、案例研究、验证与确认），其段落骨架可直接借鉴。

经过通读，我提炼出两篇文献共同的**段落范式（paragraph template）**与**语体特征（register）**，再逐节映射到 R2 的改造上。

---

## 一、两篇文献共同的"段落结构模板"

两篇文献在成段上都遵循高度规整的 **"观点句 → 解释链 → 例证/量化 → 回扣"** 四步结构。每段几乎都是"**宏观—递进—落地—收束**"的微型论证单元（topic sentence → elaboration → evidence → close）。

### 1. 第一句永远是"放之四海皆准"的领域命题（macro-claim）
Ref-B 示例：
- "There is growing consensus that gas-fired generators will play a crucial role during the transition to net-zero energy systems..."
- "For electric power systems, it has become a common trend to gradually eliminate their dependence on fossil fuels..."

Ref-A 示例：
- "Critical infrastructure systems (CISs), such as power and water supply systems, provide the basic needs and services that are essential to sustain human activities..."
- "Cascading failure is a process by which a system component fails due to the failure of another component it depends on."

**特点**：以**公认事实 / 共识 / 宏观规律**开场，建立读者与作者共同的认知前提。**不做任何限定词开场**（不用 "In this paper we..." 开头）。

### 2. 第二句起用"逻辑递进"推进，常以转折词搭桥
- Ref-B 用 "**However**"、"**In fact**"、"**In contrast to**"、"**To precisely measure this influence**" 逐层加码。
- Ref-A 用 "**In addition**"、"**Finally**"、"**Consequently**"、"**Therefore**" 构建因果链。

**特点**：段内连接词密集且方向明确；每个连接词都标记"论证轴的转向"（从背景到问题、从问题到局限、从局限到方案、从方案到案例）。

### 3. 用"具体数字/实例/反事实"把抽象论点坐实
- Ref-B 全文几乎每句都伴随数字或事件：2021 年美国停电、106,585 MW、1983/1989/2003...、30 min 25 s、1047.2 MW、507.7→438.4 MW、1577.0→13.8 MWh。
- Ref-A 用具体对象：Shelby County、EPANET v2.2、OpenDSS v9.0、8 个门站、9 个泵站、M=5.0 主震/4.52 余震、65 分钟仿真、500 次重复。

**特点**：**用数字讲故事（quantitative storytelling）**，数字不是点缀而是论证主体；通过"改一个参数，结果如何变"来反证论点。

### 4. 段末回扣，或设问/埋钩子引出下一段
- Ref-A 常用 "**In summary**"、"**In sum**" 做节内小结，再用 "**Motivated by the aforementioned gaps...**"（+情态）引出方法论。
- Ref-B 用 "**Taken together**"、"**This underscores that**"。

**特点**：几乎不作"裸结尾"，每段都收束到"这段说明了什么/为什么重要"。

---

## 二、两篇文献的"语言/语体特征"（可为 R2 借鉴的 10 条）

1. **主谓结构清晰，句子紧凑**：长句少，即使用长句也用**明示子句关系**（because/although/which 高频）。几乎不出现"一逗到底"的分词铺陈。
2. **用"名词化 + 前置定语"压缩信息**：如 "the identification and transmission of gas network malfunction information"、"the dynamically extended control time"。既客观又经济。
3. **情态词克制，结论多落实证**：用 "was demonstrated/found/observed/indicated"（客观被动）而非 "we believe/prove"。判断句通过 **"can/may/could + 明确条件**"达成，避免绝对化。
4. **概念先行、术语后置定义**：先给现象（"the time required for the propagation and escalation of the malfunction"），再命名（"we define... as the **time difference window**"）。**术语首次出现必伴随正式定义句**。
5. **"主动/被动"二元对照是天然论证骨架**：Ref-B 的 Table 1（passive vs proactive control）是全篇的"脊梁"，贯穿摘要—引言—结果—讨论—结论。Ref-A 用 "direct damage vs cascading/whole disaster impact" 同样结构。
6. **层次标题简洁、指向明确**：Ref-A 用 "3.1 HLA-based modeling..."、"4.3.3 Federation execution"；Ref-B 用 "Indicators of gas system failure"、"Numerical example of the early warning indicators"、"Proactive control of the power system"。标题**交代"这一节在做什么"而非"属于什么"**。
7. **公式与解释交织**：Ref-B 每给一个式（Eq.1–19）都紧接一段文字**解释每个符号含义与物理意义**，绝不让公式"裸奔"。
8. **反复使用"对比表格"做信息降维**：Ref-A 用 Table 1/2/3/4/5/6 承载"信息交换、对象类属性、仿真器、FOM、可接受性"；Ref-B 用 Table 1/2 承载"控制方式对比、算法流程"。**把过程/属性从正文抽到表格**，正文只讲逻辑。
9. **英文母语化的"信息流"**：已知信息在句首（theme），新信息在句尾（rheme），段与段之间用**上一段末句的"宾语"充当下一段首句的"主语"**（顺承）。
10. **数字与单位、符号、缩写全局统一**：首次缩写给出全称（EPCC、GDC、SAET、ALP、PGA、FDTD…），并全程一致。

---

## 三、逐节映射：Ref-A / Ref-B 如何校准 R2 的段落与语言

### 3.1 Abstract（摘要）—— 对标 Ref-B 摘要

Ref-B 摘要的**黄金结构**：背景共识→问题（气网故障→大面积停电，且故障传播比信息传输慢）→**核心主张（由此提出预警+主动控制）**→方法→**关键量化结果**→意义。
对照 R2 摘要，可做三点修正：

- **背景句过于"方法论化"**：R2 第一句 "Urban water supply cyber-physical systems (CPS) can achieve proactive resilience..." 是**命题**，缺 Ref-B 那种**领域共识铺垫**。建议：先给一句"城市供水系统正演化为 CPS，且其在极端故障下的韧性越来越依赖信息手段"的大前提，再落到"然而现有研究停留在评估"。
- **量化结果应"成对有数字"**：Ref-B 是 "reduced from X to Y"。R2 摘要已具 "6.17→10.33 h"、"0.50→0.61"，但**应再补一个对照型数字**（如 baseline 30.17 h 失效 vs EWM 34.33 h）以匹配正文的核心反事实。
- **术语首次出现即给缩写定义**：R2 已做（EWM、RI 前义），但 "Service time $T_{press}$"、"Service value $R_w$" 应在摘要里**点明其"时间维度/价值维度"属性**（Ref-B：AET 时间维度、ALP 空间维度）。这是与 Ref-B 最值得对齐的一处——**把两个指标明确挂到"时间/价值"两维上**。

### 3.2 Introduction（引言）—— 对标 Ref-B 引言

Ref-B 引言的推进逻辑非常清晰：**宏观趋势（脱碳→气电耦合）→ 具体事故冲击（数据堆叠）→ 现有理论与预警的不足 → 提出本文**。Ref-A 引言则是「**背景→级联失效定义与危害→三类建模方法及缺陷→引出协同仿真→本文目标与贡献**」。
R2 引言已是三条主线+三目标，结构达标；但要**精修两点**：

1. **"背景→冲击"之间缺"事故/实例"锚**。Ref-B 用一连串真实停电（2021 德州、1983–2011、加州 2015、台湾 2017）把"问题真实且紧迫"落到实处。R2 引言目前抽象（"catastrophic events causing complete source interruption..."）。建议补 1–2 个水网水源中断/长时间停水的真实或文献案例。
2. **方法论缺陷要"归因"而非"罗列"**。Ref-A 批评三类方法时，每类都给出"**它丢了什么**"（只拓扑丢功能；只抽象流丢了时变与水力特性；只 DC 流丢了非线性）。R2 对"被动 fail-and-repair""仅报警无控制"的批评可更进一步：**点名这些方法"丢弃了时间失配这一可用资源"**——这正好把批评逐条导向本文的 temporal buffer 主张。
3. **目标段**：R2 已用"三个目标+问题/模型/机制"组织，模式正确。建议**把三条目标并入一段**并按 Ref-A 末尾那种 "The remainder of this paper is organized as follows..." 补**路线图句**，交代各节职责（可学 Ref-A 的 Section 2/3/4/5/6 行文）。

### 3.3 Methodology（方法）—— 对标 Ref-A 的方法学骨架

Ref-A 的"方法"是这一语境下**最值得整体效仿**的：它不是把工具堆在一起，而是**先给架构（federation architecture）再用三级标题拆解（3.1 建模→3.2 级联仿真流程→4.3 案例开发）**，且**每级子节都用"输入/输出/处理函数"的标准化话术**。

R2 方法（2.1–2.5）有四点可对齐：

| R2 现状 | Ref-A 可借鉴的做法 | 建议动作 |
|---|---|---|
| 2.1 平铺拓扑+日需水模式 | Ref-A 4.1.1/4.1.2 先给**系统构成**再给**关键参数**，且区分"数据来源" | 把参数与"数据来源"（Walski 1987 / 标准实践）**显式标注**，避免"凭空给出" |
| 2.2 场景与 EWM 混在一个标题 | Ref-A 把**场景（4.2）与模型开发（4.3）分离**；每个子节是"输入→处理→输出" | 已拆 2.2.1–2.2.5，方向正确；建议 2.2.2 明确"**输入（H, S_pump）→判断（阈值+棘轮）→输出（γ）→物理执行**"的顺序话术 |
| 2.3 协同仿真平台 | Ref-A 3.1 用"**职责分工**"描述模块（谁发布/订阅什么数据），3.2 给出**时序循环**，并配数据交换图与 FOM 表 | R2 已用"四步顺序执行协议"，很好；**补一段"谁发布/订阅什么、exchange 接口表"**（对应 Ref-A Table 1/3/5），把"信息**交换什么**"讲清楚 |
| 2.5 假设 | Ref-A 用 **Table 6/可接受性判据**支撑 V&V | R2 的 A1–A7 已编号，建议**补一句"假设如何被敏感性分析检验"**，与 3.4 呼应（Ref-A 用 V&V 让假设"可核验"） |

**语言上的最大改进**：把"我在做耦合"改成"**耦合是通过 X 接口、以 Y 时序、交换 Z 数据实现的**"（Ref-A 的 DPU/发布订阅语言）。R2 目前写的是机制描述，可增加**"可操作/可审计"的接口性语言**。

### 3.4 Results（结果）—— 对标 Ref-B 的结果写法

Ref-B 结果的最大特征是**每段先给"发现"，再用一组数字和一条曲线坐实，并给出"为什么"**。对照 R2 结果（3.1–3.4）：

- **3.1 基线失效**：R2 已把"30.17 h 同一步骤、2.6 min 错峰、全网同步垮塌、无空间序列"讲得极细——这正是 Ref-A"heterogeneity/级联路径"式的**机制挖掘**。建议保留；但**首句要变成断言式结论**（如"在无人为干预下，系统在储水耗尽后一步内整体失效"），再把细节作为支撑，避免细节冲淡主结论。
- **3.2 EWM 激活**：R2 已给"三点触发、棘轮、γ 序列、步内错峰"。语言上可学 Ref-B 的**数值成对**："before/after"、"with/without the loop"。并把"**指令被忠实执行、物理缺口=0**"这一**可审计证据**重申为干净的一两句（这是 R2 区别近似的强卖点）。
- **3.3 对比**：R2 的双指标（Service time/value）与**体积仅 +0.6%** 是全篇灵魂。**强烈建议**学 Ref-B 用一张**"被动 vs 主动"对照表**（Table 1 风格）把 No EWM 与 EWM 在"失效时刻/服务时长/服务价值/交付体积/未服务体积"一行一维列出来——这既回应审稿人对"对比透明性"的质疑，也大幅提升可读性。
- **3.4 敏感性**：Ref-A 用"criteria→结果→是否满足"（Table 6）的**判定式**呈现；Ref-B 用"随某参数单调变化"的**趋势描述**。R2 应统一为**趋势+区间**，并把"相位平均（264 对运行）"作为方法学卖点再强调一次（对齐 Ref-A 的"500 次重复平均"这一严谨性话术）。

### 3.5 Discussion（讨论）—— 对标 Ref-B 讨论

Ref-B 的讨论**不是重复结果**，而是**上升到"机制/边界/应用/局限"四层**，且**明确点出"预警的成立前提"**（"The basic premise... is that the storage capacity of gas pipelines serves as a buffer..."）。
R2 讨论（4.1–4.4）已对应，关键差距在**段落语言**：

- **4.1/4.2（机制与归属）**：R2 已强硬证明"信息介导 vs 储水驱动"。建议用 Ref-B 的"**premise**"话术打包：**"预警/EWM 有效的前提是储水能充当缓冲；若缓冲不足，EWM 收益有限"**——一句话立起边界，再引出敏感性结论。这会让"时间差窗口"的主张更严谨、更防审稿人攻击。
- **4.3（工程实践与阈值选择）**：Ref-B 在讨论结尾给出具体部署路径（装储气/储水设施→评估缓冲是否匹配→不足则增容）。R2 4.3 已有"阈值可校准"与"D5 vs D1 权衡"，建议**补一条"缓冲容量匹配性评估"的工程判据**（学 Ref-B 的评估→安装→增强逻辑）。
- **4.4（局限与展望）**：Ref-B 把局限写得"有边界、有余地"（"If this buffer is not enough... the effectiveness will be limited"）。R2 四项局限应逐条给"**什么条件下影响多大、如何缓解**"，而不仅是罗列。

### 3.6 Conclusions（结论）—— 对标 Ref-B 结论

Ref-B 的结论极简：**重申问题→给出方法→量化收益→现实前提→未来方向**。R2 结论已是"理论/结果/工程"三段，语言上做**"数字复位+论断精简"**：把最重要的**反事实对比**（30.17 h vs 34.33 h）放最前，把"信息介导"作为**唯一**理论主张强调，其余量化集中放第二段，工程建议分条。

---

## 四、给 R2 的针对性"语言润色清单"（可直接执行）

**A. 句式**
1. 长句拆分：把含 3 个以上 "which/that/and" 的主从复合句改为"短断言 + 独立支撑句"。
2. 被动陈述落地化：把 "was demonstrated/observed/indicated" 均配**明确主语**（数值/模型/曲线），避免空泛被动。
3. 一致使用 "**can/may/could + 明确条件**"表达意义与边界，避免 "will/definitely"。

**B. 术语（统一并按 Ref-B 的"定义先于使用"）**
4. 首次出现：time difference window、Service time（$T_{press}$）、Service value（$R_w$）、one-way ratchet、temporal reserve 均给**形式定义**。
5. **区分两组近义**：`early warning`（信息）/ `early warning management (EWM)`（控制）/ `graded demand curtailment`（动作）；`buffer`（储水/缓冲）/ `time difference window`（时间）。全程严格对应，不混用（R2 曾有 "temporal buffer/temporal reserve" 并存的隐患）。
6. 统一 `No EWM` 与 `EWM` 的大小写与连字符；`demand retention multiplier` 与 `demand multiplier` 统一。

**C. 数字与证据**
7. 所有关键数值做成对照对（before/after、with/without），并标注单位与区间。
8. "264 paired runs / phase averaged / per-phase range"每次重申时**保持一致措辞**。

**D. 段落组织**
9. 每节每段：**第一句 macro-claim → 中间展开 → 数字/证据 → 回扣句**。删掉任何"铺垫型空句"。
10. 关键对比（No/With EWM、passive/active、信息介导/储水驱动）一律用**对照表或二元短语**高度凝练，不靠散文重复。
11. 在引言、结果、讨论三处各用一个**"一句式主张 + 数字支撑"**的模板段，形成全文论证锚点。

---

## 五、一句话总结

两篇文献之所以地道，在于它们**把"主张—证据—边界"三级论证拧成了固定的段落语法**，并以**成对量化**和**二元对照**作为主要修辞手段。R2 的内容与逻辑已经到位（甚至更严格），目前的最大提升空间在于：**把 R2 每一段的"细节叙事"升级为"断言+对照+边界"的论证段**，并**用一张"被动 vs 主动"对照表**把它与 Ref-B 最核心的论证骨架对齐——这同时回应了两位审稿人对"论证透明性"的关切。
