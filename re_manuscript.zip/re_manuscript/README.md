# FEM-2026-0130 返修工作空间概览 (Workspace Overview)

**论文题目**: Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective  
**期刊**: *Frontiers of Engineering Management* (FEM)  
**决定**: Major Revision (大修)  

---

## 📁 工作空间目录结构 (Directory Navigation)

```
/home/user/
├── _docs/                                # 返修核心文档与回复信
│   ├── Response_to_Reviewers.md          # ★ 逐条答复审稿人意见的完整回复信 (含完整原文化修改段落)
│   ├── Revision_Tracking.md              # 返修意见追踪与状态表 (17条意见全覆盖)
│   └── Code_Mechanism_Analysis.md        # 仿真代码与水力/信息物理机理深度解构报告
│
├── 02_revised/                           # ★ 大修全套修正成果目录 (全新仿真、图表与正文)
│   ├── manuscript_sections/              # ★ 全套正文修改稿章节 (母语级学术语言润色)
│   │   ├── Section1_Introduction.md      # §1 引言 (对比式综述 + 时间差机理 + 凝练目标)
│   │   ├── Section2_Methodology.md         # §2 方法 (理想假设表 + EWM干预表 + 对照矩阵 + PDA公式 + 图1/2/3)
│   │   ├── Section3_Results.md           # §3 结果 (双指标核算表 + 状态时长表 + 敏感性结果表 + 图4/5/6/7/8)
│   │   ├── Section4_Discussion_and_Section5_Conclusion.md # §4 讨论 + §5 结构化结论 + 235词 Abstract
│   │   └── References.md                 # 57 篇全量去重、严格 FEM 格式排版的完整参考文献列表
│   ├── figures/                          # ★ 300 DPI 顶级出版级高清插图 (配色完全复刻原稿，无图例遮挡)
│   │   ├── Fig1.png / rev_Fig1_topology.png               # Fig. 1 Anytown 拓扑与 SCADA 部署图
│   │   ├── Fig2.png / rev_Fig2_coupling_framework.png     # Fig. 2 三层 CPS 闭环耦合架构图
│   │   ├── Fig3.png / rev_Fig3_simulation_architecture.png # Fig. 3 共仿真平台架构图
│   │   ├── Fig4.png / rev_Fig4_tanklevel.png              # Fig. 4 水池状态甘特图 + 5级状态堆叠柱状图
│   │   ├── Fig5.png / rev_Fig5_pressure.png               # Fig. 5 管网平均压力 (MPa) + 保留绩效阴影图
│   │   ├── Fig6.png / rev_R23_dualmetric.png              # Fig. 6 双指标对比柱状图 + 水量/缺水核算图
│   │   ├── Fig7.png / rev_sensitivity_service.png         # Fig. 7 敏感性分析 (时长边界 + 容积反比)
│   │   └── Fig8.png / rev_sensitivity_RI.png              # Fig. 8 敏感性分析 (双指标演化)
│   ├── code/                             # 修正后的 Python 仿真与绘图脚本
│   │   ├── sim_revised.py                # 包含 PDA 驱动与 DSR / 服务型 RI 计算的仿真主程序
│   │   ├── sensitivity.py                # 多因素敏感性扫描脚本 (阈值/容积/时长/需求)
│   │   ├── make_sensitivity_figures.py   # 敏感性图表生成脚本
│   │   └── generate_perfect_figures.py   # ★ 完美复刻原稿配色与形状的全套插图生成脚本
│   ├── results/                          # 修正后的 SQLite 仿真数据库与 CSV 结果
│   │   ├── no_ew.db / ew.db              # 72h 完整 SQLite 仿真数据库
│   │   ├── sensitivity_faultdur.csv      # 故障时长敏感性数据
│   │   ├── sensitivity_tanksize.csv      # 水池容积敏感性数据
│   │   └── sensitivity_threshold.csv     # 风险阈值敏感性数据
│   └── supplementary/                    # 补充材料
│       └── sensitivity_demand.csv        # 需求模式扫描数据
│
├── 01_original/                          # 原始提交版本基线 (原封不动保留，支持复现)
│   ├── code/sim_original.py              # 原始代码
│   ├── results/no_ew.db / ew.db          # 原始复现数据库 (压力 RI 0.22 vs 0.84)
│   └── figures/                          # 原始对比插图
│
└── uploads/                              # 原始上传文件与参考论文
    ├── Main document(without Author Details).pdf # 原始提交稿件 PDF
    ├── 返修意见20260715.pdf              # 期刊决策信与审稿意见 PDF
    ├── s42524-026-5359-0.pdf             # FEM 最新发表范文
    └── 孙宏斌院士团队...pdf               # 信息物理预警与主动控制顶刊范文
```

---

## 🎯 大修核心成果与硬核数据总结 (Key Revision Highlights)

1. **服务型双指标与硬核水量核算 (回应 R2.3, R1.5)**：
   * 实际交付水量增加 **+36.2% (+489.6 m³)** ($1,353.5 \to 1,843.1\text{ m}^3$)；
   * 缺水总量减少 **-8.8% (-489.6 m³)** ($6,469.3 \to 5,979.7\text{ m}^3$)；
   * 服务型韧性指数 **$RI_{service}: 0.23 \to 0.29$ (+0.058)**；压力型韧性指数 **$RI_{pressure}: 0.22 \to 0.84$ (+0.62)**。
2. **干预动作透明化与控制矩阵 (回应 R2.1, R2.2)**：
   * 明确 EWM 对应 **70% / 40% / 20% 分级需求削减**、Ratchet 单向防抖动与 48h 自动重置；
   * 给出侧重说明表，证实基线与 EWM 共享完全相同的 EPANET PDA 求解器、300s 时间步与 0.50m 出流关断规则。
3. **范围明确与三层机制解构 (回应 R2.4, R1.6)**：
   * 明确通信延迟/丢包为超出范围的抽象；解构 **“感知层 $\to$ 控制层 $\to$ 物理层”** 三层闭环协同。
4. **多因素敏感性与运行应用边界 (回应 R2.5)**：
   * 提炼出 **“EWM 运行应用边界规则”**：轻胁迫（12h）可能导致轻度过度限流（交付量 −4.7%），但在中高胁迫（$\ge 18\text{ h}$ 长故障、小储量水池）下能带来极其显著的服务增益（交付量 +36.2% ~ +117.9%）。
5. **母语级语言润色与参考文献规范 (回应 R1.1, R1.2, R1.7, R1.8, R1.9, R1.10, R1.11)**：
   * 对齐 FEM 顶刊范式与孙宏斌院士团队论文的领域用词；废除不必要的分条罗列，改用高阶连续学术段落；
   * 57 篇参考文献全量去重、严格按 FEM 官方格式排版，并实现与正文中引用的 100% 闭环匹配。
