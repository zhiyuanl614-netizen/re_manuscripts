# 代码机制分析（用于回应 Reviewer 2）

## 代码揭示的真实机制

### 1. EWM 的"具体动作"= 分级需求削减（Graded Demand Curtailment）
`EarlyWarningSystem.LEVELS`:
- WARNING (H < 5.0 m) → demand × 0.70
- ALERT   (H < 4.0 m) → demand × 0.40
- CRITICAL(H < 2.0 m) → demand × 0.20

→ 进入某一级预警后，通过 `_update_demand_factor` 把全网节点需求按系数缩放。
→ 这是一个**真实的、可操作的干预动作**（限流/需求管理），不是"仅报警"。
→ ratchet 机制：等级只升不降（`worst_level < current_level` 时保持），故障结束(48h)后恢复 100%。
→ 触发条件双门控：必须 (a) 处于故障期 且 (b) 水泵物理状态=0（水源中断）。

### 2. 对比是否公平（R2.2）—— 可以有力反驳
NoEWSim 与 EWSim **共用同一个基类 SteppedSim**：
- 同一水力引擎（WNTR + EPANET 2.2，300s 步进）
- 同一出口关断规则（tank < 0.5 m → 出流管关闭，OUTLET_HEIGHT=0.5）
- 同一 RI 公式：RI(t)=raw_avg(t)/P0（故障期），=1.0（故障前后）
- **唯一差别**：NoEW 的 ew_demand_reduction 恒=1.0；EW 按预警等级削减。
→ 因此"基线骤降到0、EW平稳"并非两套规则，而是**同一套规则下"削不削需求"的自然结果**：
   NoEW 需求维持 1.5×，水池 6h 内耗尽→出口关断→压力归零；
   EW 削减需求→水池耗尽变慢→更久维持 >0.5m→压力维持。
→ R2.2 的"不公平对比"担忧可被证伪，但**必须在正文写透明**。

### 3. 性能函数只测压力，不计 unmet demand（R2.3）—— 最致命，审稿人说对了
`_calc_raw_avg_pressure` = 全节点 max(0, head-elev) 的平均；RI = 该均值/P0。
→ EWM"维持压力"正是**靠削减需求**（削到20%~70%）实现的。
→ 但 RI 只测压力，**完全没计入被削掉的那部分需求（unmet demand）**。
→ 审稿人原话完全命中："maintaining pressure may be achieved by curtailing demand;
   if unmet demand is not included, RI reflects preserved pressure rather than delivered service."
→ 这是**必须修的有效性问题**。且 EPANET 默认是需求驱动(DDA)，水池枯竭时压力失真，更需正视。

### 4. 信息层理想化（R2.4）
代码确认：无通信延迟/感知误差/丢包/PLC反馈建模，信息层=理想阈值分类。
→ 应作为**显式假设**声明（连 R1.3），定位为"可获收益的上界"。
→ 通信延迟/丢包/感知误差不属于本文研究重点（聚焦时间差预警），不建模；作为独立后续方向说明。

### 5. 可参数化 → 支持敏感性分析（R2.5）
demand_factor / fault_start / fault_duration / LEVELS阈值 均可调 → 可做敏感性。

### 6. T1/T2 数值 & 摘要单值（R2.6）
Anytown 中 T1/T2 配置对称、同阈值 → 时长接近可解释；EW后两者Outlet Failure均=12.08h（需说明为何完全相同）。摘要用单值需与表内双值口径统一。
