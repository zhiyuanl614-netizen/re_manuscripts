"""生成原版本图（对应论文 Fig4 水位 / Fig5 压力 / Fig6 RI），读取 results/*.db"""
import sqlite3, pandas as pd, numpy as np, os
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=os.path.dirname(__file__); RES=os.path.join(BASE,'results'); FIG=os.path.join(BASE,'figures')
os.makedirs(FIG,exist_ok=True)
TD,TR=24,48
NO=os.path.join(RES,'no_ew.db'); EW=os.path.join(RES,'ew.db')
def lp(db):
    c=sqlite3.connect(db);d=pd.read_sql("SELECT timestamp,RI,avg_pressure FROM performance_data ORDER BY timestamp",c);c.close();d['t']=d['timestamp']/3600;return d
def lt(db,tid):
    c=sqlite3.connect(db);d=pd.read_sql(f"SELECT timestamp,value FROM sensor_data WHERE sensor_id='{tid}' ORDER BY timestamp",c);c.close();d['t']=d['timestamp']/3600;return d

# Fig5-like: pressure (MPa)
n,e=lp(NO),lp(EW)
plt.figure(figsize=(10,5.5))
plt.plot(n['t'],n['avg_pressure']*0.009807,'r--',lw=2,label='Without EWM')
plt.plot(e['t'],e['avg_pressure']*0.009807,'g-',lw=2,label='With EWM')
plt.axhline(0.10,color='gray',ls=':',label='Critical threshold 0.10 MPa')
plt.axvspan(TD,TR,alpha=.08,color='orange',label='Fault (24-48h)')
plt.xlabel('Time (h)');plt.ylabel('Average network pressure (MPa)')
plt.title('Fig.5 (original) Average network pressure');plt.legend();plt.grid(alpha=.3)
plt.tight_layout();plt.savefig(os.path.join(FIG,'orig_Fig5_pressure.png'),dpi=150);plt.close()

# Fig6-like: RI(t)
plt.figure(figsize=(10,5.5))
plt.plot(n['t'],n['RI'],'r--',lw=2,label='Without EWM (RI=0.22)')
plt.plot(e['t'],e['RI'],'g-',lw=2,label='With EWM (RI=0.84)')
plt.axvspan(TD,TR,alpha=.08,color='orange',label='Fault (24-48h)')
plt.xlabel('Time (h)');plt.ylabel('RI(t)');plt.ylim(-.05,1.1)
plt.title('Fig.6 (original) Resilience Index (pressure-based)');plt.legend();plt.grid(alpha=.3)
plt.tight_layout();plt.savefig(os.path.join(FIG,'orig_Fig6_RI.png'),dpi=150);plt.close()

# Fig4-like: tank levels
plt.figure(figsize=(10,5.5))
for tid,c1,c2 in [('T1','#C64C3E','#2A916F'),('T2','#E07B39','#355E91')]:
    dn,de=lt(NO,tid),lt(EW,tid)
    plt.plot(dn['t'],dn['value'],'--',color=c1,lw=1.8,label=f'{tid} Without EWM')
    plt.plot(de['t'],de['value'],'-',color=c2,lw=1.8,label=f'{tid} With EWM')
for thr,lab in [(5.0,'Warning'),(4.0,'Alert'),(2.0,'Critical'),(0.5,'Outlet')]:
    plt.axhline(thr,color='gray',ls=':',alpha=.5)
plt.axvspan(TD,TR,alpha=.08,color='orange')
plt.xlabel('Time (h)');plt.ylabel('Tank water level (m)')
plt.title('Fig.4 (original) Tank water levels & risk states');plt.legend(fontsize=8);plt.grid(alpha=.3)
plt.tight_layout();plt.savefig(os.path.join(FIG,'orig_Fig4_tanklevel.png'),dpi=150);plt.close()
print("saved 3 figures to", FIG)
