# 01_original — 原版本（投稿版）代码与结果存档

本目录保存论文 **FEM-2026-0130 投稿版本** 的仿真代码、输入、运行结果与图，作为返修的基线（baseline），**不再修改**。修正版本见 `../02_revised/`。

## 目录结构
```
01_original/
├── code/
│   └── sim_original.py          # 还原自作者投稿版代码（修复了粘贴转义）
├── input/
│   └── anytown.inp              # Anytown 基准网络（PDA 模型）
├── results/
│   ├── no_ew.db                 # 无预警(Without EWM)仿真数据库
│   └── ew.db                    # 有预警(With EWM)仿真数据库
├── figures/
│   ├── orig_Fig4_tanklevel.png  # 对应论文 Fig.4 水池水位/风险状态
│   ├── orig_Fig5_pressure.png   # 对应论文 Fig.5 平均管网压力
│   └── orig_Fig6_RI.png         # 对应论文 Fig.6 韧性指数 RI(t)
├── extract_original_results.py  # 从 db 抽取全部指标并与论文核对
└── make_original_figures.py     # 生成上述三张图
```

## 关键机制（原版本）
- **故障场景**：水源中断，泵 P1/P2 于 24–48h 强制停运，水池无补水。
- **EWM 动作**：分级需求削减（限流）——
  - WARNING (H<5.0m) → 需求×0.70
  - ALERT   (H<4.0m) → 需求×0.40
  - CRITICAL(H<2.0m) → 需求×0.20
  - ratchet：等级只升不降；48h 故障解除后恢复 100%。
- **性能指标 RI**：仅由压力定义 —— `RI(t)=avg_pressure(t)/P0`（故障前后=1.0），
  标量 `RI=∫[td→tr]RI(t)dt/(tr−td)`。**这是被审稿人 R2.3 质疑的核心：只测压力、不计实际交付水量。**

## 运行结果 vs 论文报告（复现核对）

| 指标 | 本次复现 (No EW → With EW) | 论文报告 | 核对 |
|------|---------------------------|----------|------|
| Resilience Index RI | 0.216 → 0.837 (Δ+0.62) | 0.22 → 0.84 (Δ+0.62) | ✓ |
| 平均管网压力 | 0.117 → 0.453 MPa | 0.12 → 0.45 MPa | ✓ |
| T1 平均水位 | 1.14 → 1.64 m | 1.14 → 1.64 m | ✓ |
| T2 平均水位 | 1.09 → 1.60 m | 1.09 → 1.60 m | ✓ |
| Alert 时长 (T1/T2) | 1.33 → 3.33 h | 1.33 → 3.33 h | ✓ |
| Critical 时长 (T1/T2) | 1.00 → 5.08 h | 1.00 → 5.08 h | ✓ |
| Outlet Failure 时长 | 18.50/18.58 → 12.17 h | 18.42/18.50 → 12.08 h | ✓(步长边界微差) |

EWM 触发时序：WARNING@26.5h → ALERT@27.5h → CRITICAL@30.83h。

> **结论**：原版本代码可完整复现论文全部关键数字，作为返修基线可靠。
> 原版本的局限（R2.3：RI 仅测压力，未计 unmet demand）将在 `02_revised/` 中修正。

## 复现方法
```bash
cd 01_original
python3 code/sim_original.py          # 重跑仿真（约1分钟），生成 db
python3 extract_original_results.py   # 抽取指标并与论文核对
python3 make_original_figures.py      # 生成三张图
```
