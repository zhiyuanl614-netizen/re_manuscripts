"""绘制 R2.5 敏感性分析图：4因素 × (压力型RI vs 服务型RI)"""
import os, pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

RES='../results'; FIG='../figures'; os.makedirs(FIG,exist_ok=True)
specs=[('threshold','Threshold shift (m)','threshold_shift',None),
       ('tanksize','Tank diameter scale','diameter_scale',None),
       ('faultdur','Fault duration (h)','fault_duration',3600)]

fig,axes=plt.subplots(1,3,figsize=(18,5.5))
for ax,(name,xlabel,col,div) in zip(axes.flat,specs):
    df=pd.read_csv(os.path.join(RES,f'sensitivity_{name}.csv'))
    x=df[col]/div if div else df[col]
    ax.plot(x,df['RI_p_ew'],'g-o',lw=2,label='Pressure-RI (With EW)')
    ax.plot(x,df['RI_p_no'],'g--o',lw=1.5,alpha=.6,label='Pressure-RI (No EW)')
    ax.plot(x,df['RI_s_ew'],'b-s',lw=2,label='Service-RI (With EW)')
    ax.plot(x,df['RI_s_no'],'b--s',lw=1.5,alpha=.6,label='Service-RI (No EW)')
    ax.axhline(0,color='gray',lw=.8)
    ax.set_xlabel(xlabel); ax.set_ylabel('Resilience Index')
    ax.set_title(f'Sensitivity to {xlabel}',fontsize=11)
    ax.grid(alpha=.3); ax.legend(fontsize=8)
fig.suptitle('R2.5 Sensitivity Analysis: pressure-based vs service-based RI',
             fontsize=13,fontweight='bold')
fig.tight_layout()
fig.savefig(os.path.join(FIG,'rev_sensitivity_RI.png'),dpi=150,bbox_inches='tight')
print('saved rev_sensitivity_RI.png')

# second figure: delivered-water gain & unmet reduction (the honest service story)
fig2,axes2=plt.subplots(1,3,figsize=(18,5.5))
for ax,(name,xlabel,col,div) in zip(axes2.flat,specs):
    df=pd.read_csv(os.path.join(RES,f'sensitivity_{name}.csv'))
    x=df[col]/div if div else df[col]
    ax.bar(np.arange(len(x))-0.2,df['deliv_gain_pct'],width=0.4,label='Delivered water gain (%)',color='#2A916F')
    ax.bar(np.arange(len(x))+0.2,df['unmet_red_pct'],width=0.4,label='Unmet demand reduction (%)',color='#355E91')
    ax.axhline(0,color='k',lw=1)
    ax.set_xticks(np.arange(len(x))); ax.set_xticklabels([f'{v:g}' for v in x])
    ax.set_xlabel(xlabel); ax.set_ylabel('% change (With EW vs No EW)')
    ax.set_title(f'Service benefit vs {xlabel}',fontsize=11)
    ax.grid(alpha=.3,axis='y'); ax.legend(fontsize=8)
fig2.suptitle('R2.5 Service-level benefit of EWM (delivered water & unmet demand)',
              fontsize=13,fontweight='bold')
fig2.tight_layout()
fig2.savefig(os.path.join(FIG,'rev_sensitivity_service.png'),dpi=150,bbox_inches='tight')
print('saved rev_sensitivity_service.png')
