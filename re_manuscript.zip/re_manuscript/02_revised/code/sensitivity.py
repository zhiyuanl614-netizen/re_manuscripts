"""
R2.5 Sensitivity & Robustness Analysis
======================================
Sweeps four factors requested by Reviewer 2 (Comment 2.5):
  (1) demand pattern (demand_factor)
  (2) risk thresholds (level thresholds shifted uniformly)
  (3) tank size (tank diameter scaled)
  (4) fault assumption (fault duration)

For every configuration BOTH resilience metrics are reported:
  - pressure-based RI (original paper metric)
  - service-based RI (delivered/required, R2.3)
plus delivered water volume and unmet demand.

Run from 02_revised/code/ :  python3 sensitivity.py
Outputs: ../results/sensitivity_*.csv
"""
import os, sqlite3, copy
import numpy as np
import pandas as pd

import sim_revised as S

INP = '../input/anytown.inp'
OUT = '../results'
os.makedirs(OUT, exist_ok=True)

TIMESTEP = 300


def run_config(mode, demand_factor=1.5, fault_duration=24*3600,
               threshold_shift=0.0, diameter_scale=1.0,
               fault_start=24*3600, duration=3*24*3600, tag='cfg'):
    """Run one simulation with optional threshold shift / tank diameter scaling."""
    db_path = os.path.join(OUT, f'_sens_{tag}_{mode}.db')
    if os.path.exists(db_path):
        os.remove(db_path)

    fault = S.WaterSourceInterruption(fault_start, fault_duration, affected_pumps=None)
    SimClass = S.NoEWSim if mode == 'no_ew' else S.EWSim
    sim = SimClass(INP, db_path, TIMESTEP, fault_scenario=fault,
                   demand_factor=demand_factor, verbose=False)

    # (3) tank size: scale tank diameters (changes storage capacity)
    if abs(diameter_scale - 1.0) > 1e-9:
        for t in sim.tanks:
            node = sim.wn.get_node(t)
            node.diameter = node.diameter * diameter_scale

    # (2) thresholds: shift the three warning levels uniformly (floor at small +ve)
    if mode == 'ew' and abs(threshold_shift) > 1e-9:
        new_levels = []
        for name, thr, rd, rank in sim.ews.LEVELS:
            new_levels.append((name, max(0.6, thr + threshold_shift), rd, rank))
        sim.ews.LEVELS = new_levels
        sim.ews.THRESHOLD_MAP = {lv: thr for lv, thr, _, _ in new_levels}
        sim.ews.REDUCTION_MAP = {lv: rd for lv, _, rd, _ in new_levels}
        sim.ews.REDUCTION_MAP['NORMAL'] = 1.0

    sim.run(duration)
    P0 = sim.P0
    sim.close()

    fault_end = fault_start + fault_duration
    ri_p = S.calc_RI(db_path, fault_start, fault_end, col='RI')
    ri_s = S.calc_RI(db_path, fault_start, fault_end, col='RI_service')
    unmet, req_v, del_v = S.unmet_demand_volume(db_path, fault_start, fault_end)
    os.remove(db_path)  # keep results dir tidy; keep only summary CSVs
    return dict(RI_p=ri_p, RI_s=ri_s, unmet=unmet, req=req_v, deliv=del_v, P0=P0)


def compare(**kw):
    n = run_config('no_ew', **kw)
    e = run_config('ew', **kw)
    return dict(
        RI_p_no=n['RI_p'], RI_p_ew=e['RI_p'], dRI_p=e['RI_p']-n['RI_p'],
        RI_s_no=n['RI_s'], RI_s_ew=e['RI_s'], dRI_s=e['RI_s']-n['RI_s'],
        deliv_no=n['deliv'], deliv_ew=e['deliv'],
        deliv_gain_pct=(e['deliv']-n['deliv'])/n['deliv']*100 if n['deliv'] else np.nan,
        unmet_no=n['unmet'], unmet_ew=e['unmet'],
        unmet_red_pct=(n['unmet']-e['unmet'])/n['unmet']*100 if n['unmet'] else np.nan,
    )


def sweep(name, param, values, fixed):
    rows = []
    for v in values:
        kw = dict(fixed)
        kw[param] = v
        kw['tag'] = f'{name}_{v}'
        print(f"  [{name}] {param}={v} ...", flush=True)
        r = compare(**{k: kw[k] for k in kw if k != 'tag'}, tag=kw['tag'])
        r = {param: v, **r}
        rows.append(r)
    df = pd.DataFrame(rows)
    path = os.path.join(OUT, f'sensitivity_{name}.csv')
    df.to_csv(path, index=False, encoding='utf-8-sig')
    print(f"  -> saved {path}")
    return df


if __name__ == '__main__':
    BASE = dict(demand_factor=1.5, fault_duration=24*3600,
                threshold_shift=0.0, diameter_scale=1.0)

    print("="*64)
    print("R2.5 SENSITIVITY ANALYSIS  (both pressure-RI & service-RI)")
    print("="*64)

    print("\n(1) Demand factor sweep")
    df1 = sweep('demand', 'demand_factor', [1.0, 1.25, 1.5, 1.75, 2.0], BASE)

    print("\n(2) Threshold shift sweep (m)")
    df2 = sweep('threshold', 'threshold_shift', [-1.0, -0.5, 0.0, 0.5, 1.0], BASE)

    print("\n(3) Tank diameter scale sweep")
    df3 = sweep('tanksize', 'diameter_scale', [0.6, 0.8, 1.0, 1.2, 1.4], BASE)

    print("\n(4) Fault duration sweep (h)")
    df4 = sweep('faultdur', 'fault_duration',
                [12*3600, 18*3600, 24*3600, 36*3600, 48*3600], BASE)

    print("\nDONE. Summary CSVs in", OUT)
