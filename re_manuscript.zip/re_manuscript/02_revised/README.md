# 02_revised 目录说明 (Revised Deliverables Navigation)

本目录包含了本次 **Major Revision (大修)** 的全部最终重算与修改成果。

---

## 📂 目录子项导航

* **`manuscript_sections/`**：★ **全套正文修改稿件**（已按 FEM 顶刊范式与孙宏斌院士团队用词完成高阶母语级润色，去除了不必要的分条罗列）
  * `Section1_Introduction.md`：引言（对比式综述 + 孙院士团队式时间差机理 + 凝练目标）
  * `Section2_Methodology.md`：方法（理想假设表 + EWM干预表 + 对照矩阵 + PDA公式 + 图1/2/3）
  * `Section3_Results.md`：结果（双指标核算表 + 水池状态表 + 敏感性结果表 + 图4/5/6/7/8）
  * `Section4_Discussion_and_Section5_Conclusion.md`：讨论、结论与 235 词 Abstract
  * `References.md`：57 篇全量去重、严格按 FEM 官方格式排版的完整参考文献列表

* **`figures/`**：★ **300 DPI 顶级出版级插图**（配色完全复刻原稿，无图例遮挡，标题不写在画布内部）
  * `Fig1.png` / `rev_Fig1_topology.png`：Anytown 拓扑与 SCADA 部署图
  * `Fig2.png` / `rev_Fig2_coupling_framework.png`：三层 CPS 闭环耦合架构图
  * `Fig3.png` / `rev_Fig3_simulation_architecture.png`：共仿真平台架构图
  * `Fig4.png` / `rev_Fig4_tanklevel.png`：水池状态甘特图 + 5级状态堆叠柱状图
  * `Fig5.png` / `rev_Fig5_pressure.png`：管网平均压力 (MPa) + 保留绩效阴影图
  * `Fig6.png` / `rev_R23_dualmetric.png`：双指标对比柱状图 + 水量/缺水核算图
  * `Fig7.png` / `rev_sensitivity_service.png`：敏感性分析 (时长边界 + 容积反比)
  * `Fig8.png` / `rev_sensitivity_RI.png`：敏感性分析 (双指标演化)

* **`code/`**：修正后的 Python 仿真与绘图脚本
  * `sim_revised.py`：包含 EPANET PDA 驱动与 DSR / 服务型 RI 计算的仿真主程序
  * `sensitivity.py`：多因素敏感性扫描脚本
  * `generate_perfect_figures.py`：★ 全套高清出版插图生成脚本

* **`results/`**：修正后的 SQLite 仿真数据库与 CSV 数据集
  * `no_ew.db` / `ew.db`：72h 完整 SQLite 仿真数据库
  * `sensitivity_faultdur.csv` / `sensitivity_tanksize.csv` / `sensitivity_threshold.csv`：敏感性结果表

* **`supplementary/`**：补充材料数据集
  * `sensitivity_demand.csv`：需求模式扫描数据
