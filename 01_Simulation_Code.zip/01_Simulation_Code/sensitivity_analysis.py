"""
供水系统主动预警控制鲁棒性扫描：四维敏感性分析主程序（校准输出列名版）
扫描维度包括：
1. 预警阈值划分形态 (Threshold Interval Designs, 限制在 0.5 ~ 5.0 m 之间)
2. 水箱直径缩放比例 (Tank Diameter Scale, 0.6x ~ 1.4x)
3. 极端断水持续时长 (Outage Duration, 12h ~ 48h)
4. 相对运行用水负载因子 (Relative Demand Load Factor, 0.6x ~ 1.4x, 基准为 1.0)
"""

import os
import sqlite3
import numpy as np
import pandas as pd
import wntr

# 导入主仿真的类和方法
import sim_main as S

INP = "../03_Data_Files/anytown.inp"
OUT_DIR = "../04_Simulation_Results"
os.makedirs(OUT_DIR, exist_ok=True)

TIMESTEP = 300
DEFAULT_DURATION = 3 * 24 * 3600  # 72 小时
FAULT_START = 24 * 3600


def run_config(mode, intensity_lambda=1.0, fault_duration=24*3600, 
               diameter_scale=1.0, threshold_levels=None, tag="sa"):
    """
    运行特定参数下的单次仿真并返回评估指标
    """
    db_path = os.path.join(OUT_DIR, f"_sens_{tag}_{mode}.db")
    if os.path.exists(db_path):
        os.remove(db_path)
        
    fault = S.WaterSourceInterruption(FAULT_START, fault_duration, affected_pumps=None)
    SimClass = S.NoEWSim if mode == "no_ew" else S.EWSim
    
    # 实例化仿真器
    sim = SimClass(
        INP, db_path, TIMESTEP, fault_scenario=fault, verbose=False,
        intensity_lambda=intensity_lambda
    )
    
    # 1. 缩放水箱直径
    if abs(diameter_scale - 1.0) > 1e-9:
        for t in sim.tanks:
            sim.wn.get_node(t).diameter *= diameter_scale
            
    # 2. 修改预警阈值列表
    if mode == "ew" and threshold_levels is not None:
        sim.ews.LEVELS = threshold_levels
        sim.ews.THRESHOLD_MAP = {lv: thr for lv, thr, _, _ in threshold_levels}
        sim.ews.REDUCTION_MAP = {lv: rd for lv, _, rd, _ in threshold_levels}
        sim.ews.REDUCTION_MAP["NORMAL"] = 1.0
        
    # 运行仿真
    sim.run(DEFAULT_DURATION)
    sim.close()
    
    # 提取故障期间的评估指标
    fault_end = FAULT_START + fault_duration
    ri_p = S.calc_RI(db_path, FAULT_START, fault_end, col="RI")
    unmet, req_v, del_v = S.unmet_demand_volume(db_path, FAULT_START, fault_end)
    
    # 删除临时数据库
    if os.path.exists(db_path):
        os.remove(db_path)
        
    return dict(RI_p=ri_p, delivered=del_v, required=req_v)


def compare_scenarios(**kw):
    """
    对比有无预警的场景
    """
    n = run_config("no_ew", **kw)
    e = run_config("ew", **kw)
    return dict(
        RI_p_no=n["RI_p"], RI_p_ew=e["RI_p"], dRI_p=e["RI_p"] - n["RI_p"],
        deliv_no=n["delivered"], deliv_ew=e["delivered"],
        deliv_gain_pct=(e["delivered"] - n["delivered"]) / n["delivered"] * 100 if n["delivered"] > 0 else 0.0,
    )


# ============================================================================
# 敏感性实验定义
# ============================================================================

def run_threshold_sweep():
    print("\n--- 实验 1: 预警阈值划分形态敏感性扫描 ---")
    # 5种对称等间距设计
    designs = {
        "Design_1_Late":    [('CRITICAL', 1.0, 0.20, 3), ('ALERT', 3.0, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
        "Design_2_MidLate": [('CRITICAL', 1.5, 0.20, 3), ('ALERT', 3.25, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
        "Design_3_Symmetric": [('CRITICAL', 2.0, 0.20, 3), ('ALERT', 3.5, 0.40, 2), ('WARNING', 5.0, 0.70, 1)], # 基准
        "Design_4_MidEarly": [('CRITICAL', 2.5, 0.20, 3), ('ALERT', 3.75, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
        "Design_5_Early":   [('CRITICAL', 3.0, 0.20, 3), ('ALERT', 4.0, 0.40, 2), ('WARNING', 5.0, 0.70, 1)],
    }
    
    rows = []
    for name, levels in designs.items():
        print(f"  正在模拟: {name} ...")
        res = compare_scenarios(threshold_levels=levels, tag=f"thr_{name}")
        rows.append({"Design": name, **res})
        
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT_DIR, "sensitivity_threshold.csv"), index=False, encoding="utf-8-sig")
    print("  -> 保存至 sensitivity_threshold.csv")
    print(df[["Design", "RI_p_no", "RI_p_ew", "deliv_gain_pct"]])


def run_tank_size_sweep():
    print("\n--- 实验 2: 水箱直径缩放敏感性扫描 ---")
    scales = [0.6, 0.8, 1.0, 1.2, 1.4]
    rows = []
    for s in scales:
        print(f"  正在模拟: 直径 = {s}x ...")
        res = compare_scenarios(diameter_scale=s, tag=f"tank_{s}")
        rows.append({"diameter_scale": s, **res})
        
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT_DIR, "sensitivity_tanksize.csv"), index=False, encoding="utf-8-sig")
    print("  -> 保存至 sensitivity_tanksize.csv")
    print(df[["diameter_scale", "RI_p_no", "RI_p_ew", "deliv_gain_pct"]])


def run_fault_duration_sweep():
    print("\n--- 实验 3: 断水持续时长敏感性扫描 ---")
    durations_h = [12, 18, 24, 36, 48]
    rows = []
    for h in durations_h:
        print(f"  正在模拟: 停水 = {h}小时 ...")
        res = compare_scenarios(fault_duration=h * 3600, tag=f"dur_{h}")
        rows.append({"fault_duration": h * 3600, **res})
        
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT_DIR, "sensitivity_faultdur.csv"), index=False, encoding="utf-8-sig")
    print("  -> 保存至 sensitivity_faultdur.csv")
    print(df[["fault_duration", "RI_p_no", "RI_p_ew", "deliv_gain_pct"]])


def run_load_factor_sweep():
    print("\n--- 实验 4: 相对运行负载因子敏感性扫描 ---")
    loads = [0.6, 0.8, 1.0, 1.2, 1.4]
    rows = []
    for l in loads:
        print(f"  正在模拟: 用水负载 = {l}x ...")
        res = compare_scenarios(intensity_lambda=l, tag=f"load_{l}")
        rows.append({"Relative_Load": l, **res})
        
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT_DIR, "sensitivity_loadfactor.csv"), index=False, encoding="utf-8-sig")
    print("  -> 保存至 sensitivity_loadfactor.csv")
    print(df[["Relative_Load", "RI_p_no", "RI_p_ew", "deliv_gain_pct"]])


if __name__ == "__main__":
    print("=" * 64)
    print("  启动城市给水管网韧性四维敏感性分析实验")
    print("  底层求解器: EPANET 2.2 PDA 模式")
    print("  基准用水模型: Anytown ADD 3h (λ* 已折叠)")
    print("=" * 64)
    
    # 依次执行四项敏感性实验
    run_threshold_sweep()
    run_tank_size_sweep()
    run_fault_duration_sweep()
    run_load_factor_sweep()
    
    print("\n" + "=" * 64)
    print("  所有敏感性分析实验运行完毕！数据已保存至 04_Simulation_Results 目录。")
    print("=" * 64)
