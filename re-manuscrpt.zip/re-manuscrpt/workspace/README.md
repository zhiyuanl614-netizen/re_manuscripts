# FEM-2026-0130 返修工作空间（R2 终态）

> 更新日期：2026-08-24 ｜ 稿件：*Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective* ｜ 期刊：ENGINEERING Management ｜ 返修截止：2026-09-14

## 一、现行口径（不变）

| 决策 | 内容 |
|---|---|
| 韧性指标 | **Service time (T_press)**（时间域）+ **Service value (R_w = W/(S*·α_max))**（价值域）；图轴名称用 Service time / Service value |
| 敏感性 | 仅 Service time，四维×4 相位共 264 对运行；唯一敏感性图 Fig. 6 |
| EWM | D3 三级棘轮：WARNING/ALERT/CRITICAL = 5.0/3.5/2.0 m，γ = 0.7/0.4/0.2 |
| 术语 | time difference window；情景标签 No EWM / EWM |
| 事件链 | 触发 26.08/28.00/30.83 h；隔离 30.17→34.33 h（+4.17 h，两箱同一步长，步内错位 1.6–2.6 min） |

## 二、权威数值（results/ 复核）

| 指标 | No EWM | EWM | 变化 |
|---|---|---|---|
| Service time | 6.17 h | 10.33 h | +67.6% |
| Service value | 0.496 | 0.609 | +23.0% |
| W（加权服务量） | 745.3 | 916.2 m³·pattern | +22.9% |
| 交付体积 | 1,095.2 | 1,088.3 m³ | −0.6%（不造水，只重分配） |
| 出口失效时长(窗内) | 17.83 h | 13.67 h | 每箱一致 |

锚：S* = 1,156.44 m³，α_max = 1.30，天花板 = 1,503.37 m³·pattern（两情景共享）。

## 三、目录导航

```
workspace/
├── README.md                 ← 本文件
├── code/
│   ├── sim_main.py                    # 主仿真（步进 CPS 闭环）
│   ├── demand_patterns.py             # Anytown 8×3h 需水模式
│   ├── sensitivity_analysis_v2.py     # 四维×4相位敏感性
│   ├── junction_pressure_log.py       # 双情景节点压力记录（热力图数据）
│   └── generate_figures_v2.py         # ★ 图件权威脚本（Fig1–6, 300 DPI, Arial）
├── data/anytown.inp                  # Anytown 管网（PDA 配置）
├── results/                          # 权威数据：no_ew.db / ew.db + 敏感性 CSV×8 + 节点压力 CSV×2
├── figures/                          # Fig1–6（定稿）
├── fonts/                            # arial.ttf / arialbd.ttf（脚本自动注册）
├── .local/                           # wntr 1.5.0 运行环境
└── documents/
    ├── #返修意见20260715.pdf          # 审稿意见（R1 七条 + R2 六条）
    ├── Main document(...).pdf         # 原稿件
    ├── Manuscript_R1定稿.pdf          # 修改稿1（R2 编辑基底）
    ├── Revised_Abstract_EN.md         # 摘要+关键词（R2）
    ├── Revised_Section_1..5_EN.md     # 引言/方法/结果/讨论/结论（R2 六章）
    ├── References_Consolidated_R2.md  # 合并去重文献表（75 条）
    ├── Manuscript_R2_highlighted.docx # ★ 合稿（蓝标修订版，6 图 2 表）
    ├── Response_Letter_R2_detailed.md # ★ 逐条分点回复信（20 问答块）
    ├── 02_方法定格与R2稿件数值映射.md  # 方法定格对照（历史权威）
    ├── 03_论文框架_方法结果讨论_图文对应.md
    └── 04_审稿意见呼应核验.md          # 意见-落点核验矩阵
```

## 四、快速复现

```bash
cd code
# 1) 基准仿真（重生成 results/*.db，约 40 s）
PYTHONPATH=../.local/lib/python3.13/site-packages python3 sim_main.py
# 2) 节点压力记录（热力图数据，约 36 s）
PYTHONPATH=../.local/lib/python3.13/site-packages python3 junction_pressure_log.py
# 3) 敏感性（264 对运行，可设 SENSITIVITY_WORKERS）
PYTHONPATH=../.local/lib/python3.13/site-packages python3 sensitivity_analysis_v2.py
# 4) 图件（Fig1–6）
python3 generate_figures_v2.py        # 自动注册 fonts/ 下的 Arial
```

## 五、遗留事项

- Juan Garcia et al. (2017)：引言引用但两版文献表均无条目，作者需补齐或替换（已在文献表标注）。
- 公式在 docx 中为纯文本，投稿前需在 Word 公式编辑器中终排。
