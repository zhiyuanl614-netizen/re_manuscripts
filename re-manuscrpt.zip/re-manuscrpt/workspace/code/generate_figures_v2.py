"""Figures v2 — new-framework figure set (Results 3.1-3.4).

Fig1  Anytown topology                              (kept)
Fig2  Co-simulation platform architecture (Sec 2.4-aligned)
Fig3  Baseline failure evolution: per-tank filled levels + junction-pressure heatmap (Sec 3.1)
Fig4  EWM activation: decision trace + per-tank levels + EWM pressure heatmap, 2x2 (Sec 3.2)
Fig5  Service value / Service time bars             (was Fig6)
Fig6  Sensitivity, phase-averaged + min-max         (Sec 3.4 sole sensitivity figure)
"""
import os
import sqlite3
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.lines import Line2D

_HERE = os.path.dirname(os.path.abspath(__file__))
FIG_DIR = os.path.join(_HERE, '..', 'figures')
RESULTS_DIR = os.path.join(_HERE, '..', 'results')
FONT_DIR = os.path.join(_HERE, '..', 'fonts')
if os.path.isdir(FONT_DIR):
    from matplotlib import font_manager as _fm
    for _f in sorted(os.listdir(FONT_DIR)):
        if _f.lower().endswith('.ttf'):
            _fm.fontManager.addfont(os.path.join(FONT_DIR, _f))
from matplotlib import font_manager as _fmi
ARIAL = 'Arial' if any(f.name == 'Arial' for f in _fmi.fontManager.ttflist) else 'Liberation Sans'
plt.rcParams['font.family'] = ARIAL
plt.rcParams['font.sans-serif'] = [ARIAL, 'DejaVu Sans']
plt.rcParams['axes.edgecolor'] = '#BDC3C7'
plt.rcParams['axes.linewidth'] = 0.8
plt.rcParams['grid.color'] = '#E5E8E8'
plt.rcParams['grid.linestyle'] = '--'
plt.rcParams['text.color'] = 'black'
plt.rcParams['axes.labelcolor'] = 'black'
plt.rcParams['xtick.color'] = 'black'
plt.rcParams['ytick.color'] = 'black'
os.makedirs(FIG_DIR, exist_ok=True)

C_NO = '#C64C3E'
C_EW = '#2E86C1'
C_REQ = '#555555'
C_SHADE = '#D0ECE7'
L_NORMAL = '#75B956'
L_WARN = '#AED6F1'
L_ALERT = '#5392CE'
L_CRIT = '#B165A6'
M_TO_MPA = 0.00980665


def tag(ax, s, x=-0.11):
    ax.text(x, 1.04, s, transform=ax.transAxes, fontsize=12, fontweight='bold', fontfamily=ARIAL)


# ---------------------------------------------------------------- data
def load_db(name):
    con = sqlite3.connect(os.path.join(RESULTS_DIR, name))
    perf = pd.read_sql('SELECT timestamp/3600.0 AS t, avg_pressure, delivered, required FROM performance_data ORDER BY timestamp', con)
    lvl = pd.read_sql("SELECT timestamp/3600.0 AS t, sensor_id, value FROM sensor_data WHERE sensor_id IN ('T1','T2') ORDER BY timestamp", con)
    ewlog = pd.read_sql("SELECT timestamp/3600.0 AS t, warning_level, demand_reduction FROM early_warning_log WHERE warning_level != 'NORMAL' ORDER BY timestamp", con)
    con.close()
    perf['delivered_h'] = perf['delivered'] * 3600.0
    perf['required_h'] = perf['required'] * 3600.0
    return perf, lvl, ewlog


def isolation_time(lvl):
    df = lvl[(lvl.t >= 24.0) & (lvl.t < 48.0) & (lvl.value < 0.5)]
    return float(df.t.min()) if len(df) else None


perf_no, lvl_no, _ = load_db('no_ew.db')
perf_ew, lvl_ew, ewlog = load_db('ew.db')
ISO_NO = isolation_time(lvl_no)
ISO_EW = isolation_time(lvl_ew)
T_WARN = float(ewlog[ewlog.warning_level == 'WARNING'].t.min())
T_ALERT = float(ewlog[ewlog.warning_level == 'ALERT'].t.min())
T_CRIT = float(ewlog[ewlog.warning_level == 'CRITICAL'].t.min())
RD = [float(r) for r in ewlog.sort_values('t').demand_reduction]
print(f'events: WARN@{T_WARN:.2f}h ALERT@{T_ALERT:.2f}h CRIT@{T_CRIT:.2f}h reductions={RD}')
print(f'isolation: No-EWM {ISO_NO:.2f}h | EWM {ISO_EW:.2f}h')
LEVEL_YMAX = float(max(lvl_no.value.max(), lvl_ew.value.max())) + 0.6

# ---------------------------------------------------------------- Fig1
node_coords = {'R': (9.2, 1.2), 'P1': (8.2, 2.0), 'P2': (8.2, 1.2), 'J20': (8.2, 1.2), 'J1': (6.8, 1.2), 'J2': (7.8, 3.2), 'J3': (7.5, 5.0), 'J4': (6.2, 5.2), 'J5': (5.0, 6.2), 'J6': (3.6, 5.8), 'J7': (2.8, 5.5), 'J8': (2.8, 4.2), 'J9': (0.5, 2.8), 'J10': (1.5, 1.2), 'J11': (3.0, 0.5), 'J12': (4.8, 1.2), 'J13': (6.5, 2.2), 'J14': (6.5, 3.5), 'J15': (5.2, 4.2), 'J16': (3.8, 3.2), 'J17': (2.2, 2.2), 'J18': (4.2, 2.2), 'J19': (5.2, 2.8), 'J21': (6.2, 4.2), 'J22': (2.2, 1.5), 'T1': (6.2, 4.7), 'T2': (1.8, 3.2)}
edges = [('R', 'J20'), ('J20', 'J1'), ('J1', 'J2'), ('J1', 'J12'), ('J1', 'J13'), ('J2', 'J3'), ('J2', 'J13'), ('J2', 'J14'), ('J3', 'J4'), ('J4', 'J5'), ('J4', 'J8'), ('J4', 'J15'), ('J4', 'T1'), ('T1', 'J21'), ('J21', 'J14'), ('J5', 'J6'), ('J6', 'J7'), ('J6', 'J8'), ('J7', 'J8'), ('J8', 'J9'), ('J8', 'J15'), ('J8', 'J16'), ('J8', 'J17'), ('J9', 'J10'), ('J10', 'J11'), ('J10', 'J17'), ('J11', 'J12'), ('J12', 'J18'), ('J13', 'J14'), ('J13', 'J19'), ('J14', 'J15'), ('J14', 'J19'), ('J15', 'J16'), ('J15', 'J19'), ('J16', 'J17'), ('J16', 'J18'), ('J17', 'J18'), ('J17', 'J22'), ('J17', 'T2'), ('T2', 'J22'), ('J18', 'J19')]
fig, ax = plt.subplots(figsize=(9, 6), facecolor='#FFFFFF')
for u, v in edges:
    if u in node_coords and v in node_coords:
        (x1, y1), (x2, y2) = node_coords[u], node_coords[v]
        ax.plot([x1, x2], [y1, y2], color='#888888', lw=1.2, zorder=1)
for name, (x, y) in node_coords.items():
    if name.startswith('J'):
        ax.scatter(x, y, color='#2F5597', s=70, zorder=3)
        ax.text(x - 0.15, y - 0.25, name, fontsize=8, fontweight='bold', color='#1B365D')
rx, ry = node_coords['R']
ax.scatter(rx, ry, color='#C65911', marker='s', s=100, zorder=4)
ax.text(rx + 0.15, ry, 'R', fontsize=9, fontweight='bold', color='#C65911')
for tank in ['T1', 'T2']:
    tx, ty = node_coords[tank]
    ax.scatter(tx, ty, color='#385723', marker='D', s=100, zorder=4)
    ax.text(tx + 0.2, ty, tank, fontsize=9, fontweight='bold', color='#385723')
for pump, dy in [('P1', 0.25), ('P2', -0.35)]:
    px, py = node_coords[pump]
    ax.scatter(px, py, color='#555555', marker='o', s=80, facecolors='none', edgecolors='#333333', lw=1.5, zorder=4)
    ax.text(px, py + dy, pump, fontsize=8.5, fontweight='bold', color='#333333')
legend_elements = [Line2D([0], [0], marker='o', color='w', label='Demand nodes', markerfacecolor='#2F5597', markersize=8), Line2D([0], [0], marker='s', color='w', label='Reservoir', markerfacecolor='#C65911', markersize=9), Line2D([0], [0], marker='D', color='w', label='Tanks', markerfacecolor='#385723', markersize=9), Line2D([0], [0], marker='o', color='w', label='Pumps', markerfacecolor='none', markeredgecolor='#333333', markeredgewidth=1.5, markersize=8)]
ax.legend(handles=legend_elements, loc='upper right', frameon=True, facecolor='#FFFFFF', edgecolor='#BDC3C7', fontsize=8.5)
ax.set_xlim(-0.2, 10.2)
ax.set_ylim(-0.2, 6.8)
ax.axis('off')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig1.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig1.png generated (topology)')

# ---------------------------------------------------------------- Fig2
# Co-simulation platform architecture (aligned with manuscript Section 2.4:
# hierarchical weakly coupled; sequential execution per 300-s step)
fig, ax = plt.subplots(figsize=(10, 9.2), facecolor='#FFFFFF')
ax.set_xlim(0, 10)
ax.set_ylim(0, 9.4)
ax.axis('off')


def _rbox(x, y, w, h, fc, ec):
    ax.add_patch(patches.FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.08', fc=fc, ec=ec, lw=1.5, ls='--'))


def _body(x, y, w, h, text, ec, color, fs=8):
    ax.add_patch(patches.Rectangle((x, y), w, h, fc='#FFFFFF', ec=ec, lw=1.0))
    ax.text(x + w / 2, y + h / 2, text, ha='center', va='center', fontsize=fs, color=color, linespacing=1.6)


def _arrow(x, y0, y1, color, num, label, side='left'):
    ax.annotate('', xy=(x, y1), xytext=(x, y0), arrowprops=dict(arrowstyle='->', lw=2.0, color=color))
    yc = (y0 + y1) / 2.0
    ax.add_patch(patches.Circle((x, yc), 0.16, fc=color, ec='none', zorder=6))
    ax.text(x, yc, num, ha='center', va='center', fontsize=8, fontweight='bold', color='white', zorder=7)
    tx = 1.95 if side == 'left' else 8.05
    ax.text(tx, yc, label, ha='right' if side == 'left' else 'left', va='center', fontsize=7.5, color=color, fontweight='bold')


_rbox(0.5, 6.15, 9.0, 2.95, '#D9E1F2', '#8FAADC')
ax.text(5.0, 8.85, 'Cyber SCADA Module', ha='center', va='center', fontsize=11, fontweight='bold', color='#1B365D')
_body(0.9, 6.35, 4.0, 1.75, 'Real-time State Acquisition\n\n\u2022 Read H (tank levels), P (pressures)\n\u2022 300-s synchronized updates\n\u2022 State-transition timestamps\n\u2022 Duration accumulation', '#1B365D', '#1B365D')
_body(5.1, 6.35, 4.0, 1.75, 'Multi-stage Risk Assessment\n\n\u2022 Warning / Alert / Critical\n   (5.0 / 3.5 / 2.0 m)\n\u2022 One-way ratchet (anti-chatter)\n\u2022 Demand curtailment \u00d7\u03b3 = 0.7 / 0.4 / 0.2', '#1B365D', '#1B365D')
_rbox(0.5, 3.15, 9.0, 2.5, '#E2EFDA', '#A9D18E')
ax.text(5.0, 5.40, 'Time-synchronized SQLite Database (coupling layer)', ha='center', va='center', fontsize=11, fontweight='bold', color='#274E13')
_body(0.9, 3.35, 2.6, 1.6, 'Physical state table\n\n\u2022 H (tank levels)\n\u2022 P (nodal pressures)\n\u2022 Q (pump flows)', '#385723', '#274E13', fs=7.5)
_body(3.7, 3.35, 2.6, 1.6, 'Event & transition log\n\n\u2022 early_warning_log\n\u2022 control / fault records', '#385723', '#274E13', fs=7.5)
_body(6.5, 3.35, 2.6, 1.6, 'Performance records\n\n\u2022 delivered / required\n\u2022 Service time / Service value', '#385723', '#274E13', fs=7.5)
_rbox(0.5, 0.35, 9.0, 2.3, '#FCE4D6', '#F4B183')
ax.text(5.0, 2.38, 'Physical Simulation Module (WNTR + EPANET 2.2)', ha='center', va='center', fontsize=11, fontweight='bold', color='#833C0C')
_body(0.9, 0.55, 4.0, 1.5, 'Anytown Benchmark Network\n\n\u2022 Tanks T1 / T2, pumps P1 / P2\n\u2022 PDA hydraulics, \u0394t = 300 s', '#833C0C', '#833C0C')
_body(5.1, 0.55, 4.0, 1.5, 'Scenario Configuration\n\n\u2022 Source interruption 24\u201348 h\n\u2022 72-h simulation horizon', '#833C0C', '#833C0C')
_arrow(2.2, 2.65, 3.15, '#385723', '1', 'write states (H, P, Q)')
_arrow(2.2, 5.65, 6.15, '#1B365D', '2', 'read & risk assessment')
_arrow(7.8, 6.15, 5.65, '#1B365D', '3', 'commands (\u00d7\u03b3, pump status)', side='right')
_arrow(7.8, 3.15, 2.65, '#C65911', '4', 'execute demand \u00d7\u03b3', side='right')
ax.text(5.0, 0.10, 'Hierarchical weakly coupled structure \u00b7 implemented in Python 3.13 \u00b7 sequential execution per 300-s step', ha='center', va='center', fontsize=8.5, style='italic', color='#555555')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig2.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig2.png generated (co-simulation platform architecture)')

# ---------------------------------------------------------------- Fig3


def draw_thresholds(ax):
    for y in (5.0, 3.5, 2.0, 0.5):
        ax.axhline(y, color='#AAAAAA', ls=':', lw=0.9, zorder=1)
        ax.text(71.6, y + 0.1, f'{y} m', fontsize=7.5, ha='right', color='#666666')


fig = plt.figure(figsize=(9.5, 10.8), facecolor='#FFFFFF')
gs3 = fig.add_gridspec(3, 2, width_ratios=[1.0, 0.035], height_ratios=[1.0, 1.0, 1.9])
axa = fig.add_subplot(gs3[0, 0])
axb = fig.add_subplot(gs3[1, 0])
axc = fig.add_subplot(gs3[2, 0])
for ax in (axa, axb, axc):
    ax.set_facecolor('#FFFFFF')
    ax.set_xlim(0, 72)
# (a)/(b) per-tank filled level charts
TANK_COLOR = {'T1': '#5392CE', 'T2': '#75B956'}
for ax_t, sid, lab in ((axa, 'T1', '(a)'), (axb, 'T2', '(b)')):
    d = lvl_no[lvl_no.sensor_id == sid]
    ax_t.plot(d.t, d.value, '-', color=TANK_COLOR[sid], lw=1.8, zorder=4)
    ax_t.fill_between(d.t, 0, d.value, color=TANK_COLOR[sid], alpha=0.22, lw=0, zorder=2)
    ax_t.axvline(24, color='#C64C3E', lw=1.4)
    ax_t.axvline(48, color='#C64C3E', lw=1.4)
    ax_t.axhline(0.5, color='#999999', ls=':', lw=1.0, zorder=3)
    ax_t.text(71.6, 0.56, '0.5 m outlet isolation threshold', fontsize=7, ha='right', color='#666666')
    ax_t.set_ylim(0, LEVEL_YMAX)
    ax_t.set_ylabel('Tank level (m)', fontsize=10, fontweight='bold')
    ax_t.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
    ax_t.plot(ISO_NO, 0.5, 'o', color='#C64C3E', ms=7.5, zorder=5)
    ax_t.annotate(f'Failure time\n{ISO_NO:.2f} h', xy=(ISO_NO, 0.5), xytext=(ISO_NO + 6.5, 1.5), fontsize=8.5, fontweight='bold', color='#C64C3E', arrowprops=dict(arrowstyle='->', color='#C64C3E', lw=1.1))
    ax_t.text(0.985, 0.955, sid, transform=ax_t.transAxes, fontsize=10.5, fontweight='bold', ha='right', va='top', color=TANK_COLOR[sid], bbox=dict(fc='white', ec='none', alpha=0.75, pad=1.2))
    ax_t.grid(True)
    tag(ax_t, lab)
# (c) per-junction pressure heatmap (fallback: network average pressure)
jp_path = os.path.join(RESULTS_DIR, 'junction_pressure_no_ew.csv')
if os.path.exists(jp_path):
    from matplotlib.colors import LinearSegmentedColormap, to_rgba
    jpdf = pd.read_csv(jp_path)

    def _jnum(j):
        digits = ''.join(ch for ch in j if ch.isdigit())
        return int(digits) if digits else 0
    order = sorted([c for c in jpdf.columns if c != 'time_h'], key=_jnum)
    Mj = np.clip(jpdf[order].to_numpy(dtype=float), 0.0, None) * M_TO_MPA
    tj = jpdf['time_h'].to_numpy(dtype=float)
    n = len(order)
    cmap_j = LinearSegmentedColormap.from_list('ewm3', ['#C64C3E', '#75B956', '#5392CE'])
    pc = axc.imshow(Mj.T, aspect='auto', origin='upper', extent=[tj[0], tj[-1], n - 0.5, -0.5], cmap=cmap_j, vmin=0.0, interpolation='nearest')
    axc.set_yticks(np.arange(n))
    axc.set_yticklabels(order, fontsize=6.5)
    axc.contour(tj, np.arange(n), Mj.T, levels=[0.1], colors='white', linewidths=1.0, linestyles='--')
    axc.axvline(24, color='white', lw=1.3)
    axc.axvline(48, color='white', lw=1.3)
    axc.axvline(ISO_NO, color='white', lw=1.3, ls='-.')
    axc.text(ISO_NO + 1.2, 7.0, f'Failure time\n{ISO_NO:.2f} h', fontsize=8, fontweight='bold', color='white', bbox=dict(fc='#333333', ec='none', alpha=0.75, pad=2.0))
    cax3 = fig.add_subplot(gs3[2, 1])
    cbar = fig.colorbar(pc, cax=cax3)
    cbar.set_label('Nodal pressure (MPa)', fontsize=9)
    cbar.ax.tick_params(labelsize=7.5)
    axc.set_ylabel('Junction', fontsize=9.5, fontweight='bold')
    axc.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
else:
    t_p = perf_no.t.to_numpy()
    p_mpa = perf_no.avg_pressure.to_numpy() * M_TO_MPA
    axc.plot(t_p, p_mpa, '-', color=C_NO, lw=1.8, label='No EWM', zorder=4)
    axc.axhline(0.1, color='#2F5597', ls='--', lw=1.3, zorder=3)
    axc.set_ylabel('Network average\npressure (MPa)', fontsize=10, fontweight='bold')
    axc.set_ylim(0, None)
    axc.legend(fontsize=7.5, loc='upper right', framealpha=0.95)
    axc.grid(True)
    axc.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
    print('WARNING: junction_pressure_no_ew.csv missing; Fig3(c) fell back to average pressure.')
tag(axc, '(c)')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig3.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig3.png generated (baseline failure evolution)')

# ---------------------------------------------------------------- Fig4
fig, axes4 = plt.subplots(2, 2, figsize=(14, 11), facecolor='#FFFFFF')
axa, axb, axc, axd = axes4.flat
for ax in (axa, axb, axc):
    ax.set_facecolor('#FFFFFF')
    ax.set_xlim(0, 72)
    ax.axvline(24, color='#C64C3E', lw=1.4)
    ax.axvline(48, color='#C64C3E', lw=1.4)
axd.set_facecolor('#FFFFFF')
axd.set_xlim(0, 72)
# (a) decision trace
bands = [(0.0, T_WARN, '#75B956', 0.30, None), (T_WARN, T_ALERT, '#5392CE', 0.28, 'WARNING'), (T_ALERT, T_CRIT, '#5392CE', 0.55, 'ALERT'), (T_CRIT, ISO_EW, '#C64C3E', 0.42, 'CRITICAL'), (48.0, 72.0, '#75B956', 0.30, None)]
for x0, x1, c, al, lab in bands:
    axa.axvspan(x0, x1, color=c, alpha=al, zorder=0, lw=0)
    if lab:
        axa.text((x0 + x1) / 2, 0.985, lab, rotation=90, va='top', ha='center', fontsize=8, fontweight='bold', transform=axa.get_xaxis_transform())
axa.axvspan(ISO_EW, 48.0, color='#C64C3E', alpha=0.20, zorder=0, lw=0)
axa.text((ISO_EW + 48.0) / 2.0, 0.985, 'OUTLET FAILURE', rotation=90, va='top', ha='center', fontsize=7.5, fontweight='bold', transform=axa.get_xaxis_transform())
step_x = [0.0, T_WARN, T_ALERT, T_CRIT, ISO_EW, 48.0, 72.0]
step_y = [1.0, RD[0], RD[1], RD[2], 0.0, 0.0, 1.0]
axa.step(step_x, step_y, where='post', color='black', lw=1.5, alpha=0.65, zorder=4)
for xx, yy in ((T_WARN, RD[0]), (T_ALERT, RD[1]), (T_CRIT, RD[2]), (ISO_EW, 0.0)):
    axa.plot(xx, yy, 'o', color='black', alpha=0.65, ms=4, zorder=5)
    axa.text(xx + 0.4, yy + 0.04, f'{xx:.2f} h\n{yy:.1f}', fontsize=8, fontweight='bold', va='bottom')
axa.text(48.6, 0.74, 'Recovery\n48.00 h', fontsize=8, fontweight='bold', va='bottom', color='#333333')
axa.set_ylim(0, 1.18)
axa.set_yticks(np.arange(0, 1.01, 0.2))
axa.set_ylabel('Demand retention factor', fontsize=10, fontweight='bold')
axa.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
axa.grid(True)
tag(axa, '(a)')
# (b)/(c) per-tank physical response — small multiples
for sid, ax_t, lab in (('T1', axb, '(b)'), ('T2', axc, '(c)')):
    tcolor = '#5392CE' if sid == 'T1' else '#75B956'
    d_no = lvl_no[lvl_no.sensor_id == sid]
    d_ew = lvl_ew[lvl_ew.sensor_id == sid]
    ax_t.fill_between(d_ew.t, 0, d_ew.value, color=tcolor, alpha=0.22, lw=0, zorder=2)
    ax_t.plot(d_no.t, d_no.value, '--', color='#C64C3E', lw=1.6, alpha=0.9, label='No EWM', zorder=3)
    ax_t.plot(d_ew.t, d_ew.value, '-', color=tcolor, lw=1.9, label='EWM', zorder=4)
    for xx, wl in ((T_WARN, 'W'), (T_ALERT, 'A'), (T_CRIT, 'C')):
        ax_t.axvline(xx, color='#666666', ls=':', lw=1.2, zorder=2)
        ax_t.text(xx, LEVEL_YMAX + 1.7, wl, fontsize=8.5, fontweight='bold', ha='center', va='top', color='#333333')
    draw_thresholds(ax_t)
    ax_t.set_ylim(0, LEVEL_YMAX + 2.0)
    ax_t.set_ylabel('Tank level (m)', fontsize=10, fontweight='bold')
    ax_t.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
    ax_t.text(0.012, 0.965, sid, transform=ax_t.transAxes, fontsize=11.5, fontweight='bold', va='top', color=tcolor, bbox=dict(fc='white', ec='none', alpha=0.75, pad=1.2))
    ax_t.plot(ISO_NO, 0.5, 'o', color='#C64C3E', ms=7.5, zorder=5)
    ax_t.plot(ISO_EW, 0.5, 'o', color=tcolor, ms=7.5, zorder=5)
    ax_t.annotate(f'{ISO_NO:.2f} h', xy=(ISO_NO, 0.5), xytext=(ISO_NO - 7.5, 1.35), fontsize=8.5, fontweight='bold', color='#C64C3E', arrowprops=dict(arrowstyle='->', color='#C64C3E', lw=1.0))
    ax_t.annotate(f'{ISO_EW:.2f} h', xy=(ISO_EW, 0.5), xytext=(ISO_EW + 4.5, 1.35), fontsize=8.5, fontweight='bold', color=tcolor, arrowprops=dict(arrowstyle='->', color=tcolor, lw=1.0))
    ax_t.grid(True)
    ax_t.legend(fontsize=8, loc='upper right', framealpha=0.95)
    tag(ax_t, lab)
axc.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
# (d) per-junction pressure heatmap under EWM (fallback: average pressure)
jpe_path = os.path.join(RESULTS_DIR, 'junction_pressure_ew.csv')
if os.path.exists(jpe_path):
    from matplotlib.colors import LinearSegmentedColormap
    jdfe = pd.read_csv(jpe_path)

    def _jnum2(j):
        dg = ''.join(ch for ch in j if ch.isdigit())
        return int(dg) if dg else 0
    order_e = sorted([c for c in jdfe.columns if c != 'time_h'], key=_jnum2)
    Me = np.clip(jdfe[order_e].to_numpy(dtype=float), 0.0, None) * M_TO_MPA
    te = jdfe['time_h'].to_numpy(dtype=float)
    ne = len(order_e)
    cmap_e = LinearSegmentedColormap.from_list('ewm3', ['#C64C3E', '#75B956', '#5392CE'])
    pce = axd.imshow(Me.T, aspect='auto', origin='upper', extent=[te[0], te[-1], ne - 0.5, -0.5], cmap=cmap_e, vmin=0.0, interpolation='nearest')
    axd.set_yticks(np.arange(ne))
    axd.set_yticklabels(order_e, fontsize=6)
    axd.contour(te, np.arange(ne), Me.T, levels=[0.1], colors='white', linewidths=1.0, linestyles='--')
    for xx in (T_WARN, T_ALERT, T_CRIT):
        axd.axvline(xx, color='white', ls=':', lw=1.1)
    axd.axvline(24, color='white', lw=1.3)
    axd.axvline(48, color='white', lw=1.3)
    axd.axvline(ISO_EW, color='white', lw=1.3, ls='-.')
    axd.text(ISO_EW + 1.0, 7.0, f'Failure time\n{ISO_EW:.2f} h', fontsize=8, fontweight='bold', color='white', bbox=dict(fc='#333333', ec='none', alpha=0.75, pad=2.0))
    cbare = fig.colorbar(pce, ax=axd, pad=0.015, fraction=0.046)
    cbare.set_label('Nodal pressure (MPa)', fontsize=8.5)
    cbare.ax.tick_params(labelsize=6.5)
    axd.set_ylabel('Junction', fontsize=9.5, fontweight='bold')
    axd.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
else:
    pe = perf_ew.avg_pressure.to_numpy() * M_TO_MPA
    axd.plot(perf_ew.t, pe, '-', color='#5392CE', lw=1.6)
    axd.axhline(0.1, color='#2F5597', ls='--', lw=1.2)
    axd.set_ylabel('Network average\npressure (MPa)', fontsize=10, fontweight='bold')
    axd.set_ylim(0, None)
    axd.grid(True)
    axd.set_xlabel('Time (h)', fontsize=10, fontweight='bold')
    print('WARNING: junction_pressure_ew.csv missing; Fig4(d) fell back to average pressure.')
tag(axd, '(d)')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig4.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig4.png generated (EWM activation & closed-loop process)')

# ---------------------------------------------------------------- Fig5


def _metric_map(db_path):
    con = sqlite3.connect(db_path)
    frame = pd.read_sql('SELECT metric, value FROM resilience_metrics', con)
    con.close()
    return dict(zip(frame['metric'], frame['value']))


m_no = _metric_map(os.path.join(RESULTS_DIR, 'no_ew.db'))
m_ew = _metric_map(os.path.join(RESULTS_DIR, 'ew.db'))
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.5, 4.3), facecolor='#FFFFFF')
bar_x = [0, 1]
c_val_no = (83 / 255, 146 / 255, 206 / 255, 0.45)
c_val_ew = '#5392CE'
c_time_no = (117 / 255, 185 / 255, 86 / 255, 0.45)
c_time_ew = '#75B956'
ax1.set_facecolor('#FFFFFF')
ax2.set_facecolor('#FFFFFF')
rs_vals = [m_no['R_w'], m_ew['R_w']]
ax1.bar(bar_x, rs_vals, width=0.45, color=[c_val_no, c_val_ew], edgecolor='none', zorder=3)
ax1.set_xticks(bar_x)
ax1.set_xticklabels(['No EWM', 'EWM'], fontsize=10, fontweight='bold')
ax1.set_xlim(-0.6, 1.6)
ax1.set_ylim(0, 1.0)
ax1.set_yticks(np.arange(0, 1.01, 0.2))
ax1.set_ylabel('Service value', fontsize=10, fontweight='bold')
ax1.grid(axis='y', zorder=0)
for xi, value in zip(bar_x, rs_vals):
    ax1.text(xi, value + 0.03, f'{value:.2f}', ha='center', va='bottom', fontsize=9.5, fontweight='bold')
tag(ax1, '(a)', x=-0.09)
rt_vals = [m_no['T_press_h'], m_ew['T_press_h']]
ax2.bar(bar_x, rt_vals, width=0.45, color=[c_time_no, c_time_ew], edgecolor='none', zorder=3)
ax2.set_xticks(bar_x)
ax2.set_xticklabels(['No EWM', 'EWM'], fontsize=10, fontweight='bold')
ax2.set_xlim(-0.6, 1.6)
ax2.set_ylim(0, 12)
ax2.set_yticks(np.arange(0, 12.1, 2))
ax2.set_ylabel('Service time (h)', fontsize=10, fontweight='bold')
ax2.grid(axis='y', zorder=0)
for xi, value in zip(bar_x, rt_vals):
    ax2.text(xi, value + 0.3, f'{value:.2f}', ha='center', va='bottom', fontsize=9.5, fontweight='bold')
tag(ax2, '(b)', x=-0.09)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig5.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig5.png generated (Service value / Service time bars)')

# ---------------------------------------------------------------- Fig6 + Fig7 + Fig8
threshold = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_threshold.csv'))
diameter = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_diameter.csv'))
duration = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_duration.csv'))
load = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_load.csv'))
diameter['x'] = diameter['key'].astype(float)
duration['x'] = duration['key'].astype(float)
load['x'] = load['key'].astype(float)


def _error_range(frame, column):
    center = frame[column].to_numpy(dtype=float)
    return np.vstack((center - frame[column + '_lo'].to_numpy(dtype=float), frame[column + '_hi'].to_numpy(dtype=float) - center))


panels = [(np.arange(len(threshold)), threshold, 'Threshold design', np.arange(len(threshold)), threshold['key'].astype(str).tolist()), (diameter['x'], diameter, 'Tank diameter scale', None, None), (duration['x'], duration, 'Outage duration (h)', None, None), (load['x'], load, 'Relative demand load', None, None)]

# Fig6: phase-averaged
from matplotlib.ticker import MaxNLocator
fig, axes = plt.subplots(2, 2, figsize=(12, 8.5), facecolor='#FFFFFF')
panel_hex6 = ['#5392CE', '#75B956', '#B165A6', '#C64C3E']
for ax, panel, label, chex in zip(axes.flat, panels, ['(a)', '(b)', '(c)', '(d)'], panel_hex6):
    xvals, frame, xlabel, ticks, ticklabels = panel
    ax.set_facecolor('#FFFFFF')
    no_rgb = tuple(int(chex[j:j + 2], 16) / 255 for j in (1, 3, 5)) + (0.45,)
    ax.errorbar(xvals, frame['t_press_no'], yerr=_error_range(frame, 't_press_no'), fmt='o--', color=no_rgb, lw=2, ms=6, capsize=4, label='Without EWM')
    ax.errorbar(xvals, frame['t_press_ew'], yerr=_error_range(frame, 't_press_ew'), fmt='s-', color=chex, lw=2, ms=6, capsize=4, label='With EWM')
    if ticks is not None:
        ax.set_xticks(ticks)
        ax.set_xticklabels(ticklabels)
    ax.set_xlabel(xlabel, fontsize=10, fontweight='bold')
    ax.set_ylabel('Service time (h)', fontsize=10, fontweight='bold')
    ax.grid(True)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    if label == '(a)':
        ax.set_ylim(0, 16)
    elif label == '(d)':
        ax.set_ylim(bottom=0)
    if label == '(c)':
        ymax_c = float(max(frame['t_press_no_hi'].max(), frame['t_press_ew_hi'].max())) * 1.22
        ax.set_ylim(0, ymax_c)
        ax.legend(loc='upper left', fontsize=7.5, framealpha=0.95)
    else:
        ax.legend(loc='best', fontsize=7.5, framealpha=0.95)
    tag(ax, label, x=-0.13)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig6.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig6.png generated (sensitivity, phase-averaged)')
print('ALL DONE (v2 framework set: Fig1-Fig6)')
