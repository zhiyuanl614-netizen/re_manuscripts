"""Log per-junction pressure for both scenarios (for Fig3/Fig4 heatmaps).

Subclasses NoEWSim/EWSim without touching sim_main.py; captures
results.node['pressure'] at every 300-s step and writes
results/junction_pressure_no_ew.csv  (No EWM, Sec 3.1 / Fig3c)
results/junction_pressure_ew.csv    (EWM,     Sec 3.2 / Fig4d)
Columns: time_h + one column per junction, pressure in meters.
"""
import os
import sys
import time
import pandas as pd

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import sim_main as S

INP = os.path.join(SCRIPT_DIR, '..', 'data', 'anytown.inp')
OUT_DIR = os.path.join(SCRIPT_DIR, '..', 'results')
TMP_DB = os.path.join(OUT_DIR, '_jpl_tmp.db')

_records = []
_t0 = time.time()


def _make_logged(base_cls):

    class LoggedSim(base_cls):

        def calculate_pressure_performance(self, results, sim_time):
            row = results.node['pressure'].loc[sim_time]
            rec = {'time_h': self.current_time / 3600.0}
            for j in self.all_junctions:
                v = float(row[j])
                if v > 500.0:  # WNTR returned Pascals -> convert to meters
                    v /= 9806.65
                rec[j] = v
            _records.append(rec)
            if len(_records) % 240 == 0:
                print(f'  step {len(_records)}  t={rec["time_h"]:.1f}h  ({time.time()-_t0:.0f}s)', flush=True)
            return super().calculate_pressure_performance(results, sim_time)

    return LoggedSim


def run_scenario(mode):
    global _records, _t0
    _records = []
    _t0 = time.time()
    out_csv = os.path.join(OUT_DIR, f'junction_pressure_{mode}.csv')
    if os.path.exists(TMP_DB):
        os.remove(TMP_DB)
    fault = S.WaterSourceInterruption(24 * 3600, 24 * 3600)
    cls = _make_logged(S.NoEWSim if mode == 'no_ew' else S.EWSim)
    sim = cls(INP, TMP_DB, 300, fault_scenario=fault, intensity_lambda=1.0)
    sim.run(3 * 24 * 3600)
    sim.close()
    df = pd.DataFrame(_records)
    df.to_csv(out_csv, index=False)
    if os.path.exists(TMP_DB):
        os.remove(TMP_DB)
    print(f'saved {out_csv}: {df.shape[0]} rows x {df.shape[1]-1} junctions', flush=True)


if __name__ == '__main__':
    for m in ('no_ew', 'ew'):
        print(f'=== scenario: {m} ===', flush=True)
        run_scenario(m)
    print('ALL DONE')
