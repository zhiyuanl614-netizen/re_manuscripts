import wntr
import sqlite3
import pandas as pd
import numpy as np
import os
import demand_patterns as DP
_HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(_HERE, '..', 'data')
RESULTS_DIR = os.path.join(_HERE, '..', 'results')
DEFAULT_INP = os.path.join(DATA_DIR, 'anytown.inp')
M_TO_MPA = 0.00980665
EMERGENCY_PRESSURE_MPA = 0.1

class SimulationDB:

    def __init__(self, db_path='scada_sim.db'):
        self.conn = sqlite3.connect(db_path)
        self._create_tables()

    def _create_tables(self):
        c = self.conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS sensor_data (\n            timestamp REAL, sensor_id TEXT, value REAL, unit TEXT,\n            is_fault INTEGER DEFAULT 0, true_value REAL)')
        c.execute('CREATE TABLE IF NOT EXISTS actuator_status (\n            timestamp REAL, actuator_id TEXT, status INTEGER, source TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS pump_physical_status (\n            timestamp REAL, pump_id TEXT, status INTEGER,\n            is_fault_overridden INTEGER)')
        c.execute('CREATE TABLE IF NOT EXISTS control_log (\n            timestamp REAL, action TEXT, reason TEXT,\n            is_under_fault INTEGER DEFAULT 0)')
        c.execute('CREATE TABLE IF NOT EXISTS fault_log (\n            timestamp REAL, fault_type TEXT,\n            affected_pumps TEXT, description TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS early_warning_log (\n            timestamp REAL, warning_level TEXT,\n            trigger_tank TEXT, tank_level REAL,\n            pump_physical_status INTEGER,\n            trigger_threshold REAL,\n            demand_reduction REAL,\n            action TEXT, description TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS performance_data (\n            timestamp          REAL,\n            avg_pressure       REAL,\n            delivered          REAL,\n            required           REAL,\n            weighted_delivered REAL)')
        c.execute('CREATE TABLE IF NOT EXISTS resilience_metrics (\n            metric TEXT PRIMARY KEY,\n            value  REAL,\n            unit   TEXT)')
        self.conn.commit()

    def write_sensor(self, timestamp, sensor_id, value, unit='', is_fault=0, true_value=None):
        if true_value is None:
            true_value = value
        self.conn.execute('INSERT INTO sensor_data VALUES (?,?,?,?,?,?)', (float(timestamp), sensor_id, float(value), unit, int(is_fault), float(true_value)))
        self.conn.commit()

    def write_actuator(self, timestamp, actuator_id, status, source='PLC'):
        self.conn.execute('INSERT INTO actuator_status VALUES (?,?,?,?)', (timestamp, actuator_id, status, source))
        self.conn.commit()

    def write_pump_physical_status(self, timestamp, pump_id, status, is_fault_overridden):
        self.conn.execute('INSERT INTO pump_physical_status VALUES (?,?,?,?)', (timestamp, pump_id, status, is_fault_overridden))
        self.conn.commit()

    def write_fault_log(self, timestamp, fault_type, affected_pumps, description):
        self.conn.execute('INSERT INTO fault_log VALUES (?,?,?,?)', (timestamp, fault_type, ','.join(affected_pumps), description))
        self.conn.commit()

    def write_early_warning_log(self, timestamp, warning_level, trigger_tank, tank_level, pump_physical_status, trigger_threshold, demand_reduction, action, description):
        self.conn.execute('INSERT INTO early_warning_log VALUES (?,?,?,?,?,?,?,?,?)', (timestamp, warning_level, trigger_tank, tank_level, pump_physical_status, trigger_threshold, demand_reduction, action, description))
        self.conn.commit()

    def write_performance(self, timestamp, avg_pressure, delivered, required, weighted_delivered):
        self.conn.execute('INSERT INTO performance_data\n               (timestamp, avg_pressure, delivered, required, weighted_delivered)\n               VALUES (?,?,?,?,?)', (float(timestamp), float(avg_pressure), float(delivered), float(required), float(weighted_delivered)))
        self.conn.commit()

    def write_log(self, timestamp, action, reason, is_under_fault=0):
        self.conn.execute('INSERT INTO control_log VALUES (?,?,?,?)', (timestamp, action, reason, is_under_fault))
        self.conn.commit()

    def get_latest_actuator(self, actuator_id):
        c = self.conn.execute('SELECT status FROM actuator_status WHERE actuator_id=? ORDER BY timestamp DESC LIMIT 1', (actuator_id,))
        r = c.fetchone()
        return r[0] if r else None

    def get_latest_pump_physical_status(self, pump_id):
        c = self.conn.execute('SELECT status FROM pump_physical_status WHERE pump_id=? ORDER BY timestamp DESC LIMIT 1', (pump_id,))
        r = c.fetchone()
        return r[0] if r else None

    def get_latest_sensor_with_fault_flag(self, sensor_id):
        c = self.conn.execute('SELECT value, is_fault, true_value FROM sensor_data WHERE sensor_id=? ORDER BY timestamp DESC LIMIT 1', (sensor_id,))
        r = c.fetchone()
        return {'value': r[0], 'is_fault': r[1], 'true_value': r[2]} if r else None

    def close(self):
        self.conn.close()

class WaterSourceInterruption:

    def __init__(self, fault_start_time=24 * 3600, fault_duration=24 * 3600, affected_pumps=None):
        self.fault_start_time = fault_start_time
        self.fault_duration = fault_duration
        self.fault_end_time = fault_start_time + fault_duration
        self.affected_pumps = affected_pumps
        self.is_active = False
        self.fault_logged = False

    def is_fault_active(self, current_time):
        return self.fault_start_time <= current_time < self.fault_end_time

    def apply_fault(self, current_time, pump_name, intended_status):
        if not self.is_fault_active(current_time):
            self.is_active = False
            return (intended_status, False)
        if self.affected_pumps is None or pump_name in self.affected_pumps:
            self.is_active = True
            return (0, True)
        return (intended_status, False)

class EarlyWarningSystem:
    LEVELS = [('CRITICAL', 2.0, 0.2, 3), ('ALERT', 3.5, 0.4, 2), ('WARNING', 5.0, 0.7, 1)]
    LEVEL_RANK = {'NORMAL': 0, 'WARNING': 1, 'ALERT': 2, 'CRITICAL': 3}
    REDUCTION_MAP = {lv: rd for lv, _, rd, _ in LEVELS}
    REDUCTION_MAP['NORMAL'] = 1.0
    THRESHOLD_MAP = {lv: thr for lv, thr, _, _ in LEVELS}

    def __init__(self, db, tank_pump_map, fault_start_time, fault_end_time):
        self.db = db
        self.tank_pump_map = tank_pump_map
        self.fault_start_time = fault_start_time
        self.fault_end_time = fault_end_time
        self.current_level = 'NORMAL'
        self.current_reduction = 1.0
        self.level_history = []

    def _evaluate_tank(self, level, pump_physical_status):
        if pump_physical_status != 0:
            return ('NORMAL', None)
        for lv_name, threshold, _, _ in self.LEVELS:
            if level < threshold:
                return (lv_name, threshold)
        return ('NORMAL', None)

    def evaluate(self, current_time, tank_levels):
        if current_time < self.fault_start_time:
            return (1.0, 'NORMAL')
        if current_time >= self.fault_end_time:
            if self.current_level != 'NORMAL':
                prev = self.current_level
                self.current_level = 'NORMAL'
                self.current_reduction = 1.0
                self.db.write_early_warning_log(current_time, 'NORMAL', '-', 0.0, 1, 0.0, 1.0, '故障结束：解除预警，需求恢复正常', f'故障于 {self.fault_end_time / 3600:.1f}h 结束，{prev} -> NORMAL')
                self.db.write_log(current_time, '故障结束：需求恢复100%', f'{prev} -> NORMAL', is_under_fault=0)
            return (1.0, 'NORMAL')
        prev_level = self.current_level
        worst_level = 'NORMAL'
        worst_thr = None
        worst_tank = None
        worst_lv = None
        worst_ps = None
        for tank_id, level in tank_levels.items():
            pump_id = self.tank_pump_map.get(tank_id)
            if pump_id is None:
                continue
            phys = self.db.get_latest_pump_physical_status(pump_id)
            if phys is None:
                phys = 1
            lv, thr = self._evaluate_tank(level, phys)
            if self.LEVEL_RANK[lv] > self.LEVEL_RANK[worst_level]:
                worst_level = lv
                worst_thr = thr
                worst_tank = tank_id
                worst_lv = level
                worst_ps = phys
        if self.LEVEL_RANK[worst_level] < self.LEVEL_RANK[self.current_level]:
            worst_level = self.current_level
        self.current_level = worst_level
        self.current_reduction = self.REDUCTION_MAP[worst_level]
        if worst_level != prev_level:
            rd = self.REDUCTION_MAP[worst_level]
            desc = f'水箱 {worst_tank} 水位={worst_lv:.3f}m < {worst_thr}m，水泵物理关闭；需求削减至 {rd * 100:.0f}%'
            self.db.write_early_warning_log(current_time, worst_level, worst_tank or '-', worst_lv or 0.0, worst_ps or 0, worst_thr or 0.0, rd, f'{prev_level} -> {worst_level}：需求×{rd:.2f}', desc)
            self.db.write_log(current_time, f'EWS: {prev_level}->{worst_level} 需求×{rd:.2f}', desc, is_under_fault=1)
            self.level_history.append({'time_h': current_time / 3600, 'level': worst_level, 'reduction': rd})
        return (self.current_reduction, self.current_level)

class PLC:

    def __init__(self, db):
        self.db = db
        self.rules = {'T1': {'pump': 'P1', 'low': 5.0, 'high': 8.0}, 'T2': {'pump': 'P2', 'low': 5.0, 'high': 8.0}}
        self.pump_states = {}

    def control(self, current_time):
        for tank, rule in self.rules.items():
            data = self.db.get_latest_sensor_with_fault_flag(tank)
            if data is None:
                continue
            level = data['value']
            pump = rule['pump']
            current = self.pump_states.get(pump, self.db.get_latest_actuator(pump))
            if current is None:
                current = 1
            if current == 0 and level < rule['low']:
                new = 1
            elif current == 1 and level > rule['high']:
                new = 0
            else:
                new = current
            if new != current:
                self.db.write_actuator(current_time, pump, new, 'PLC')
            self.pump_states[pump] = new

class SteppedSim:
    MIN_WATER_LEVEL = 0.05
    OUTLET_HEIGHT = 0.5

    def __init__(self, inp_file, db_path='scada_sim.db', timestep=300, fault_scenario=None, intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
        self.inp_file = inp_file
        self.wn = wntr.network.WaterNetworkModel(inp_file)
        self.db = SimulationDB(db_path)
        self._epanet_file_prefix = os.path.splitext(os.path.abspath(db_path))[0] + '_epanet'
        self.timestep = timestep
        self.current_time = 0
        self.step = 0
        self.intensity_lambda = float(intensity_lambda)
        self.pattern_name = pattern_name
        self.fault_scenario = fault_scenario
        self.outlet_failed = {}
        self.outlet_failure_time = {}
        self.fault_start_time = fault_scenario.fault_start_time if fault_scenario else 24 * 3600
        self.fault_end_time = fault_scenario.fault_end_time if fault_scenario else 48 * 3600
        for ctrl in list(self.wn.control_name_list):
            self.wn.remove_control(ctrl)
        for tank_name in self.wn.tank_name_list:
            self.wn.get_node(tank_name).min_level = self.MIN_WATER_LEVEL
            self.outlet_failed[tank_name] = False
        self._apply_pattern(self.intensity_lambda, self.pattern_name)
        self.alpha_max = max(self._m_hat)
        self.fault_start_storage_m3 = None
        self.tanks = self.wn.tank_name_list
        self.pumps = self.wn.pump_name_list
        self.all_junctions = self.wn.junction_name_list
        self.tank_levels = {}
        for tank in self.tanks:
            lvl = self.wn.get_node(tank).init_level
            self.tank_levels[tank] = lvl
        self._identify_tank_outlets()

    def _identify_tank_outlets(self):
        self.tank_outlet_pipes = {}
        for t in self.tanks:
            self.tank_outlet_pipes[t] = [p for p in self.wn.pipe_name_list if self.wn.get_link(p).start_node_name == t or self.wn.get_link(p).end_node_name == t]

    def _apply_pattern(self, intensity_lambda, pattern_name):
        self._m_hat = DP.normalised(pattern_name)
        pname = 'SIM_PATTERN'
        if pname in self.wn.pattern_name_list:
            self.wn.remove_pattern(pname)
        self.wn.add_pattern(pname, [1.0] * 24)
        self._orig_demands = []
        self._orig_base = {j: 0.0 for j in self.wn.junction_name_list}
        for junc in self.wn.junction_name_list:
            for d in self.wn.get_node(junc).demand_timeseries_list:
                if d.base_value > 0:
                    calibrated = float(d.base_value) * 0.12
                    self._orig_demands.append((junc, d, calibrated))
                    self._orig_base[junc] += calibrated
                    d.pattern_name = pname
        self._sim_pattern = list(self._m_hat)
        self._apply_absolute_demand(alpha=1.0, sim_time=0.0)

    def _apply_absolute_demand(self, alpha, sim_time):
        hour = int(sim_time // 3600) % len(self._m_hat)
        self._active_pattern_multiplier = float(self._m_hat[hour])
        scale = self.intensity_lambda * float(alpha) * self._active_pattern_multiplier
        for _, d, orig in self._orig_demands:
            d.base_value = orig * scale

    def apply_pump_control(self):
        for ctrl in list(self.wn.control_name_list):
            self.wn.remove_control(ctrl)
        for pump_name in self.pumps:
            plc_status = self.db.get_latest_actuator(pump_name)
            if plc_status is None:
                plc_status = 1
            if self.fault_scenario:
                actual, overridden = self.fault_scenario.apply_fault(self.current_time, pump_name, plc_status)
                if overridden and (not self.fault_scenario.fault_logged):
                    self.db.write_fault_log(self.current_time, 'WATER_SOURCE_INTERRUPTION', list(self.pumps), '水源中断：水泵无法向水箱供水')
                    self.fault_scenario.fault_logged = True
            else:
                actual, overridden = (plc_status, False)
            self.db.write_pump_physical_status(self.current_time, pump_name, actual, int(overridden))
            pump = self.wn.get_link(pump_name)
            status = wntr.network.LinkStatus.Open if actual == 1 else wntr.network.LinkStatus.Closed
            act = wntr.network.controls.ControlAction(pump, 'status', status)
            cond = wntr.network.controls.SimTimeCondition(self.wn, '=', 0)
            self.wn.add_control(f'SIM_{pump_name}', wntr.network.controls.Control(cond, act))

    def control_tank_outlets(self):
        fault_active = self.fault_scenario.is_fault_active(self.current_time) if self.fault_scenario else False
        for tank_name in self.tanks:
            level = self.tank_levels[tank_name]
            for pipe_name in self.tank_outlet_pipes.get(tank_name, []):
                pipe = self.wn.get_link(pipe_name)
                if level < self.OUTLET_HEIGHT and fault_active:
                    pipe.initial_status = wntr.network.LinkStatus.Closed
                    if not self.outlet_failed[tank_name]:
                        self.outlet_failed[tank_name] = True
                        self.outlet_failure_time[tank_name] = self.current_time
                else:
                    pipe.initial_status = wntr.network.LinkStatus.Open
                    self.outlet_failed[tank_name] = False

    def _calc_raw_avg_pressure(self, results, sim_time):
        total = 0.0
        count = len(self.all_junctions)
        for junction in self.all_junctions:
            head = results.node['head'].loc[sim_time, junction]
            elev = self.wn.get_node(junction).elevation
            total += max(0.0, head - elev)
        return total / count if count > 0 else 0.0

    def _calc_service_terms(self, results, sim_time):
        delivered = sum((max(0.0, float(results.node['demand'].loc[sim_time, j])) for j in self.all_junctions))
        required = sum(self._orig_base.values()) * self.intensity_lambda * self._active_pattern_multiplier
        weighted_delivered = delivered * self._active_pattern_multiplier
        return (delivered, max(required, 1e-12), weighted_delivered)

    def calculate_pressure_performance(self, results, sim_time):
        raw_avg = self._calc_raw_avg_pressure(results, sim_time)
        delivered, required, weighted_delivered = self._calc_service_terms(results, sim_time)
        self.db.write_performance(self.current_time, raw_avg, delivered, required, weighted_delivered)
        return raw_avg

    def write_sensors(self, results, sim_time):
        is_fault = self.fault_scenario.is_active if self.fault_scenario else False
        for tank in self.tanks:
            head = results.node['head'].loc[sim_time, tank]
            elev = self.wn.get_node(tank).elevation
            level = max(self.MIN_WATER_LEVEL, head - elev)
            self.db.write_sensor(self.current_time, tank, level, 'm', is_fault=int(is_fault), true_value=level)
        for pump in self.pumps:
            flow = results.link['flowrate'].loc[sim_time, pump] * 3600
            self.db.write_sensor(self.current_time, f'{pump}_flow', flow, 'm3/h')

    def record_initial_state(self):
        for tank in self.tanks:
            self.db.write_sensor(0, tank, self.tank_levels[tank], 'm')
        for pump in self.pumps:
            self.db.write_pump_physical_status(0, pump, 1, 0)
        self.wn.options.time.duration = self.timestep
        self.wn.options.time.hydraulic_timestep = self.timestep
        self.wn.options.time.report_timestep = self.timestep
        results = wntr.sim.EpanetSimulator(self.wn).run_sim(file_prefix=self._epanet_file_prefix)
        initial_time = results.node['head'].index[0]
        raw_avg = self._calc_raw_avg_pressure(results, initial_time)
        delivered, required, weighted_delivered = self._calc_service_terms(results, initial_time)
        self.db.write_performance(0, raw_avg, delivered, required, weighted_delivered)

    def storage_value_ceiling(self):
        if self.fault_start_storage_m3 is None:
            return None
        return self.fault_start_storage_m3 * self.alpha_max

    def run_step(self, ew_demand_reduction=1.0):
        if self.fault_start_storage_m3 is None and self.current_time >= self.fault_start_time:
            self.fault_start_storage_m3 = sum(float(np.pi * self.wn.get_node(t).diameter ** 2 / 4.0) * max(0.0, self.tank_levels[t] - self.MIN_WATER_LEVEL) for t in self.tanks)
        self._apply_absolute_demand(ew_demand_reduction, self.current_time)
        for tank in self.tanks:
            self.wn.get_node(tank).init_level = max(self.MIN_WATER_LEVEL, self.tank_levels[tank])
        self.control_tank_outlets()
        self.apply_pump_control()
        self.wn.options.time.duration = self.timestep
        self.wn.options.time.hydraulic_timestep = self.timestep
        self.wn.options.time.report_timestep = self.timestep
        results = wntr.sim.EpanetSimulator(self.wn).run_sim(file_prefix=self._epanet_file_prefix)
        for tank in self.tanks:
            head = results.node['head'].loc[self.timestep, tank]
            elev = self.wn.get_node(tank).elevation
            self.tank_levels[tank] = max(self.MIN_WATER_LEVEL, head - elev)
        self.current_time += self.timestep
        self.write_sensors(results, self.timestep)
        self.calculate_pressure_performance(results, self.timestep)
        self.step += 1
        return results

    def close(self):
        self.db.close()
        for extension in ('.inp', '.bin', '.out', '.rpt', '.hyd'):
            temporary = self._epanet_file_prefix + extension
            if os.path.exists(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass

class NoEWSim(SteppedSim):

    def __init__(self, inp_file, db_path='scada_sim.db', timestep=300, fault_scenario=None, intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
        super().__init__(inp_file, db_path, timestep, fault_scenario, intensity_lambda, pattern_name)
        self.plc = PLC(self.db)
        for pump in self.pumps:
            self.db.write_actuator(0, pump, 1, 'INIT')

    def run(self, duration):
        steps = int(duration / self.timestep)
        self.record_initial_state()
        for i in range(steps):
            if i > 0:
                self.plc.control(self.current_time)
            self.run_step(ew_demand_reduction=1.0)

class EWSim(SteppedSim):

    def __init__(self, inp_file, db_path='scada_sim.db', timestep=300, fault_scenario=None, intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
        super().__init__(inp_file, db_path, timestep, fault_scenario, intensity_lambda, pattern_name)
        self.plc = PLC(self.db)
        for pump in self.pumps:
            self.db.write_actuator(0, pump, 1, 'INIT')
        tank_pump_map = {tank: f'P{tank[-1]}' for tank in self.tanks}
        self.ews = EarlyWarningSystem(db=self.db, tank_pump_map=tank_pump_map, fault_start_time=self.fault_start_time, fault_end_time=self.fault_end_time)

    def run(self, duration):
        steps = int(duration / self.timestep)
        self.record_initial_state()
        for i in range(steps):
            if i > 0:
                self.plc.control(self.current_time)
            reduction, _ = self.ews.evaluate(self.current_time, self.tank_levels)
            self.run_step(ew_demand_reduction=reduction)

def calculate_resilience_metrics(db_path, fault_start, fault_end, pressure_threshold_mpa=EMERGENCY_PRESSURE_MPA, u_max=None):
    conn = sqlite3.connect(db_path)
    df = pd.read_sql('SELECT timestamp, avg_pressure, delivered, required,\n                  weighted_delivered\n           FROM performance_data\n           WHERE timestamp >= ? AND timestamp <= ? ORDER BY timestamp', conn, params=(fault_start, fault_end))
    conn.close()
    df = df.dropna()
    if len(df) < 2:
        raise ValueError('insufficient performance data in the fault window')
    if u_max is None:
        raise ValueError('u_max (storage value ceiling S_star * alpha_max) is required')
    ts = df['timestamp'].to_numpy(dtype=float)
    duration = float(fault_end - fault_start)
    if duration <= 0:
        raise ValueError('fault_end must be greater than fault_start')
    dt = np.diff(ts)
    end_pressure_mpa = df['avg_pressure'].to_numpy(dtype=float)[1:] * M_TO_MPA
    t_press_h = float(dt[end_pressure_mpa >= pressure_threshold_mpa].sum() / 3600.0)
    weighted_volume = float(np.sum(df['weighted_delivered'].to_numpy(dtype=float)[1:] * dt))
    r_w = weighted_volume / float(u_max)
    metrics = {'T_press_h': t_press_h, 'R_w': r_w, 'weighted_service_m3': weighted_volume}
    units = {'T_press_h': 'h', 'R_w': '-', 'weighted_service_m3': 'weighted_m3'}
    conn = sqlite3.connect(db_path)
    conn.executemany('INSERT OR REPLACE INTO resilience_metrics(metric, value, unit)\n           VALUES (?,?,?)', [(name, float(value), units[name]) for name, value in metrics.items()])
    conn.commit()
    conn.close()
    return metrics

def run_one(mode, inp_file, base=RESULTS_DIR, duration=3 * 24 * 3600, timestep=300, fault_start=24 * 3600, fault_duration=24 * 3600, intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
    os.makedirs(base, exist_ok=True)
    db_path = os.path.join(base, f'{mode}.db')
    if os.path.exists(db_path):
        os.remove(db_path)
    fault = WaterSourceInterruption(fault_start, fault_duration, affected_pumps=None)
    SimClass = NoEWSim if mode == 'no_ew' else EWSim
    sim = SimClass(inp_file, db_path, timestep, fault_scenario=fault, intensity_lambda=intensity_lambda, pattern_name=pattern_name)
    sim.run(duration)
    fault_end = fault_start + fault_duration
    s_star = sim.fault_start_storage_m3
    alpha_max = sim.alpha_max
    ceiling = sim.storage_value_ceiling()
    sim.close()
    metrics = calculate_resilience_metrics(db_path, fault_start, fault_end, u_max=ceiling)
    conn = sqlite3.connect(db_path)
    conn.executemany('INSERT OR REPLACE INTO resilience_metrics(metric, value, unit)\n           VALUES (?,?,?)', [('S_star_m3', float(s_star), 'm3'), ('alpha_max', float(alpha_max), '-'), ('value_ceiling_m3', float(ceiling), 'weighted_m3')])
    conn.commit()
    conn.close()
    return {'mode': mode, 'metrics': metrics, 'db_path': db_path, 'fault_start': fault_start, 'fault_end': fault_end, 'ceiling': ceiling}

def compare_scenarios(no_ew, with_ew):
    return {'T_press_h': (no_ew['metrics']['T_press_h'], with_ew['metrics']['T_press_h']), 'R_w': (no_ew['metrics']['R_w'], with_ew['metrics']['R_w'])}
if __name__ == '__main__':
    INP = DEFAULT_INP
    print('Running two-metric resilience simulation...')
    no_ew = run_one('no_ew', INP)
    with_ew = run_one('ew', INP)
    summary = compare_scenarios(no_ew, with_ew)
    print(f"\n{'=' * 72}")
    print(f"  {'Metric':<30}{'No EWM':>14}{'EWM':>14}{'Change':>12}")
    print(f"  {'-' * 68}")
    for key in ('T_press_h', 'R_w'):
        baseline, ewm = summary[key]
        print(f'  {key:<30}{baseline:>14.4f}{ewm:>14.4f}{ewm - baseline:>+12.4f}')
    print(f"{'=' * 72}")
    print(f'  R_w convention: anchor = S_star x alpha_max = {no_ew["ceiling"]:.2f} (w_j=1)')
