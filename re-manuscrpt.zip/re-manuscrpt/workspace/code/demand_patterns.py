from __future__ import annotations
_ANYTOWN_BLOCKS = [0.7, 0.6, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9]
ANYTOWN_ADD_3H = [v for v in _ANYTOWN_BLOCKS for _ in range(3)]
PATTERNS = {'anytown_add_3h': ANYTOWN_ADD_3H}
DEFAULT_PATTERN = 'anytown_add_3h'

def normalised(name: str):
    raw = list(PATTERNS[name])
    mu = sum(raw) / len(raw)
    if mu <= 0:
        raise ValueError(f'pattern {name} has non-positive mean')
    return [x / mu for x in raw]
