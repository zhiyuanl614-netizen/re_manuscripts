import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
import sim_main as S
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INP = os.path.join(SCRIPT_DIR, '..', 'data', 'anytown.inp')
OUT = os.path.join(SCRIPT_DIR, '..', 'results')
TMP = os.path.join(OUT, '_sensitivity_tmp')
os.makedirs(OUT, exist_ok=True)
os.makedirs(TMP, exist_ok=True)
PHASES = [0, 6, 12, 18]
FAULT_BASE = 24.0
TIMESTEP = 300
WORKERS = max(1, int(os.environ.get('SENSITIVITY_WORKERS', '4')))
DESIGNS = {'D1': [('CRITICAL', 1.0, 0.2, 3), ('ALERT', 3.0, 0.4, 2), ('WARNING', 5.0, 0.7, 1)], 'D2': [('CRITICAL', 1.5, 0.2, 3), ('ALERT', 3.25, 0.4, 2), ('WARNING', 5.0, 0.7, 1)], 'D3': [('CRITICAL', 2.0, 0.2, 3), ('ALERT', 3.5, 0.4, 2), ('WARNING', 5.0, 0.7, 1)], 'D4': [('CRITICAL', 2.5, 0.2, 3), ('ALERT', 3.75, 0.4, 2), ('WARNING', 5.0, 0.7, 1)], 'D5': [('CRITICAL', 3.0, 0.2, 3), ('ALERT', 4.0, 0.4, 2), ('WARNING', 5.0, 0.7, 1)]}
METRICS = ('t_press',)

def run_config(mode, fault_start_h, fault_duration_h, diameter_scale=1.0, threshold_levels=None, intensity_lambda=1.0, tag='x'):
    db = os.path.join(TMP, f'{tag}_{mode}.db')
    if os.path.exists(db):
        os.remove(db)
    fault_start = int(fault_start_h * 3600)
    fault_duration = int(fault_duration_h * 3600)
    fault_end = fault_start + fault_duration
    fault = S.WaterSourceInterruption(fault_start, fault_duration)
    sim_class = S.NoEWSim if mode == 'no_ew' else S.EWSim
    sim = sim_class(INP, db, TIMESTEP, fault_scenario=fault, intensity_lambda=intensity_lambda)
    if abs(diameter_scale - 1.0) > 1e-09:
        for tank in sim.tanks:
            sim.wn.get_node(tank).diameter *= diameter_scale
    if mode == 'ew' and threshold_levels is not None:
        sim.ews.LEVELS = list(threshold_levels)
        sim.ews.THRESHOLD_MAP = {level: threshold for level, threshold, _, _ in threshold_levels}
        sim.ews.REDUCTION_MAP = {level: retention for level, _, retention, _ in threshold_levels}
        sim.ews.REDUCTION_MAP['NORMAL'] = 1.0
    try:
        sim.run(fault_end + 3600)
        ceiling = sim.storage_value_ceiling()
    finally:
        sim.close()
    metrics = S.calculate_resilience_metrics(db, fault_start, fault_end, u_max=ceiling)
    result = {'t_press': metrics['T_press_h']}
    if os.path.exists(db):
        os.remove(db)
    return result

def compare(key, **kwargs):
    samples = {f'{metric}_{scenario}': [] for metric in METRICS for scenario in ('no', 'ew')}
    tasks = []
    for phase in PHASES:
        for mode, scenario in (('no_ew', 'no'), ('ew', 'ew')):
            tasks.append((mode, scenario, phase))
    with ProcessPoolExecutor(max_workers=min(WORKERS, len(tasks))) as pool:
        futures = {pool.submit(run_config, mode, FAULT_BASE + phase, tag=f'{key}_p{phase}', **kwargs): (scenario, phase) for mode, scenario, phase in tasks}
        raw = []
        for future in as_completed(futures):
            scenario, phase = futures[future]
            result = future.result()
            for metric in METRICS:
                samples[f'{metric}_{scenario}'].append(result[metric])
            raw.append({'key': key, 'mode': scenario, 'phase': phase, 't_press': result['t_press']})
    output = {}
    for name, values in samples.items():
        output[name] = float(np.mean(values))
        output[f'{name}_lo'] = float(np.min(values))
        output[f'{name}_hi'] = float(np.max(values))
    return output, raw

def sweep(dimension, configs, output_csv, **fixed):
    print(f'--- {dimension} ---', flush=True)
    records = []
    raw_records = []
    started = time.time()
    for index, (key, variable) in enumerate(configs, start=1):
        parameters = {**fixed, **variable}
        result, raw = compare(key, **parameters)
        result['key'] = key
        records.append(result)
        raw_records.extend(raw)
        elapsed = time.time() - started
        print(f"  [{index}/{len(configs)}] {key}: T_press {result['t_press_no']:.2f}->{result['t_press_ew']:.2f} h ({elapsed:.0f}s elapsed)", flush=True)
    dataframe = pd.DataFrame(records)
    ordered = ['key']
    for metric in METRICS:
        for scenario in ('no', 'ew'):
            base = f'{metric}_{scenario}'
            ordered.extend([base, f'{base}_lo', f'{base}_hi'])
    dataframe = dataframe[ordered]
    dataframe.to_csv(output_csv, index=False, encoding='utf-8-sig')
    pd.DataFrame(raw_records).to_csv(output_csv.replace('.csv', '_raw.csv'), index=False, encoding='utf-8-sig')
    print(f'  -> {output_csv} (+_raw.csv)', flush=True)
if __name__ == '__main__':
    print('=== 三指标敏感性分析：4相位平均 ===', flush=True)
    print(f'指标：T_press；并行进程数：{WORKERS}\n', flush=True)
    sweep('threshold', [(name, {'threshold_levels': levels}) for name, levels in sorted(DESIGNS.items())], os.path.join(OUT, 'sensitivity_threshold.csv'), fault_duration_h=24.0)
    sweep('diameter', [(f'{scale:.1f}', {'diameter_scale': scale}) for scale in np.round(np.arange(0.6, 1.41, 0.1), 2)], os.path.join(OUT, 'sensitivity_diameter.csv'), fault_duration_h=24.0)
    sweep('duration', [(str(duration), {'fault_duration_h': float(duration)}) for duration in range(12, 49, 4)], os.path.join(OUT, 'sensitivity_duration.csv'))
    sweep('load', [(f'{load:.1f}', {'intensity_lambda': load}) for load in np.round(np.arange(0.6, 1.41, 0.1), 2)], os.path.join(OUT, 'sensitivity_load.csv'), fault_duration_h=24.0)
    print('ALL DONE', flush=True)
