"""三指标敏感性分析：加密取点 + 4 相位平均。

仅分析以下三个韧性指标（均在故障窗口 [t0, t1] 内计算）：

  RI_p    压力韧性指数；
  T_press 平均节点压力不低于 0.10 MPa 的有效服务时长（h）；
  R_w     标准化服务韧性，U_max=1491.85、w_j=1，时段权重采用
          归一化 Anytown 日需水模式。

不再分析或输出 RI_v、累计供水量、未满足需求、供水量增益、出口隔离
延迟和高峰时段覆盖率。

为削弱三小时需水块与故障时刻对齐造成的伪影，故障起点在 24 h 基础上
按 phase ∈ {0, 6, 12, 18} h 平移。每个输出 CSV 保存 No-EWM 与 EWM
两种场景下三个指标的四相位均值、最小值和最大值。
"""

import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
import pandas as pd

import sim_main as S

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CODE_ROOT = os.path.dirname(SCRIPT_DIR)
INP = os.path.join(CODE_ROOT, '03_Data_Files', 'anytown.inp')
OUT = os.path.join(CODE_ROOT, '04_Simulation_Results', 'phase_avg')
TMP = os.path.join(CODE_ROOT, '04_Simulation_Results', '_sensitivity_tmp')
os.makedirs(OUT, exist_ok=True)
os.makedirs(TMP, exist_ok=True)

PHASES = [0, 6, 12, 18]
FAULT_BASE = 24.0
TIMESTEP = 300
WORKERS = max(1, int(os.environ.get('SENSITIVITY_WORKERS', '4')))

# 五组分级预警阈值设计。
DESIGNS = {
    'D1': [('CRITICAL', 1.0, 0.20, 3),
           ('ALERT', 3.0, 0.40, 2),
           ('WARNING', 5.0, 0.70, 1)],
    'D2': [('CRITICAL', 1.5, 0.20, 3),
           ('ALERT', 3.25, 0.40, 2),
           ('WARNING', 5.0, 0.70, 1)],
    'D3': [('CRITICAL', 2.0, 0.20, 3),
           ('ALERT', 3.5, 0.40, 2),
           ('WARNING', 5.0, 0.70, 1)],
    'D4': [('CRITICAL', 2.5, 0.20, 3),
           ('ALERT', 3.75, 0.40, 2),
           ('WARNING', 5.0, 0.70, 1)],
    'D5': [('CRITICAL', 3.0, 0.20, 3),
           ('ALERT', 4.0, 0.40, 2),
           ('WARNING', 5.0, 0.70, 1)],
}

METRICS = ('ri_p', 't_press', 'r_w')


def run_config(mode, fault_start_h, fault_duration_h, diameter_scale=1.0,
               threshold_levels=None, intensity_lambda=1.0, tag='x'):
    """运行一个场景并返回 RI_p、T_press 和 R_w。"""
    db = os.path.join(TMP, f'{tag}_{mode}.db')
    if os.path.exists(db):
        os.remove(db)

    fault_start = int(fault_start_h * 3600)
    fault_duration = int(fault_duration_h * 3600)
    fault_end = fault_start + fault_duration
    fault = S.WaterSourceInterruption(fault_start, fault_duration)
    sim_class = S.NoEWSim if mode == 'no_ew' else S.EWSim
    sim = sim_class(
        INP, db, TIMESTEP, fault_scenario=fault,
        intensity_lambda=intensity_lambda)

    if abs(diameter_scale - 1.0) > 1e-9:
        for tank in sim.tanks:
            sim.wn.get_node(tank).diameter *= diameter_scale

    if mode == 'ew' and threshold_levels is not None:
        sim.ews.LEVELS = list(threshold_levels)
        sim.ews.THRESHOLD_MAP = {
            level: threshold
            for level, threshold, _, _ in threshold_levels
        }
        sim.ews.REDUCTION_MAP = {
            level: retention
            for level, _, retention, _ in threshold_levels
        }
        sim.ews.REDUCTION_MAP['NORMAL'] = 1.0

    try:
        # 覆盖故障全过程并附加 1 h 恢复期。
        sim.run(fault_end + 3600)
    finally:
        sim.close()

    metrics = S.calculate_resilience_metrics(db, fault_start, fault_end)
    result = {
        'ri_p': metrics['RI_p'],
        't_press': metrics['T_press_h'],
        'r_w': metrics['R_w'],
    }

    if os.path.exists(db):
        os.remove(db)
    return result


def compare(key, **kwargs):
    """返回三个指标在 No-EWM/EWM 下的四相位均值及范围。"""
    samples = {
        f'{metric}_{scenario}': []
        for metric in METRICS
        for scenario in ('no', 'ew')
    }
    tasks = []
    for phase in PHASES:
        for mode, scenario in (('no_ew', 'no'), ('ew', 'ew')):
            tasks.append((mode, scenario, phase))

    # Eight independent hydraulic runs per design point are parallelized.
    with ProcessPoolExecutor(max_workers=min(WORKERS, len(tasks))) as pool:
        futures = {
            pool.submit(run_config, mode, FAULT_BASE + phase,
                        tag=f'{key}_p{phase}', **kwargs): scenario
            for mode, scenario, phase in tasks
        }
        for future in as_completed(futures):
            scenario = futures[future]
            result = future.result()
            for metric in METRICS:
                samples[f'{metric}_{scenario}'].append(result[metric])

    output = {}
    for name, values in samples.items():
        output[name] = float(np.mean(values))
        output[f'{name}_lo'] = float(np.min(values))
        output[f'{name}_hi'] = float(np.max(values))
    return output


def sweep(dimension, configs, output_csv, **fixed):
    """执行一个参数维度的扫描并输出三指标 CSV。"""
    print(f'--- {dimension} ---', flush=True)
    records = []
    started = time.time()

    for index, (key, variable) in enumerate(configs, start=1):
        parameters = {**fixed, **variable}
        result = compare(key, **parameters)
        result['key'] = key
        records.append(result)
        elapsed = time.time() - started
        print(
            f'  [{index}/{len(configs)}] {key}: '
            f'RI_p {result["ri_p_no"]:.3f}->{result["ri_p_ew"]:.3f}; '
            f'T_press {result["t_press_no"]:.2f}->{result["t_press_ew"]:.2f} h; '
            f'R_w {result["r_w_no"]:.3f}->{result["r_w_ew"]:.3f} '
            f'({elapsed:.0f}s elapsed)',
            flush=True)

    dataframe = pd.DataFrame(records)
    ordered = ['key']
    for metric in METRICS:
        for scenario in ('no', 'ew'):
            base = f'{metric}_{scenario}'
            ordered.extend([base, f'{base}_lo', f'{base}_hi'])
    dataframe = dataframe[ordered]
    dataframe.to_csv(output_csv, index=False, encoding='utf-8-sig')
    print(f'  -> {output_csv}\n', flush=True)


if __name__ == '__main__':
    print('=== 三指标敏感性分析：4相位平均 ===', flush=True)
    print(f'指标：RI_p、T_press、R_w；并行进程数：{WORKERS}\n', flush=True)

    sweep(
        'threshold',
        [(name, {'threshold_levels': levels})
         for name, levels in sorted(DESIGNS.items())],
        os.path.join(OUT, 'threshold.csv'),
        fault_duration_h=24.0)

    sweep(
        'diameter',
        [(f'{scale:.1f}', {'diameter_scale': scale})
         for scale in np.round(np.arange(0.6, 1.41, 0.1), 2)],
        os.path.join(OUT, 'diameter.csv'),
        fault_duration_h=24.0)

    sweep(
        'duration',
        [(str(duration), {'fault_duration_h': float(duration)})
         for duration in range(12, 49, 4)],
        os.path.join(OUT, 'duration.csv'))

    sweep(
        'load',
        [(f'{load:.1f}', {'intensity_lambda': load})
         for load in np.round(np.arange(0.6, 1.41, 0.1), 2)],
        os.path.join(OUT, 'load.csv'),
        fault_duration_h=24.0)

    print('ALL DONE', flush=True)
