"""Pressure-resilience co-simulation for the Anytown CPS case study.

The simulation reports five resilience metrics:

    RI_p       pressure resilience index over the fault window
    T_press    duration with average pressure >= 0.10 MPa
    R_w        time-weighted delivered service / U_max (U_max=1491.85)
    DeltaT_iso EWM delay of mean tank-outlet isolation time
    P_cov      delivered/required volume in the 09:00-12:00 peak block

At each time step, pressure performance is

    p(t) = clip(P_avg(t) / P_0, 0, 1)

and RI_p is its fault-window time average.  R_w uses unit node weights and
the normalized Anytown demand-pattern multiplier as the time-value weight.

Demand model
------------
    q_i(t) = q_i,inp * m_hat(t) * lambda * alpha(t)

    m_hat  : normalized 24-h demand pattern
    lambda : global demand intensity, applied once
    alpha  : EWM demand-retention factor {1.00, 0.70, 0.40, 0.20}
"""

import wntr
import sqlite3
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
import numpy as np
import os

import demand_patterns as DP

M_TO_MPA = 0.00980665
EMERGENCY_PRESSURE_MPA = 0.10
U_MAX_WEIGHTED_M3 = 1491.85
PEAK_BLOCK_START_HOUR = 9.0
PEAK_BLOCK_END_HOUR = 12.0


# ============================================================================
# 数据库类
# ============================================================================
class SimulationDB:
    def __init__(self, db_path='scada_sim.db'):
        self.conn = sqlite3.connect(db_path)
        self._create_tables()

    def _create_tables(self):
        c = self.conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS sensor_data (
            timestamp REAL, sensor_id TEXT, value REAL, unit TEXT,
            is_fault INTEGER DEFAULT 0, true_value REAL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS actuator_status (
            timestamp REAL, actuator_id TEXT, status INTEGER, source TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS pump_physical_status (
            timestamp REAL, pump_id TEXT, status INTEGER,
            is_fault_overridden INTEGER)''')
        c.execute('''CREATE TABLE IF NOT EXISTS control_log (
            timestamp REAL, action TEXT, reason TEXT,
            is_under_fault INTEGER DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS fault_log (
            timestamp REAL, fault_type TEXT,
            affected_pumps TEXT, description TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS early_warning_log (
            timestamp REAL, warning_level TEXT,
            trigger_tank TEXT, tank_level REAL,
            pump_physical_status INTEGER,
            trigger_threshold REAL,
            demand_reduction REAL,
            action TEXT, description TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS performance_data (
            timestamp          REAL,
            RI                 REAL,
            avg_pressure       REAL,
            delivered          REAL,
            required           REAL,
            weighted_delivered REAL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS resilience_metrics (
            metric TEXT PRIMARY KEY,
            value  REAL,
            unit   TEXT)''')
        self.conn.commit()

    def write_sensor(self, timestamp, sensor_id, value, unit='',
                     is_fault=0, true_value=None):
        if true_value is None:
            true_value = value
        self.conn.execute('INSERT INTO sensor_data VALUES (?,?,?,?,?,?)',
                          (float(timestamp), sensor_id, float(value), unit,
                           int(is_fault), float(true_value)))
        self.conn.commit()

    def write_actuator(self, timestamp, actuator_id, status, source='PLC'):
        self.conn.execute('INSERT INTO actuator_status VALUES (?,?,?,?)',
                          (timestamp, actuator_id, status, source))
        self.conn.commit()

    def write_pump_physical_status(self, timestamp, pump_id, status, is_fault_overridden):
        self.conn.execute('INSERT INTO pump_physical_status VALUES (?,?,?,?)',
                          (timestamp, pump_id, status, is_fault_overridden))
        self.conn.commit()

    def write_fault_log(self, timestamp, fault_type, affected_pumps, description):
        self.conn.execute('INSERT INTO fault_log VALUES (?,?,?,?)',
                          (timestamp, fault_type, ','.join(affected_pumps), description))
        self.conn.commit()

    def write_early_warning_log(self, timestamp, warning_level, trigger_tank, tank_level,
                                pump_physical_status, trigger_threshold,
                                demand_reduction, action, description):
        self.conn.execute('INSERT INTO early_warning_log VALUES (?,?,?,?,?,?,?,?,?)',
                          (timestamp, warning_level, trigger_tank, tank_level,
                           pump_physical_status, trigger_threshold,
                           demand_reduction, action, description))
        self.conn.commit()

    def write_performance(self, timestamp, pressure_ratio, avg_pressure,
                          delivered, required, weighted_delivered):
        """Store pressure performance and raw service terms for the five metrics."""
        self.conn.execute(
            '''INSERT INTO performance_data
               (timestamp, RI, avg_pressure, delivered, required, weighted_delivered)
               VALUES (?,?,?,?,?,?)''',
            (float(timestamp), float(pressure_ratio), float(avg_pressure),
             float(delivered), float(required), float(weighted_delivered)))
        self.conn.commit()

    def write_metric(self, metric, value, unit=''):
        self.conn.execute(
            '''INSERT OR REPLACE INTO resilience_metrics(metric, value, unit)
               VALUES (?,?,?)''', (metric, float(value), unit))
        self.conn.commit()

    def write_log(self, timestamp, action, reason, is_under_fault=0):
        self.conn.execute('INSERT INTO control_log VALUES (?,?,?,?)',
                          (timestamp, action, reason, is_under_fault))
        self.conn.commit()

    def get_latest_actuator(self, actuator_id):
        c = self.conn.execute('SELECT status FROM actuator_status '
                              'WHERE actuator_id=? ORDER BY timestamp DESC LIMIT 1', (actuator_id,))
        r = c.fetchone()
        return r[0] if r else None

    def get_latest_pump_physical_status(self, pump_id):
        c = self.conn.execute('SELECT status FROM pump_physical_status '
                              'WHERE pump_id=? ORDER BY timestamp DESC LIMIT 1', (pump_id,))
        r = c.fetchone()
        return r[0] if r else None

    def get_latest_sensor_with_fault_flag(self, sensor_id):
        c = self.conn.execute('SELECT value, is_fault, true_value FROM sensor_data '
                              'WHERE sensor_id=? ORDER BY timestamp DESC LIMIT 1', (sensor_id,))
        r = c.fetchone()
        return {'value': r[0], 'is_fault': r[1], 'true_value': r[2]} if r else None

    def close(self):
        self.conn.close()


# ============================================================================
# 水源中断故障场景
# ============================================================================
class WaterSourceInterruption:
    def __init__(self, fault_start_time=24*3600, fault_duration=24*3600, affected_pumps=None):
        self.fault_start_time = fault_start_time
        self.fault_duration = fault_duration
        self.fault_end_time = fault_start_time + fault_duration
        self.affected_pumps = affected_pumps
        self.is_active = False
        self.fault_logged = False

    def is_fault_active(self, current_time):
        return self.fault_start_time <= current_time < self.fault_end_time

    def apply_fault(self, current_time, pump_name, intended_status):
        if not self.is_fault_active(current_time):
            self.is_active = False
            return intended_status, False
        if self.affected_pumps is None or pump_name in self.affected_pumps:
            self.is_active = True
            return 0, True
        return intended_status, False


# ============================================================================
# 早期预警系统（三级阶梯 + 双重时间门控）
# ============================================================================
class EarlyWarningSystem:
    LEVELS = [
        ('CRITICAL', 2.0, 0.20, 3),
        ('ALERT',    3.5, 0.40, 2),
        ('WARNING',  5.0, 0.70, 1),
    ]
    LEVEL_RANK = {'NORMAL': 0, 'WARNING': 1, 'ALERT': 2, 'CRITICAL': 3}
    REDUCTION_MAP = {lv: rd for lv, _, rd, _ in LEVELS}
    REDUCTION_MAP['NORMAL'] = 1.0
    THRESHOLD_MAP = {lv: thr for lv, thr, _, _ in LEVELS}

    def __init__(self, db, tank_pump_map, fault_start_time, fault_end_time):
        self.db = db
        self.tank_pump_map = tank_pump_map
        self.fault_start_time = fault_start_time
        self.fault_end_time = fault_end_time
        self.current_level = 'NORMAL'
        self.current_reduction = 1.0
        self.warning_triggered = False
        self.warning_first_time = None
        self.level_history = []

    def _evaluate_tank(self, level, pump_physical_status):
        if pump_physical_status != 0:
            return 'NORMAL', None
        for lv_name, threshold, _, _ in self.LEVELS:
            if level < threshold:
                return lv_name, threshold
        return 'NORMAL', None

    def evaluate(self, current_time, tank_levels):
        if current_time < self.fault_start_time:
            return 1.0, 'NORMAL'

        if current_time >= self.fault_end_time:
            if self.current_level != 'NORMAL':
                prev = self.current_level
                self.current_level = 'NORMAL'
                self.current_reduction = 1.0
                self.db.write_early_warning_log(
                    current_time, 'NORMAL', '-', 0.0, 1, 0.0, 1.0,
                    '故障结束：解除预警，需求恢复正常',
                    f'故障于 {self.fault_end_time/3600:.1f}h 结束，{prev} -> NORMAL')
                self.db.write_log(current_time, '故障结束：需求恢复100%',
                                  f'{prev} -> NORMAL', is_under_fault=0)
            return 1.0, 'NORMAL'

        prev_level = self.current_level
        worst_level = 'NORMAL'
        worst_thr = None
        worst_tank = None
        worst_lv = None
        worst_ps = None

        for tank_id, level in tank_levels.items():
            pump_id = self.tank_pump_map.get(tank_id)
            if pump_id is None:
                continue
            phys = self.db.get_latest_pump_physical_status(pump_id)
            if phys is None:
                phys = 1
            lv, thr = self._evaluate_tank(level, phys)
            if self.LEVEL_RANK[lv] > self.LEVEL_RANK[worst_level]:
                worst_level = lv
                worst_thr = thr
                worst_tank = tank_id
                worst_lv = level
                worst_ps = phys

        if self.LEVEL_RANK[worst_level] < self.LEVEL_RANK[self.current_level]:
            worst_level = self.current_level

        self.current_level = worst_level
        self.current_reduction = self.REDUCTION_MAP[worst_level]

        if (self.LEVEL_RANK[worst_level] >= self.LEVEL_RANK['WARNING']
                and not self.warning_triggered):
            self.warning_triggered = True
            self.warning_first_time = current_time

        if worst_level != prev_level:
            rd = self.REDUCTION_MAP[worst_level]
            desc = (f"水箱 {worst_tank} 水位={worst_lv:.3f}m < {worst_thr}m，"
                    f"水泵物理关闭；需求削减至 {rd*100:.0f}%")
            self.db.write_early_warning_log(
                current_time, worst_level, worst_tank or '-', worst_lv or 0.0,
                worst_ps or 0, worst_thr or 0.0, rd,
                f"{prev_level} -> {worst_level}：需求×{rd:.2f}", desc)
            self.db.write_log(current_time, f"EWS: {prev_level}->{worst_level} 需求×{rd:.2f}",
                              desc, is_under_fault=1)
            self.level_history.append({'time_h': current_time/3600,
                                       'level': worst_level, 'reduction': rd})

        return self.current_reduction, self.current_level


# ============================================================================
# PLC 控制器
# ============================================================================
class PLC:
    def __init__(self, db):
        self.db = db
        self.rules = {'T1': {'pump': 'P1', 'low': 5.0, 'high': 8.0},
                      'T2': {'pump': 'P2', 'low': 5.0, 'high': 8.0}}
        self.pump_states = {}

    def control(self, current_time):
        for tank, rule in self.rules.items():
            data = self.db.get_latest_sensor_with_fault_flag(tank)
            if data is None:
                continue
            level = data['value']
            pump = rule['pump']
            current = self.pump_states.get(pump, self.db.get_latest_actuator(pump))
            if current is None:
                current = 1
            if current == 0 and level < rule['low']:
                new = 1
            elif current == 1 and level > rule['high']:
                new = 0
            else:
                new = current
            if new != current:
                self.db.write_actuator(current_time, pump, new, 'PLC')
            self.pump_states[pump] = new


# ============================================================================
# 步进仿真引擎（基类）
# ============================================================================
class SteppedSim:
    MIN_WATER_LEVEL = 0.05
    OUTLET_HEIGHT = 0.50

    def __init__(self, inp_file, db_path='scada_sim.db', timestep=300,
                 fault_scenario=None, demand_factor=None, verbose=False,
                 intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
        self.verbose = verbose
        self.inp_file = inp_file
        self.wn = wntr.network.WaterNetworkModel(inp_file)
        self.db = SimulationDB(db_path)
        # A unique EPANET prefix prevents temporary-file collisions when
        # sensitivity scenarios run in parallel processes.
        self._epanet_file_prefix = os.path.splitext(os.path.abspath(db_path))[0] + '_epanet'
        self.timestep = timestep
        self.current_time = 0
        self.step = 0
        # intensity_lambda is the single load scale. demand_factor kept as alias.
        if demand_factor is not None:
            intensity_lambda = demand_factor
        self.intensity_lambda = float(intensity_lambda)
        self.pattern_name = pattern_name
        self.base_demand_factor = self.intensity_lambda
        self.current_demand_factor = self.intensity_lambda
        self.fault_scenario = fault_scenario
        self.outlet_failed = {}
        self.outlet_failure_time = {}
        self.previous_levels = {}
        self.P0 = None
        self.P0_recorded = False
        self._last_pre_fault_avg = None
        self.fault_start_time = (fault_scenario.fault_start_time if fault_scenario else 24*3600)
        self.fault_end_time = (fault_scenario.fault_end_time if fault_scenario else 48*3600)

        for ctrl in list(self.wn.control_name_list):
            self.wn.remove_control(ctrl)
        for tank_name in self.wn.tank_name_list:
            self.wn.get_node(tank_name).min_level = self.MIN_WATER_LEVEL
            self.outlet_failed[tank_name] = False

        self._apply_pattern(self.intensity_lambda, self.pattern_name)

        self.tanks = self.wn.tank_name_list
        self.pumps = self.wn.pump_name_list
        self.all_junctions = self.wn.junction_name_list

        self.tank_levels = {}
        for tank in self.tanks:
            lvl = self.wn.get_node(tank).init_level
            self.tank_levels[tank] = lvl
            self.previous_levels[tank] = lvl

        self._identify_tank_outlets()

    def _identify_tank_outlets(self):
        # 水箱连接管可能是 J21->T1 / J22->T2 (起点是节点), 也可能是 T->J。
        # 只要管道一端接水箱, 即为水箱的"进出口"; 出口失效时(水位<0.5 m)将其关闭,
        # 实现真实的"重力排水出口隔离", 而非仅作水位分类。
        self.tank_outlet_pipes = {}
        for t in self.tanks:
            self.tank_outlet_pipes[t] = [
                p for p in self.wn.pipe_name_list
                if (self.wn.get_link(p).start_node_name == t
                    or self.wn.get_link(p).end_node_name == t)
            ]

    def _apply_pattern(self, intensity_lambda, pattern_name):
        """Recommendation A: EPANET pattern ≡ 1; m(t)·λ·α live in base_value."""
        self._m_hat = DP.normalised(pattern_name)
        pname = 'SIM_PATTERN'
        if pname in self.wn.pattern_name_list:
            self.wn.remove_pattern(pname)
        self.wn.add_pattern(pname, [1.0] * 24)
        self._orig_demands = []
        self._orig_base = {j: 0.0 for j in self.wn.junction_name_list}
        for junc in self.wn.junction_name_list:
            for d in self.wn.get_node(junc).demand_timeseries_list:
                if d.base_value > 0:
                    calibrated = float(d.base_value) * 0.12
                    self._orig_demands.append((junc, d, calibrated))
                    self._orig_base[junc] += calibrated
                    d.pattern_name = pname
        self._sim_pattern = list(self._m_hat)
        self._apply_absolute_demand(alpha=1.0, sim_time=0.0)

    def _apply_absolute_demand(self, alpha, sim_time):
        hour = int(sim_time // 3600) % len(self._m_hat)
        self._active_pattern_multiplier = float(self._m_hat[hour])
        scale = (self.intensity_lambda * float(alpha)
                 * self._active_pattern_multiplier)
        for _, d, orig in self._orig_demands:
            d.base_value = orig * scale
        self.current_demand_factor = self.intensity_lambda * float(alpha)

    def apply_pump_control(self):
        for ctrl in list(self.wn.control_name_list):
            self.wn.remove_control(ctrl)
        for pump_name in self.pumps:
            plc_status = self.db.get_latest_actuator(pump_name)
            if plc_status is None:
                plc_status = 1
            if self.fault_scenario:
                actual, overridden = self.fault_scenario.apply_fault(
                    self.current_time, pump_name, plc_status)
                if overridden and not self.fault_scenario.fault_logged:
                    self.db.write_fault_log(self.current_time, 'WATER_SOURCE_INTERRUPTION',
                                            list(self.pumps), '水源中断：水泵无法向水箱供水')
                    self.fault_scenario.fault_logged = True
            else:
                actual, overridden = plc_status, False
            self.db.write_pump_physical_status(self.current_time, pump_name, actual, int(overridden))
            pump = self.wn.get_link(pump_name)
            status = (wntr.network.LinkStatus.Open if actual == 1
                      else wntr.network.LinkStatus.Closed)
            act = wntr.network.controls.ControlAction(pump, 'status', status)
            cond = wntr.network.controls.SimTimeCondition(self.wn, '=', 0)
            self.wn.add_control(f'SIM_{pump_name}',
                                wntr.network.controls.Control(cond, act))

    def control_tank_outlets(self):
        # 仅在水源中断进行中才允许"出口隔离"; 故障结束后出口恢复开启, 水泵补水。
        fault_active = (self.fault_scenario.is_fault_active(self.current_time)
                        if self.fault_scenario else False)
        for tank_name in self.tanks:
            level = self.tank_levels[tank_name]
            for pipe_name in self.tank_outlet_pipes.get(tank_name, []):
                pipe = self.wn.get_link(pipe_name)
                if level < self.OUTLET_HEIGHT and fault_active:
                    pipe.initial_status = wntr.network.LinkStatus.Closed
                    if not self.outlet_failed[tank_name]:
                        self.outlet_failed[tank_name] = True
                        self.outlet_failure_time[tank_name] = self.current_time
                else:
                    pipe.initial_status = wntr.network.LinkStatus.Open
                    self.outlet_failed[tank_name] = False

    def _calc_raw_avg_pressure(self, results, sim_time):
        total = 0.0
        count = len(self.all_junctions)
        for junction in self.all_junctions:
            head = results.node['head'].loc[sim_time, junction]
            elev = self.wn.get_node(junction).elevation
            total += max(0.0, head - elev)
        return total / count if count > 0 else 0.0

    def _calc_service_terms(self, results, sim_time):
        """Return actual, nominal and time-weighted delivered rates (m3/s)."""
        delivered = sum(
            max(0.0, float(results.node['demand'].loc[sim_time, j]))
            for j in self.all_junctions)
        required = sum(self._orig_base.values()) * self.intensity_lambda \
            * self._active_pattern_multiplier
        # Latest R_w convention: all node weights w_j=1 and alpha(t)=m_hat(t).
        weighted_delivered = delivered * self._active_pattern_multiplier
        return delivered, max(required, 1e-12), weighted_delivered

    def calculate_pressure_performance(self, results, sim_time):
        """Calculate and store instantaneous terms needed by all five metrics."""
        raw_avg = self._calc_raw_avg_pressure(results, sim_time)
        if self.current_time < self.fault_start_time:
            self._last_pre_fault_avg = raw_avg
            pressure_ratio = 1.0
        elif self.current_time == self.fault_start_time:
            if not self.P0_recorded:
                self.P0 = (self._last_pre_fault_avg
                           if self._last_pre_fault_avg is not None else raw_avg)
                self.P0_recorded = True
            pressure_ratio = raw_avg / self.P0 if self.P0 > 0 else 0.0
        elif self.fault_start_time < self.current_time <= self.fault_end_time:
            pressure_ratio = raw_avg / self.P0 if (self.P0 and self.P0 > 0) else 0.0
        else:
            pressure_ratio = 1.0
        pressure_ratio = float(np.clip(pressure_ratio, 0.0, 1.0))
        delivered, required, weighted_delivered = self._calc_service_terms(
            results, sim_time)
        self.db.write_performance(
            self.current_time, pressure_ratio, raw_avg,
            delivered, required, weighted_delivered)
        return pressure_ratio, raw_avg

    def write_sensors(self, results, sim_time):
        is_fault = (self.fault_scenario.is_active if self.fault_scenario else False)
        for tank in self.tanks:
            head = results.node['head'].loc[sim_time, tank]
            elev = self.wn.get_node(tank).elevation
            level = max(self.MIN_WATER_LEVEL, head - elev)
            self.previous_levels[tank] = level
            self.db.write_sensor(self.current_time, tank, level, 'm',
                                 is_fault=int(is_fault), true_value=level)
        for pump in self.pumps:
            flow = results.link['flowrate'].loc[sim_time, pump] * 3600
            self.db.write_sensor(self.current_time, f"{pump}_flow", flow, 'm3/h')

    def record_initial_state(self):
        for tank in self.tanks:
            self.db.write_sensor(0, tank, self.tank_levels[tank], 'm')
        for pump in self.pumps:
            self.db.write_pump_physical_status(0, pump, 1, 0)
        self.wn.options.time.duration = self.timestep
        self.wn.options.time.hydraulic_timestep = self.timestep
        self.wn.options.time.report_timestep = self.timestep
        results = wntr.sim.EpanetSimulator(self.wn).run_sim(
            file_prefix=self._epanet_file_prefix)
        initial_time = results.node['head'].index[0]
        raw_avg = self._calc_raw_avg_pressure(results, initial_time)
        delivered, required, weighted_delivered = self._calc_service_terms(
            results, initial_time)
        self._last_pre_fault_avg = raw_avg
        self.db.write_performance(
            0, 1.0, raw_avg, delivered, required, weighted_delivered)

    def run_step(self, ew_demand_reduction=1.0):
        self._apply_absolute_demand(ew_demand_reduction, self.current_time)
        for tank in self.tanks:
            self.wn.get_node(tank).init_level = max(self.MIN_WATER_LEVEL, self.tank_levels[tank])
        self.control_tank_outlets()
        self.apply_pump_control()
        self.wn.options.time.duration = self.timestep
        self.wn.options.time.hydraulic_timestep = self.timestep
        self.wn.options.time.report_timestep = self.timestep
        results = wntr.sim.EpanetSimulator(self.wn).run_sim(
            file_prefix=self._epanet_file_prefix)
        for tank in self.tanks:
            head = results.node['head'].loc[self.timestep, tank]
            elev = self.wn.get_node(tank).elevation
            self.tank_levels[tank] = max(self.MIN_WATER_LEVEL, head - elev)
        self.current_time += self.timestep
        self.write_sensors(results, self.timestep)
        self.calculate_pressure_performance(results, self.timestep)
        self.step += 1
        return results

    def close(self):
        self.db.close()
        for extension in ('.inp', '.bin', '.out', '.rpt', '.hyd'):
            temporary = self._epanet_file_prefix + extension
            if os.path.exists(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass


class NoEWSim(SteppedSim):
    def __init__(self, inp_file, db_path='scada_sim.db', timestep=300,
                 fault_scenario=None, demand_factor=None, verbose=False,
                 intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
        super().__init__(inp_file, db_path, timestep, fault_scenario, demand_factor,
                         verbose, intensity_lambda, pattern_name)
        self.plc = PLC(self.db)
        for pump in self.pumps:
            self.db.write_actuator(0, pump, 1, 'INIT')

    def run(self, duration):
        steps = int(duration / self.timestep)
        self.record_initial_state()
        for i in range(steps):
            if i > 0:
                self.plc.control(self.current_time)
            self.run_step(ew_demand_reduction=1.0)


class EWSim(SteppedSim):
    def __init__(self, inp_file, db_path='scada_sim.db', timestep=300,
                 fault_scenario=None, demand_factor=None, verbose=False,
                 intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
        super().__init__(inp_file, db_path, timestep, fault_scenario, demand_factor,
                         verbose, intensity_lambda, pattern_name)
        self.plc = PLC(self.db)
        for pump in self.pumps:
            self.db.write_actuator(0, pump, 1, 'INIT')
        tank_pump_map = {tank: f"P{tank[-1]}" for tank in self.tanks}
        self.ews = EarlyWarningSystem(db=self.db, tank_pump_map=tank_pump_map,
                                      fault_start_time=self.fault_start_time,
                                      fault_end_time=self.fault_end_time)

    def run(self, duration):
        steps = int(duration / self.timestep)
        self.record_initial_state()
        for i in range(steps):
            if i > 0:
                self.plc.control(self.current_time)
            reduction, _ = self.ews.evaluate(self.current_time, self.tank_levels)
            self.run_step(ew_demand_reduction=reduction)


# ============================================================================
# 韧性指标计算
# ============================================================================
def calculate_resilience_metrics(db_path, fault_start, fault_end,
                                 pressure_threshold_mpa=EMERGENCY_PRESSURE_MPA,
                                 u_max=U_MAX_WEIGHTED_M3):
    """Calculate RI_p, T_press, R_w and P_cov over the fault window.

    Step-end samples represent the preceding hydraulic interval, so duration
    and volume metrics use right-endpoint rectangular integration. RI_p uses
    trapezoidal integration of the continuous pressure ratio.
    """
    conn = sqlite3.connect(db_path)
    df = pd.read_sql(
        '''SELECT timestamp, RI, avg_pressure, delivered, required,
                  weighted_delivered
           FROM performance_data
           WHERE timestamp >= ? AND timestamp <= ? ORDER BY timestamp''',
        conn, params=(fault_start, fault_end))
    conn.close()
    df = df.dropna()
    if len(df) < 2:
        raise ValueError('insufficient performance data in the fault window')

    ts = df['timestamp'].to_numpy(dtype=float)
    duration = float(fault_end - fault_start)
    if duration <= 0:
        raise ValueError('fault_end must be greater than fault_start')

    ri_p = float(np.clip(
        np.trapezoid(df['RI'].to_numpy(dtype=float), ts) / duration, 0.0, 1.0))

    dt = np.diff(ts)
    end_pressure_mpa = (df['avg_pressure'].to_numpy(dtype=float)[1:]
                        * M_TO_MPA)
    t_press_h = float(dt[end_pressure_mpa >= pressure_threshold_mpa].sum() / 3600.0)

    weighted_volume = float(np.sum(
        df['weighted_delivered'].to_numpy(dtype=float)[1:] * dt))
    r_w = weighted_volume / float(u_max)

    mid_hour = ((ts[:-1] + ts[1:]) / 2.0 % 86400.0) / 3600.0
    peak = ((mid_hour >= PEAK_BLOCK_START_HOUR)
            & (mid_hour < PEAK_BLOCK_END_HOUR))
    peak_delivered = float(np.sum(
        df['delivered'].to_numpy(dtype=float)[1:][peak] * dt[peak]))
    peak_required = float(np.sum(
        df['required'].to_numpy(dtype=float)[1:][peak] * dt[peak]))
    p_cov = peak_delivered / peak_required if peak_required > 0 else 0.0

    metrics = {
        'RI_p': ri_p,
        'T_press_h': t_press_h,
        'R_w': r_w,
        'P_cov': p_cov,
        'weighted_service_m3': weighted_volume,
        'peak_delivered_m3': peak_delivered,
        'peak_required_m3': peak_required,
    }
    units = {
        'RI_p': '-', 'T_press_h': 'h', 'R_w': '-', 'P_cov': '-',
        'weighted_service_m3': 'weighted_m3',
        'peak_delivered_m3': 'm3', 'peak_required_m3': 'm3',
    }
    conn = sqlite3.connect(db_path)
    conn.executemany(
        '''INSERT OR REPLACE INTO resilience_metrics(metric, value, unit)
           VALUES (?,?,?)''',
        [(name, float(value), units[name]) for name, value in metrics.items()])
    conn.commit()
    conn.close()
    return metrics


def run_one(mode, inp_file, base='../04_Simulation_Results',
            duration=3*24*3600, timestep=300, demand_factor=None,
            fault_start=24*3600, fault_duration=24*3600,
            intensity_lambda=1.0, pattern_name=DP.DEFAULT_PATTERN):
    os.makedirs(base, exist_ok=True)
    db_path = os.path.join(base, f'{mode}.db')
    if os.path.exists(db_path):
        os.remove(db_path)
    fault = WaterSourceInterruption(fault_start, fault_duration, affected_pumps=None)
    SimClass = NoEWSim if mode == 'no_ew' else EWSim
    sim = SimClass(inp_file, db_path, timestep, fault_scenario=fault,
                   demand_factor=demand_factor, verbose=False,
                   intensity_lambda=intensity_lambda, pattern_name=pattern_name)
    sim.run(duration)
    P0 = sim.P0
    ews_hist = sim.ews.level_history if mode == 'ew' else []
    fault_end = fault_start + fault_duration
    isolation_times = [
        sim.outlet_failure_time.get(tank, fault_end)
        for tank in sim.tanks
    ]
    mean_isolation_h = float(
        np.mean([(t - fault_start) / 3600.0 for t in isolation_times]))
    sim.close()

    metrics = calculate_resilience_metrics(db_path, fault_start, fault_end)
    metrics['T_iso_h'] = mean_isolation_h
    conn = sqlite3.connect(db_path)
    conn.execute(
        '''INSERT OR REPLACE INTO resilience_metrics(metric, value, unit)
           VALUES (?,?,?)''', ('T_iso_h', mean_isolation_h, 'h'))
    conn.commit()
    conn.close()
    return {'mode': mode, 'P0': P0, 'metrics': metrics,
            'db_path': db_path, 'fault_start': fault_start,
            'fault_end': fault_end, 'ews_hist': ews_hist}


def compare_scenarios(no_ew, with_ew):
    """Return the five reported metrics and persist DeltaT_iso in the EWM DB."""
    delta_t_iso = (with_ew['metrics']['T_iso_h']
                   - no_ew['metrics']['T_iso_h'])
    conn = sqlite3.connect(with_ew['db_path'])
    conn.execute(
        '''INSERT OR REPLACE INTO resilience_metrics(metric, value, unit)
           VALUES (?,?,?)''', ('DeltaT_iso_h', float(delta_t_iso), 'h'))
    conn.commit()
    conn.close()
    return {
        'RI_p': (no_ew['metrics']['RI_p'], with_ew['metrics']['RI_p']),
        'T_press_h': (no_ew['metrics']['T_press_h'],
                      with_ew['metrics']['T_press_h']),
        'R_w': (no_ew['metrics']['R_w'], with_ew['metrics']['R_w']),
        'DeltaT_iso_h': delta_t_iso,
        'P_cov': (no_ew['metrics']['P_cov'], with_ew['metrics']['P_cov']),
    }


if __name__ == "__main__":
    INP = '../03_Data_Files/anytown.inp'
    print("Running five-metric resilience simulation...")
    no_ew = run_one('no_ew', INP)
    with_ew = run_one('ew', INP)
    summary = compare_scenarios(no_ew, with_ew)

    print(f"\n{'='*72}")
    print(f"  {'Metric':<30}{'No EWM':>14}{'EWM':>14}{'Change':>12}")
    print(f"  {'-'*68}")
    for key in ('RI_p', 'T_press_h', 'R_w', 'P_cov'):
        baseline, ewm = summary[key]
        print(f"  {key:<30}{baseline:>14.4f}{ewm:>14.4f}{ewm-baseline:>+12.4f}")
    print(f"  {'DeltaT_iso_h':<30}{'--':>14}{'--':>14}"
          f"{summary['DeltaT_iso_h']:>+12.4f}")
    print(f"{'='*72}")
    print(f"  R_w convention: U_max={U_MAX_WEIGHTED_M3:.2f}, w_j=1, "
          "alpha(t)=normalized demand-pattern multiplier")
