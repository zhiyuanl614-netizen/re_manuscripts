### Response to Reviewer 2 (Part 2)

**R2-C5: "The 'time-difference buffer' seems to come mainly from physical tank storage rather than from a modeled cyber-physical mechanism."**
**Response**: We clarify that the physical storage is the *source* of the water, but the *buffer time* is strictly controlled by the cyber-physical management logic. Without the EWM warning signals and the corresponding demand-reduction controls, the physical storage is exhausted at 30.17h. The EWM logic proactively curtails demand to extend this availability to 34.33h. This 4.16-hour gain is a direct output of the cyber-physical intervention. We have added Section 4.2 in the Discussion to further elaborate on this information-physical coupling value.

**R2-C6: "Table 2 reports very similar state-duration values for T1 and T2... the abstract also reports the failure-duration reduction using a single value."**
**Response**: The Anytown network is a relatively compact and symmetrical system, and the two tanks are located at similar hydraulic elevations, leading to nearly identical depletion rates under a global load scaling. We have updated Table 4 with the fixed simulation results (e.g., T1 isolation at 34.33h vs 30.17h). Regarding the single value in the abstract, we have clarified it as the "average network isolation delay" and now report the specific value of 4.16 hours (with a phase-averaged mean of 5.15 hours) to ensure transparency.

**R2-C7: [Truncated - assuming concerns about metrics and validation]**
**Response**: To ensure the scientific rigor of our findings, we have completely reconstructed the resilience metrics in Section 2.5. The new primary metrics, Effective Service Duration ($T_{press}$) and Standardized Service Resilience ($R_w$), are anchored to the emergency service level (0.10 MPa) and normalized by the physical limit of available storage. This addressing the concern about "preserving pressure vs. delivering water" by proving a 22.1% improvement in service value even when accounting for unmet demand.

**R2-C8: [Truncated - general conclusion]**
**Response**: We have added a dedicated section on "Limitations and Future Perspectives" (Section 4.4) to discuss the potential integration of Digital Twins and AI for dynamic resilience management, addressing the reviewer's implied interest in the future scalability of the proposed EWM framework.

---
*Note: All corresponding changes in the manuscript have been highlighted in **bold blue** text as per the editor's instructions.*
