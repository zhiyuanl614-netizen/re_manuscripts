## 2.5 Resilience Assessment Metrics

To quantitatively evaluate the efficacy of the proposed Early Warning Management (EWM) system under extreme cyber-physical disruptions, we define a multi-dimensional resilience assessment framework. Following the principles of exogenous thresholding (Hashimoto et al., 1982) and functional integration (Cimellaro et al., 2010), we introduce two primary metrics that capture the system’s performance in both temporal and socio-economic dimensions.

### 2.5.1 Effective Service Duration ($T_{press}$)
This metric quantifies the duration during which the network maintains an acceptable level of hydraulic service. We define the "satisfactory state" as the period where the average nodal pressure $\bar{P}(t)$ remains above the emergency service threshold $P_{min} = 0.10$ MPa (approximately 10.2 m), as specified in the GB 50013-2018 technical standard for urban water supply.
$$T_{press} = \int_{t_d}^{t_r} I(\bar{P}(t) \geq P_{min}) dt$$
where $I(\cdot)$ is the indicator function, $t_d$ is the fault initiation time, and $t_r$ is the restoration time.

### 2.5.2 Standardized Service Resilience ($R_w$)
Traditional resilience indices often fail to account for the socio-economic value of water supply during different demand blocks. We propose a standardized service resilience metric, $R_w$, which evaluates the actual delivered water volume weighted by the time-varying demand factors $\alpha(t)$.
$$R_w = \frac{\int_{t_d}^{t_r} \sum w_j \cdot q_{del,j}(t) \cdot \alpha(t) dt}{U_{max}}$$
The denominator $U_{max}$ represents the theoretical maximum weighted service that the system could provide given the physical constraints of tank storage (approximately 1,156 m³ in this study). By anchoring the metric to the physical limit of available resources rather than the unconstrained ideal demand, $R_w$ provides a transparent measure of how effectively the management strategy utilizes finite storage to bridge supply gaps.

### 2.5.3 Supporting Indicators for Mechanism Analysis
To further elucidate the cyber-physical synergy, we utilize two supporting indicators in the discussion section:
1.  **Isolation Delay ($\Delta T_{iso}$)**: The difference in the time of tank exhaustion (outlet isolation) between the baseline and EWM scenarios, quantifying the physical time-buffer gained.
2.  **Peak-Block Coverage ($P_{cov}$)**: The ratio of delivered demand during the highest demand block (09:00–12:00, factor 1.30), reflecting the redistribution efficacy of the proactive management.
