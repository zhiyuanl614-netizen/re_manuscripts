# Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning Perspective

**Journal**: *Frontiers of Engineering Management* (FEM)  
**Manuscript ID**: FEM-2026-0130  
**Revision Deadline**: September 14, 2026  

---

## Abstract

Urban water supply cyber-physical systems (CPS) exploit the temporal discrepancy between fast cyber sensing and slow physical hydraulic degradation to enhance proactive resilience. Using a co-simulation platform (WNTR/EPANET 2.2 + SCADA control) on the Anytown benchmark network under a total water source interruption scenario ($24\text{--}48\text{ h}$), we model early warning as an operational graded demand-management intervention ($70\% / 40\% / 20\%$ demand curtailment) and evaluate system performance using both pressure-based ($RI_{\text{pressure}}$) and service-based ($RI_{\text{service}}$, Demand Satisfaction Ratio $DSR$) resilience indices. Simulation results demonstrate that early warning converts a brittle zero-supply collapse into a controlled, manageable degradation process: over a 24-h source outage, EWM increases total delivered water volume by $36.2\%$ ($1,353.5\text{ m}^3$ to $1,843.1\text{ m}^3$) and reduces cumulative unmet demand by $8.8\%$ ($6,469.3\text{ m}^3$ to $5,979.7\text{ m}^3$), while preserving pipeline head above the $0.10\text{ MPa}$ emergency threshold. Multi-factor sensitivity analysis across risk thresholds ($\Delta H \pm 1.0\text{ m}$), tank storage sizes ($0.6\times\text{--}1.4\times$), and outage durations ($12\text{--}48\text{ h}$) reveals that EWM benefits are stress-dependent, establishing clear operational application boundaries and demonstrating over-curtailment risks under light stress. These findings provide municipal water management departments with quantitative pre-plan guidelines for stress-aware emergency load shedding and adaptive dispatching.

**Keywords**: Cyber-physical systems; Urban water supply; Proactive resilience; Early warning mechanism; Pressure-driven analysis; Graded demand management

---


## 1. Introduction

Urban water supply systems serve as foundational lifeline infrastructures, delivering essential drinking water and fire-fighting capabilities to municipal populations. In recent years, rapid urbanization and industrial digital transformation have accelerated the evolution of conventional water supply infrastructures into complex Cyber-Physical Systems (CPS) (Alexandra et al., 2023; Ande et al., 2020; Liao et al., 2025). Physical hydraulic infrastructures, including reservoirs, pumping stations, distribution mains, and storage tanks, are now tightly coupled with cyber monitoring networks consisting of Supervisory Control and Data Acquisition (SCADA) telemetry, Programmable Logic Controllers (PLCs), wireless sensor networks, and automated control valves (Bhardwaj et al., 2021; Khan et al., 2020; Yadav & Paul, 2021). While this cyber-physical integration significantly enhances operational efficiency under routine conditions, modern urban water supply CPSs face unprecedented operational vulnerabilities from catastrophic disruptions, including extreme natural hazards, climate risks, power blackouts, and severe source contamination events (Argyroudis et al., 2022; Boltz et al., 2019; Khattak, 2024; Mohebbi et al., 2020).

When a catastrophic disruption strikes, such as a total water source outage causing an immediate loss of primary pumping capacity, conventional risk management frameworks predominantly rely on passive, post-disaster fail-and-repair strategies (Holling, 1973; Hosseini et al., 2016). However, physical repair times for critical pumping infrastructure or contaminated source remediation typically range from several hours to multiple days. In the absence of active operational intervention, uncurtailed consumer demand rapidly depletes emergency storage tanks, causing widespread pipeline depressurization, air binding, cascading failure propagation, and catastrophic water service collapse (He et al., 2024; Wu & Li, 2021). Consequently, there is an urgent imperative to transition urban water supply infrastructure from passive disturbance tolerance toward proactive resilience, leveraging cyber-physical capabilities, digital transformation, and organizational agility to actively manage degradation during emergency disruption windows (Garcia-Perez et al., 2023; He et al., 2023).

A critical, yet underutilized, mechanism for achieving proactive resilience is the intrinsic temporal discrepancy between cyber sensing and physical hydraulic drawdown. Cyber telemetry operates on ultra-fast time scales (~seconds), continuously acquiring pressure heads and storage levels across distribution mains. In contrast, physical hydraulic storage drawdown and network head degradation propagate across significantly slower time scales (~hours). In a coupled cyber-physical system, the identification, transmission, and operationalization of risk telemetry occur notably faster than the physical propagation and escalation of hydraulic failure (Arghandeh et al., 2016; Hassanzadeh et al., 2020). This temporal speed difference creates a valuable time-difference buffer, establishing a quantifiable time-difference window ($\Delta T$). If SCADA sensing can identify early risk trends before irreversible tank drainage occurs, this temporal window can be operationalized to trigger proactive control actions, converting a passive physical time margin into an active resilience mechanism.

Despite the growing body of literature on urban infrastructure security, existing research across relevant domains exhibits key methodological limitations when applied to proactive water supply resilience. Research on smart water networks and CPS monitoring (Bhardwaj et al., 2021; Hassanzadeh et al., 2020; Taormina et al., 2018; Yadav & Paul, 2021) has focused overwhelmingly on cybersecurity, cyber-attack detection, and automated leak localization. While these studies establish the technical feasibility of high-frequency SCADA telemetry, they rarely explore how fast cyber sensing can be coupled with physical hydraulic control to actively buffer major physical disruptions such as total source outages. Concurrently, traditional infrastructure resilience assessment frameworks (Cai et al., 2021; Casal-Campos et al., 2018; Chen et al., 2025a, 2025b; Hosseini et al., 2016; Hou et al., 2023; Liu et al., 2020; Meng et al., 2018; Zhang et al., 2022) rely heavily on structural network topology or pressure head availability. Most resilience indices evaluate physical pressure preservation relative to pre-fault baseline head, implicitly assuming that maintaining pipe pressure is synonymous with maintaining consumer supply.

Under extreme source disruptions where demand is intentionally curtailed to conserve storage, pressure-based metrics fail to account for the service sacrificed during load shedding, leading to inflated resilience assessments. Furthermore, existing early warning and decision support research in water engineering (Juan-Garcia et al., 2017; Liu, 2019; Liu & Mijic, 2025; Liu et al., 2023a; Wardropper & Brookfield, 2022) is largely restricted to alarm generation for pipe bursts or regional water routing, lacking closed-loop integration with operational demand management. Crucially, the physical mechanisms governing how early warning signals translate into delivered water gains, as well as the operational application boundaries under varying stress levels, remain unquantified.

To overcome these limitations and bridge the gap between cyber early warning and physical hydraulic operation, this study advances an integrated co-simulation and resilience evaluation framework applied to the benchmark Anytown urban water distribution network under a total source interruption scenario. Specifically, this work addresses three core objectives: first, to eliminate the catastrophic zero-supply collapse caused by rapid, uncurtailed tank depletion during total water source outages by establishing an automated, closed-loop emergency response strategy; second, to construct an integrated CPS co-simulation framework utilizing EPANET 2.2 Pressure-Driven Analysis (PDA) within the WNTR Python environment, coupling real-time SCADA tank level monitoring with a graded emergency demand-management control protocol ($70\% / 40\% / 20\%$ demand multipliers); and third, to quantitatively unpack the time-difference buffer mechanism, demonstrating how early cyber detection converts passive physical tank storage into an active resilience resource that extends supply duration, preserves pipeline head, and maximizes delivered water volume.

---

## 2. Methodology

### 2.1 Benchmark Water Distribution Network and Co-Simulation Platform

The proposed Cyber-Physical System (CPS) co-simulation and resilience evaluation framework is demonstrated on the benchmark Anytown urban water distribution network (Walski et al., 1987). As illustrated in **Fig. 1**, the physical network topology comprises 19 demand junction nodes, 34 distribution pipelines, 2 elevated storage tanks ($T1$ and $T2$), a primary water reservoir $R1$, and a main pumping station equipped with two identical parallel pumps ($P1$ and $P2$). Water is drawn from reservoir $R1$ and pumped through main transmission mains into the distribution grid. Elevated storage tanks $T1$ and $T2$ are positioned at opposite ends of the network to balance peak demand and maintain distribution pressure. Both tanks share symmetrical physical specifications, with a base elevation of $66.54\text{ m}$, a cylindrical tank diameter of $9.95\text{ m}$, a maximum operating depth of $10.67\text{ m}$, and an initial pre-fault water level of $3.051\text{ m}$. SCADA water level sensors are installed at both $T1$ and $T2$ to provide real-time storage telemetry, while SCADA pressure and flow sensors monitor junction heads and pump operating statuses across the network.

![Fig. 1 Topology and SCADA sensor/actuator configuration](figures/Fig1.png)  
**Fig. 1. Topology and SCADA sensor/actuator configuration of the benchmark Anytown water distribution network, showing junction nodes, pipelines, reservoir R1, parallel pumps P1/P2, tanks T1/T2, and SCADA telemetry points.**

The co-simulation engine couples the EPANET 2.2 Pressure-Driven Analysis (PDA) solver with Python-based SCADA control logic wrapped within the Water Network Tool for Resilience (WNTR) framework. As depicted in the co-simulation workflow diagram in **Fig. 2**, the simulation operates across a five-stage closed loop during each 300-s ($5\text{-min}$) timestep over a 72-h continuous horizon: first, the EPANET 2.2 PDA engine solves non-linear hydraulic equations to compute junction pressure heads, pipe flows, and tank storage levels; second, high-frequency SCADA sensors poll current tank water levels $H_{\text{tank}}(t)$ and pump operational statuses $S_{\text{pump}}(t)$, logging state variables into a central SQLite relational database; third, the cyber observer logic continuously compares $H_{\text{tank}}(t)$ against pre-set operational risk thresholds ($5.0\text{ m}, 4.0\text{ m}, 2.0\text{ m}, 0.50\text{ m}$) during an active water source outage; fourth, upon detecting threshold crossings, the cyber controller enforces a monotonic ratchet rule ($\gamma_t \le \gamma_{t-1}$) to prevent control chattering and transmits updated demand curtailment multipliers ($\gamma \in \{1.00, 0.70, 0.40, 0.20\}$) to network nodes; and fifth, automated AMI smart meters and pressure-reducing valves throttle nodal demand accordingly for the subsequent simulation timestep.

![Fig. 2 Integrated WNTR/EPANET 2.2 co-simulation workflow](figures/Fig3.png)  
**Fig. 2. Integrated WNTR/EPANET 2.2 co-simulation workflow and SCADA control loop, detailing the five-stage interaction between EPANET 2.2 PDA execution, SQLite SCADA logging, EWM observer evaluation, ratchet control enforcement, and actuator execution.**

### 2.2 Idealized Modeling Assumptions and Scope Boundaries

To establish a rigorous baseline for quantifying proactive cyber-physical resilience, the co-simulation model incorporates several idealized assumptions regarding cyber communication, control execution, and hydraulic behavior. Table 1 explicitly delineates these assumptions, assesses their potential impacts on practical engineering implementations, and outlines corresponding engineering mitigation measures.

**Table 1: Explicit declaration of modeling assumptions, engineering impacts, and mitigation measures**

| Assumption Domain | Idealized Assumption | Potential Impact on Engineering Practice | Practical Engineering Mitigation Measure |
| :--- | :--- | :--- | :--- |
| **Cyber Sensing** | Sensors provide continuous, error-free SCADA telemetry of tank levels and pump states. | Measurement noise or sensor drift could cause premature or delayed EWM triggering. | Implement local Kalman filtering and dual-redundant sensor polling at tank sites. |
| **Communication Network** | Zero transmission latency, zero packet loss, and infinite bandwidth between SCADA and PLCs. | Network congestion or signal packet loss may delay demand reduction commands by seconds to minutes. | Deploy edge-computing PLCs capable of autonomous threshold evaluation during network outages. |
| **Control Execution** | Nodal demand curtailment is executed instantaneously and uniformly across all customer nodes. | Physical valve throttling at customer service connections requires finite mechanical actuation time. | Implement automated AMI-enabled smart meters and pressure-reducing valves (PRVs) with pre-set emergency routines. |
| **Hydraulic Water Quality** | Water quality (e.g., chlorine residual, age) is assumed non-degrading during emergency supply. | Low-flow velocity during severe demand curtailment may increase water age and stagnation. | Limit CRITICAL state duration and enforce post-event pipe flushing protocols. |
| **Disturbance Scenario** | Water source outage is modeled as a deterministic, step-function total pump shutdown ($24\text{--}48\text{ h}$). | Real-world power outages or pipe bursts may exhibit partial or cascading failure dynamics. | Conduct multi-factor sensitivity analysis across varying outage durations ($12\text{--}48\text{ h}$). |

### 2.3 Cyber-Physical Early Warning Mechanism (EWM) and Graded Demand Management

Rather than functioning merely as a passive status logger or alarm monitor, the Cyber-Physical Early Warning Mechanism (EWM) operationalizes early risk detection into concrete, closed-loop emergency hydraulic interventions. As illustrated in the three-layer CPS architecture in **Fig. 3**, the system integrates three tightly coupled layers: the Cyber Sensing Layer, where SCADA sensors poll tank water levels $H_{\text{tank}}(t)$ and pump operational statuses $S_{\text{pump}}(t)$ at $300\text{-s}$ intervals, transmitting telemetry signals through a gateway interface to the cyber control layer; the Cyber Control Layer, where upon receiving confirmation of a water source outage (pump shutdown $S_{\text{pump}} = 0$ at $t = 24\text{ h}$), the cyber controller evaluates current tank levels against pre-established operational risk thresholds ($5.0\text{ m}, 4.0\text{ m}, 2.0\text{ m}, 0.50\text{ m}$), enforcing a monotonic ratchet constraint ($\gamma_t \le \gamma_{t-1}$) to prevent control chattering and issuing state-dependent demand reduction multipliers ($\gamma \in \{1.00, 0.70, 0.40, 0.20\}$); and the Physical Hydraulic Layer, where demand reduction commands are executed at distribution junctions, throttling consumer outflow, slowing tank volumetric drainage ($d H_{\text{tank}} / dt = (Q_{\text{in}} - Q_{\text{out}}) / A_{\text{tank}}$), keeping tank outlet pipes submerged above $0.50\text{ m}$, and maintaining pipeline pressure above the $0.10\text{ MPa}$ ($\approx 10\text{ m}$) emergency threshold.

$$\text{Demand}(j, t) = \gamma(t) \cdot \text{BaseDemand}(j) \cdot \text{Pattern}(t)$$

![Fig. 3 Three-layer Cyber-Physical System architecture](figures/Fig2.png)  
**Fig. 3. Three-layer Cyber-Physical System (CPS) architecture illustrating closed-loop interaction among Sensing Layer (SCADA telemetry polling), Control Layer (EWM risk observer, ratchet rule enforcement, demand multiplier selection), and Physical Hydraulic Layer (junction demand throttling, tank level preservation, pipeline head maintenance).**

**Table 2: Operational trigger logic and demand management actions of EWM**

| Risk State | Tank Level Threshold ($H_{\text{tank}}$) | Pump Status ($S_{\text{pump}}$) | Demand Multiplier ($\gamma$) | Operational Action & Hydraulic Effect |
| :--- | :--- | :---: | :---: | :--- |
| **NORMAL** | $H_{\text{tank}} \ge 5.0\text{ m}$ | Operational ($S=1$) | $1.00$ | Standard supply; 100% nominal demand delivered. |
| **WARNING** | $H_{\text{tank}} < 5.0\text{ m}$ | Outage ($S=0$) | $0.70$ | Level 1 curtailment; 30% non-essential demand shed; slows initial storage drawdown. |
| **ALERT** | $H_{\text{tank}} < 4.0\text{ m}$ | Outage ($S=0$) | $0.40$ | Level 2 curtailment; 60% demand shed; preserves pressure above critical supply head ($0.10\text{ MPa}$). |
| **CRITICAL** | $H_{\text{tank}} < 2.0\text{ m}$ | Outage ($S=0$) | $0.20$ | Level 3 curtailment; 80% demand shed; maintains minimum emergency head and prevents tank dry-out. |
| **OUTLET FAILURE** | $H_{\text{tank}} < 0.50\text{ m}$ | Outage ($S=0$) | $0.00$ | Physical pipe closure; outlet valve shuts to prevent cavitation and air entrainment. |

The rationale for setting these specific water level risk thresholds ($5.0\text{ m}, 4.0\text{ m}, 2.0\text{ m}, 0.50\text{ m}$) integrates physical, operational, and regulatory constraints. First, the Outlet Failure threshold ($0.50\text{ m}$) is dictated by the physical crown elevation of tank outlet pipes, below which vortexing, air entrainment, and pump cavitation occur, requiring immediate isolation (Zhang et al., 2024). Second, the Normal threshold ($5.0\text{ m}$) aligns strictly with the baseline SCADA pump start setpoint ($H \le 5.0\text{ m}$ start, $H \ge 8.0\text{ m}$ stop), establishing operational self-consistency across routine and emergency modes. Third, the intermediate Warning ($5.0\text{ m}$), Alert ($4.0\text{ m}$), and Critical ($2.0\text{ m}$) thresholds evenly divide the active storage depth, providing progressive reaction time windows ($\sim 1.0\text{--}3.5\text{ h}$) that allow the network to step down demand in a controlled manner, ensuring that system pressure remains above the $0.10\text{ MPa}$ ($\approx 10\text{ m}$) minimum service head required by national engineering standards (MOHURD, 2018).

### 2.4 Experimental Control and Fairness of Comparison

To guarantee complete experimental rigor and eliminate potential bias in resilience quantification, the 'Without EWM' (baseline) and 'With EWM' (intervened) simulation scenarios are executed on an identical hydraulic modeling baseline. Both cases are evaluated using the EPANET 2.2 Pressure-Driven Analysis (PDA) solver wrapped within the WNTR Python framework. Both scenarios share identical network topology, pipe roughness, node elevations, initial tank levels ($3.051\text{ m}$), hydraulic step sizes ($\Delta t = 300\text{ s}$), and physical tank outlet protection thresholds ($H_{\text{outlet}} = 0.50\text{ m}$).

The abrupt pressure drop observed in the baseline case is not an assumed binary failure rule, but rather the deterministic hydraulic outcome of uncurtailed 100% demand under total source interruption: high outflow drains the tank storage within $\sim 6\text{ h}$, causing water level to drop below $0.50\text{ m}$, which forces the physical closure of tank outlet pipes to prevent pump/pipe cavitation. The single controlled experimental variable between the two scenarios is the activation of early-warning-triggered demand management. Table 3 lists the side-by-side experimental control matrix.

**Table 3: Comparative experimental control matrix between Without EWM and With EWM scenarios**

| Simulation Parameter / Rule | Baseline Scenario (Without EWM) | Proposed Scenario (With EWM) | Experimental Control Status |
| :--- | :--- | :--- | :--- |
| **Hydraulic Solver Engine** | WNTR / EPANET 2.2 (PDA) | WNTR / EPANET 2.2 (PDA) | **Identical** |
| **Simulation Horizon / Step** | $72\text{ h}$ total / $\Delta t = 300\text{ s}$ | $72\text{ h}$ total / $\Delta t = 300\text{ s}$ | **Identical** |
| **Disruption Scenario** | Total pump outage ($t=24\text{--}48\text{ h}$) | Total pump outage ($t=24\text{--}48\text{ h}$) | **Identical** |
| **Tank Outlet Closure Rule** | Closed when $H_{\text{tank}} < 0.50\text{ m}$ | Closed when $H_{\text{tank}} < 0.50\text{ m}$ | **Identical** |
| **Baseline System Head ($P_0$)** | $55.23\text{ m}$ ($0.541\text{ MPa}$) | $55.23\text{ m}$ ($0.541\text{ MPa}$) | **Identical** |
| **Demand Management Multiplier** | Constant $\gamma = 1.00$ (No intervention) | Dynamic $\gamma \in \{1.00, 0.70, 0.40, 0.20\}$ | **Single Controlled Variable** |

### 2.5 Dual Resilience Metrics and Volumetric Accounting Formulation

To distinguish between pipeline pressure maintenance and actual water service delivery, a dual-metric resilience evaluation framework is established. The actual delivered nodal flow $Q_{\text{del}, j}(t)$ is governed by EPANET Pressure-Driven Analysis (PDA):

$$Q_{\text{del}, j}(t) = \begin{cases} Q_{\text{req}, j}(t), & \text{if } H_j(t) \ge H_{\text{req}} \\ Q_{\text{req}, j}(t) \cdot \left(\frac{H_j(t) - H_{\text{min}}}{H_{\text{req}} - H_{\text{min}}}\right)^{\alpha}, & \text{if } H_{\text{min}} < H_j(t) < H_{\text{req}} \\ 0, & \text{if } H_j(t) \le H_{\text{min}} \end{cases}$$

1. **Pressure Resilience Index ($RI_{\text{pressure}}$)**: Evaluates physical hydraulic head preservation relative to baseline pressure $P_0$:

$$RI_{\text{pressure}} = \frac{1}{T_{\text{fault}}} \int_{t_{\text{start}}}^{t_{\text{end}}} \frac{\bar{P}(t)}{P_0} \, dt$$

2. **Service Resilience Index ($RI_{\text{service}}$)**: Evaluates water service continuity based on the Demand Satisfaction Ratio ($DSR(t)$):

$$DSR(t) = \frac{\sum Q_{\text{del}, j}(t)}{\sum Q_{\text{nom}, j}(t)}, \quad RI_{\text{service}} = \frac{1}{T_{\text{fault}}} \int_{t_{\text{start}}}^{t_{\text{end}}} DSR(t) \, dt$$

3. **Cumulative Unmet Demand ($V_{\text{unmet}}$)**: Quantifies total water supply deficit ($m^3$):

$$V_{\text{unmet}} = \int_{t_{\text{start}}}^{t_{\text{end}}} \left( \sum Q_{\text{nom}, j}(t) - \sum Q_{\text{del}, j}(t) \right) \, dt$$

---

## 3. Results

### 3.1 Tank Water Level Dynamics and Risk State Transitions

The water storage tank level drawdown trajectories and EWM risk state transitions for Tanks T1 and T2 under Without EWM and With EWM scenarios are visually demonstrated in **Fig. 4**. Under the uncurtailed baseline scenario, high uncurtailed consumer demand ($100\%$ load) causes rapid, steep water level drawdown in both Tank T1 (**Fig. 4(a)**, left upper panel) and Tank T2 (**Fig. 4(b)**, right upper panel). Starting from an initial level of $3.051\text{ m}$, water levels in T1 and T2 drop rapidly across $2.50\text{ h}$ and $2.42\text{ h}$ respectively, breaching the $0.50\text{ m}$ Outlet Failure threshold at $t = 29.50\text{ h}$ (T1) and $t = 29.42\text{ h}$ (T2). This triggers automatic physical outlet valve closure to prevent air entrainment and pump cavitation, leaving both tanks completely isolated and drained for the remaining $18.50\text{ h}$ and $18.58\text{ h}$ of the $24\text{-h}$ source outage.

In stark contrast, under the proposed EWM scenario, the activation of graded demand curtailment significantly alters the drawdown trajectory. As water levels drop below the $5.0\text{ m}$ Warning threshold upon pump outage at $t = 24\text{ h}$, demand is immediately reduced to $70\%$ ($\gamma = 0.70$), flattening the initial drawdown slope. As storage drops further across the $4.0\text{ m}$ Alert threshold ($t = 25.0\text{ h}$) and $2.0\text{ m}$ Critical threshold ($t = 28.5\text{ h}$), demand is progressively stepped down to $40\%$ ($\gamma = 0.40$) and $20\%$ ($\gamma = 0.20$). As shown in the state progression bands in **Fig. 4(a)** and **Fig. 4(b)**, this progressive demand reduction extends the active water discharge duration of Tanks T1 and T2 from $5.46\text{ h}$ to $11.83\text{ h}$, delaying Outlet Failure until $t = 35.83\text{ h}$ and reducing the total Outlet Failure duration from $18.50\text{--}18.58\text{ h}$ down to $12.17\text{ h}$ for both tanks, representing an effective expansion of the operational reaction window by $6.33\text{ h}$. Table 4 summarizes the exact state duration values and Outlet Failure timings.

![Fig. 4 Water storage tank water level dynamics and early warning risk state transitions](figures/Fig4.png)  
**Fig. 4. Water storage tank water level dynamics and early warning risk state transitions under a 24-h water source outage ($t = 24\text{--}48\text{ h}$). Upper panels illustrate water level drawdown for Tank T1 (a, left) and Tank T2 (b, right) under Without EWM and With EWM scenarios. Lower state bands show the temporal progression of EWM risk states: NORMAL ($\ge 5.0\text{ m}$), WARNING ($< 5.0\text{ m}$), ALERT ($< 4.0\text{ m}$), CRITICAL ($< 2.0\text{ m}$), and OUTLET FAILURE ($< 0.50\text{ m}$). The EWM demand management delays Outlet Failure, expanding the operational reaction window by $6.33\text{ h}$.**

**Table 4: Tank state durations and Outlet Failure timings for Tanks T1 and T2**

| Scenario | Tank ID | Normal ($\ge 5.0\text{ m}$) | Warning ($< 5.0\text{ m}$) | Alert ($< 4.0\text{ m}$) | Critical ($< 2.0\text{ m}$) | Outlet Failure ($< 0.50\text{ m}$) | Total Outflow Duration |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Without EWM** | **T1** | $0.00\text{ h}$ | $0.00\text{ h}$ | $2.50\text{ h}$ | $3.00\text{ h}$ | $18.50\text{ h}$ | **$5.50\text{ h}$** |
| | **T2** | $0.00\text{ h}$ | $0.00\text{ h}$ | $2.42\text{ h}$ | $3.00\text{ h}$ | $18.58\text{ h}$ | **$5.42\text{ h}$** |
| **With EWM** | **T1** | $0.00\text{ h}$ | $1.00\text{ h}$ | $3.50\text{ h}$ | $7.33\text{ h}$ | $12.17\text{ h}$ | **$11.83\text{ h}$** |
| | **T2** | $0.00\text{ h}$ | $1.00\text{ h}$ | $3.50\text{ h}$ | $7.33\text{ h}$ | $12.17\text{ h}$ | **$11.83\text{ h}$** |

### 3.2 System Pressure Trajectories and Dual-Metric Volumetric Accounting

The network-wide average junction pressure $P_{\text{avg}}(t)$ and system performance trajectory over the $72\text{-h}$ simulation timeline are illustrated in **Fig. 5**. During the pre-fault phase ($0\text{--}24\text{ h}$), average system pressure remains stably elevated at $55.23\text{ m}$ ($0.541\text{ MPa}$). Upon pump shutdown at $t = 24\text{ h}$, the baseline curve without EWM exhibits a steep pressure drop as uncurtailed demand drains the tanks. At $t = 30.2\text{ h}$, complete tank dry-out triggers physical outlet pipe closure, causing network pressure to collapse abruptly to zero ($0.00\text{ MPa}$) and creating a complete zero-supply blackout for the remaining $17.8\text{ h}$ of the outage.

Conversely, the performance trajectory under EWM intervention in **Fig. 5** demonstrates the dynamic pressure stabilization achieved through proactive load control. As demand is progressively curtailed ($70\% \to 40\% \to 20\%$), line head loss decreases and storage depletion slows, maintaining $P_{\text{avg}}(t)$ consistently above the dashed horizontal line representing the critical $0.10\text{ MPa}$ ($\approx 10\text{ m}$) emergency service threshold throughout the entire $24\text{-h}$ outage ($24\text{--}48\text{ h}$). The shaded region between the intervened and baseline performance curves visually highlights the integrated system performance area preserved by EWM, raising the Pressure Resilience Index ($RI_{\text{pressure}}$) from $0.22$ to $0.84$ ($\Delta = +0.62$).

![Fig. 5 Network-wide average junction pressure and performance trajectory](figures/Fig5.png)  
**Fig. 5. Network-wide average junction pressure $P_{\text{avg}}(t)$ and system performance trajectory $P(t)$ during the 72-h simulation horizon under Without EWM and With EWM scenarios, showing pressure preservation above the critical service threshold ($0.10\text{ MPa} \approx 10\text{ m}$, dashed horizontal line) throughout the 24-h outage period.**

To resolve the potential distortion of evaluating resilience solely through pressure preservation, **Fig. 6** provides a side-by-side comparison of the dual resilience indices and the volumetric water accounting results over the disruption period ($V_{\text{req}} = 7,822.8\text{ m}^3$). In **Fig. 6(a)**, the bar chart compares $RI_{\text{pressure}}$ ($0.22$ vs. $0.84$) alongside $RI_{\text{service}}$ ($0.23$ vs. $0.29$). While $RI_{\text{pressure}}$ exhibits a massive $+0.62$ jump due to pipeline head preservation, $RI_{\text{service}}$ reflects the actual Demand Satisfaction Ratio ($DSR$), showing a modest but meaningful $+0.058$ improvement.

**Fig. 6(b)** details the volumetric water accounting bars, contrasting total delivered water volume $V_{\text{del}}$ against cumulative unmet demand $V_{\text{unmet}}$. Without EWM, uncurtailed $100\%$ demand drains tanks within $6\text{ h}$, yielding a total delivered volume of only $1,353.5\text{ m}^3$ followed by $18\text{ h}$ of total blackout. Under EWM, graded curtailment maintains continuous low-rate supply across all $24\text{ h}$, delivering $1,843.1\text{ m}^3$ of water. As quantified in **Fig. 6(b)**, EWM achieves a **$+36.2\%$ net gain in total delivered water** ($+489.6\text{ m}^3$) and an **$-8.8\%$ net reduction in cumulative unmet demand** ($5,979.7\text{ m}^3$ vs. $6,469.3\text{ m}^3$), proving that continuous low-rate emergency supply delivers significantly more water than short-lived full-rate supply followed by prolonged blackout. Table 5 summarizes these quantitative metrics.

![Fig. 6 Dual-metric resilience comparison and volumetric water accounting](figures/Fig6.png)  
**Fig. 6. Dual-metric resilience comparison and volumetric water accounting ($t=24\text{--}48\text{ h}$). Panel (a) compares Pressure Resilience Index ($RI_{\text{pressure}}$) and Service Resilience Index ($RI_{\text{service}}$). Panel (b) illustrates cumulative delivered water volume ($V_{\text{del}}$) and unmet demand ($V_{\text{unmet}}$), quantifying the $+36.2\%$ net gain in delivered water.**

**Table 5: Dual-metric resilience assessment and volumetric water accounting ($t=24\text{--}48\text{ h}$)**

| Metric Category | Performance Indicator | Baseline (Without EWM) | Proposed (With EWM) | Net Change ($\Delta$) | Physical & Operational Significance |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **Resilience Index** | Pressure Index ($RI_{\text{pressure}}$) | $0.22$ | $0.84$ | $+0.62$ | Pipeline head maintained above critical threshold. |
| | Service Index ($RI_{\text{service}}$) | $0.23$ | $0.29$ | $+0.058$ | Continuity of actual delivered water service. |
| **Water Accounting** | Delivered Volume ($V_{\text{del}}$) | $1,353.5\text{ m}^3$ | $1,843.1\text{ m}^3$ | **$+489.6\text{ m}^3$ (+36.2%)** | **Net gain in actual water delivered to consumers.** |
| | Unmet Demand ($V_{\text{unmet}}$) | $6,469.3\text{ m}^3$ | $5,979.7\text{ m}^3$ | **$-8.8\%$ (-489.6 $\text{m}^3$)** | **Net reduction in municipal water deficit.** |
| | Nominal Demand ($V_{\text{req}}$) | $7,822.8\text{ m}^3$ | $7,822.8\text{ m}^3$ | $0.0\text{ m}^3$ | Shared uncurtailed baseline water demand. |

### 3.3 Multi-Factor Sensitivity Analysis and Operational Application Boundaries

To evaluate model robustness and identify operational application boundaries, a multi-factor sensitivity analysis was executed across risk threshold shifts ($\Delta H \in [-1.0, +1.0]\text{ m}$), tank storage scaling ($D_{\text{tank}} \in [0.6\times, 1.4\times]$), and outage durations ($T_{\text{fault}} \in [12\text{--}48\text{ h}]$). The visual trajectories and performance trade-offs are depicted in **Fig. 7** and **Fig. 8**, with quantitative metrics summarized in Table 6.

**Fig. 7** illustrates the sensitivity of delivered water volume gain across varying outage durations in **Fig. 7(a)** and tank storage capacities in **Fig. 7(b)**:
- **Outage Duration Sensitivity (Fig. 7(a))**: The response trajectory reveals a critical operational application boundary at $T_{\text{fault}} = 18\text{ h}$. For short outages ($T_{\text{fault}} = 12\text{ h}$), passive tank storage is sufficient to maintain supply without reaching outlet closure; active demand curtailment under EWM causes unnecessary service restriction, resulting in a slight net reduction in delivered volume ($-4.7\%$, represented by the over-curtailment region below $0\%$). Beyond $18\text{ h}$, however, as uncurtailed tanks dry out, EWM yields massive positive gains, reaching $+36.2\%$ at $24\text{ h}$ and $+117.9\%$ at $48\text{ h}$.
- **Tank Capacity Sensitivity (Fig. 7(b))**: The curve exhibits a steep negative slope, demonstrating a strong inverse storage dependency. In storage-constrained networks ($0.6\times$ diameter), passive storage exhausts rapidly, making EWM essential and yielding a massive **$+208.2\%$ gain in delivered water volume**. Conversely, in systems with large storage tanks ($1.4\times$ diameter), passive storage alone buffers the outage, rendering active load shedding redundant ($+0.09\%$ gain).

![Fig. 7 Sensitivity of delivered water volume gain across outage durations and tank sizes](figures/Fig7.png)  
**Fig. 7. Sensitivity of delivered water volume gain and unmet demand reduction across outage durations ($12\text{--}48\text{ h}$, a) and tank storage capacities ($0.6\times\text{--}1.4\times$, b), highlighting the $18\text{-h}$ over-curtailment boundary and inverse storage dependency.**

**Fig. 8** presents the response of Pressure Resilience Index ($RI_{\text{pressure}}$) and Service Resilience Index ($RI_{\text{service}}$) across risk threshold shifts ($\Delta H \in [-1.0, +1.0]\text{ m}$). Both metrics exhibit smooth, monotonic increases as thresholds are shifted upward ($+1.0\text{ m}$ conservative triggering), with $RI_{\text{pressure}}$ rising from $0.81$ to $0.87$ and $RI_{\text{service}}$ rising from $0.27$ to $0.30$. Crucially, delivered volume gains remain robustly positive ($+27.1\%$ to $+45.3\%$) across all threshold levels, proving that EWM performance is highly tolerant to threshold calibration variations.

![Fig. 8 Sensitivity of Pressure Resilience Index and Service Resilience Index](figures/Fig8.png)  
**Fig. 8. Sensitivity of Pressure Resilience Index ($RI_{\text{pressure}}$) and Service Resilience Index ($RI_{\text{service}}$) across risk threshold shifts ($\Delta H \in [-1.0, +1.0]\text{ m}$), demonstrating model robustness against threshold calibration uncertainty.**

**Table 6: Multi-factor sensitivity analysis and operational application boundaries**

| Sensitivity Factor | Factor Level | $RI_{\text{pressure}}$ (No / With) | $RI_{\text{service}}$ (No / With) | Delivered Volume Gain (%) | Unmet Demand Reduction (%) | Operational Boundary & Performance Regime |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **Threshold Shift ($\Delta H$)** | $-1.0\text{ m}$ | $0.22 / 0.81$ | $0.23 / 0.27$ | $+27.1\%$ | $-5.8\%$ | **Robust Positive Gain**: High tolerance to threshold calibration. |
| | $0.0\text{ m}$ (Baseline) | $0.22 / 0.84$ | $0.23 / 0.29$ | $+36.2\%$ | $-8.8\%$ | **Optimal Baseline**: Balanced pressure and service gains. |
| | $+1.0\text{ m}$ | $0.22 / 0.87$ | $0.23 / 0.30$ | $+45.3\%$ | $-9.9\%$ | **Conservative Trigger**: Earlier curtailment preserves more storage. |
| **Tank Diameter ($D_{\text{tank}}$)** | $0.6\times$ | $0.09 / 0.77$ | $0.09 / 0.22$ | **$+208.2\%$** | $-18.7\%$ | **Critical EWM Value**: Essential for storage-constrained networks. |
| | $1.0\times$ (Baseline) | $0.22 / 0.84$ | $0.23 / 0.29$ | $+36.2\%$ | $-8.8\%$ | **Moderate EWM Value**: Substantial service continuity gain. |
| | $1.4\times$ | $0.51 / 0.90$ | $0.51 / 0.53$ | $+0.09\%$ | $-0.08\%$ | **Low EWM Value**: Passive physical storage dominates. |
| **Fault Duration ($T_{\text{fault}}$)** | $12\text{ h}$ | $0.43 / 0.89$ | $0.46 / 0.43$ | **$-4.7\%$** | $+1.4\%$ | **Over-Curtailment Boundary**: Unnecessary for minor outages. |
| | $24\text{ h}$ (Baseline) | $0.22 / 0.84$ | $0.23 / 0.29$ | $+36.2\%$ | $-8.8\%$ | **High EWM Value**: Prevents complete zero-supply collapse. |
| | $48\text{ h}$ | $0.11 / 0.79$ | $0.11 / 0.22$ | **$+117.9\%$** | $-13.6\%$ | **Vital EWM Value**: Maintains lifeline water supply during prolonged events. |

---

## 4. Discussion

### 4.1 Three-Layer Cyber-Physical Linkage Mechanism and Time-Difference Buffer

The proactive resilience demonstrated by the EWM framework emerges directly from the tight, closed-loop coupling across the three layers of the urban water supply CPS (**Fig. 3**). The Cyber Sensing Layer continuously polls tank telemetry and pump operational status at $300\text{-s}$ intervals. Upon pump shutdown at $t = 24\text{ h}$, the sensing layer detects storage drawdown within minutes, hours before physical pipe depressurization becomes severe. The Cyber Control Layer processes these signals, evaluates current tank levels against risk thresholds, applies a monotonic ratchet rule to prevent control oscillation, and transmits demand reduction multipliers ($\gamma = 0.70, 0.40, 0.20$) to distribution nodes. The Physical Hydraulic Layer responds by reducing volumetric discharge, slowing tank drainage ($d H_{\text{tank}} / dt = (Q_{\text{in}} - Q_{\text{out}}) / A_{\text{tank}}$), and keeping tank outlet valves submerged above $0.50\text{ m}$.

While physical storage provides the raw hydraulic capacity, the cyber layer actively manages the rate of consumption, converting passive water volume into an active time-difference buffer that sustains pipeline head above $0.10\text{ MPa}$ throughout the outage. Thus, proactive resilience is an emergent property of integrated cyber-physical coupling rather than a feature of physical storage alone.

### 4.2 Physical Insights from Dual-Metric Divergence

The observed divergence between the pressure-based index ($RI_{\text{pressure}} = 0.84$) and the service-based index ($RI_{\text{service}} = 0.29$) provides critical insights for water infrastructure performance assessment. Traditional resilience frameworks heavily rely on pressure head or topological connectivity (Casal-Campos et al., 2015; Meng et al., 2018), which can overstate performance recovery during operational emergency interventions. Under Pressure-Driven Analysis (PDA), maintaining pipeline pressure during source outages is accomplished by intentionally curtailing outflow. Therefore, evaluating resilience solely through pressure head reflects physical pressure robustness (the preservation of structural head above cavitation thresholds) rather than actual water service delivery.

By introducing the Demand Satisfaction Ratio ($DSR$) alongside volumetric water accounting, this study provides an honest, service-oriented assessment. Crucially, volumetric accounting confirms that graded demand curtailment yields a net $36.2\%$ increase in total delivered water ($+489.6\text{ m}^3$) over the $24\text{-h}$ disruption. This net gain occurs because uncurtailed demand causes rapid tank dry-out and an $18\text{-h}$ complete outage ($1,353.5\text{ m}^3$ delivered), whereas EWM maintains continuous controlled emergency supply over the entire outage period ($1,843.1\text{ m}^3$ delivered). These results demonstrate that evaluating emergency load management requires dual-dimensional accounting to prevent misinterpreting pressure preservation as uncompromised consumer service.

### 4.3 Study Limitations and Physical Boundaries

While the proposed framework demonstrates significant hydraulic resilience gains, three key physical and operational limitations warrant explicit acknowledgment. First, operating distribution networks under extended low-flow demand curtailment increases water age in distribution mains and storage tanks (Sitzenfrei, 2021). Prolonged water residence time accelerates disinfectant residual decay (e.g., free chlorine depletion) and elevates microbial regrowth risks (WHO, 2022; Zou et al., 2023), which may compromise drinking water safety despite maintaining hydraulic pressure. Second, severe localized pressure head drops during extreme supply disruptions increase the risk of transient sub-atmospheric pressure dips, which can induce back-siphonage or contaminant intrusion through pipe joints and cracks (Mignot & Dewals, 2022; Taiwo et al., 2023). Although EWM maintains global average head above $0.10\text{ MPa}$ to mitigate this hazard, explicit transient water quality-hydraulic modeling remains necessary to evaluate localized contamination risks. Third, the baseline model implements uniform percentage demand curtailment across all network junctions. In actual municipal water systems, demand shedding must incorporate social priorities and critical infrastructure classification (Sadien et al., 2024; Zhang et al., 2025), safeguarding healthcare facilities and residential lifelines while restricting non-essential commercial and industrial consumption.

### 4.4 Future Research Directions: Digital Twin Integration and Adaptive Control

To overcome the rigidity of fixed water level thresholds, future research will focus on integrating Digital Twin technology with AI-driven adaptive control. The WNTR/EPANET co-simulation platform can be scaled into an online digital twin shadow model, ingesting real-time SCADA pressure and flow streams via SQLite/MQTT protocols to predict hydraulic storage drawdown trajectories $1\text{--}6\text{ h}$ in advance. Furthermore, lightweight Reinforcement Learning (RL) or Gradient Boosted Decision Tree (GBDT) agents trained on multi-scenario offline co-simulation ensembles can dynamically adjust triggering thresholds ($\Delta H$) and curtailment ratios ($\gamma$) based on real-time disruption severity, initial storage levels, and forecasted diurnal demand patterns. This AI-driven adaptive triggering framework will eliminate over-curtailment risks during minor disruptions while maximizing service continuity during catastrophic outages.

## 5. Conclusions

### 5.1 Theoretical Findings

This study establishes a proactive resilience paradigm for urban water supply Cyber-Physical Systems (CPS) under extreme water source outages. We demonstrate that system resilience is not merely a passive property determined by physical pipe sizing or tank capacity, but an emergent, dynamic capability driven by the coupling of cyber early warning with physical demand management. By exploiting the time-difference buffer between rapid cyber sensing and gradual hydraulic degradation, proactive demand curtailment actively transforms passive storage reserves into extended operational survival time.

### 5.2 Key Simulation Insights

Quantitative co-simulation on the Anytown benchmark network under a 24-h total pump outage reveals three core insights: first, EWM elevates the Pressure Resilience Index ($RI_{\text{pressure}}$) from $0.22$ to $0.84$ ($\Delta = +0.62$) and the Service Resilience Index ($RI_{\text{service}}$) from $0.23$ to $0.29$ ($\Delta = +0.058$); second, proactive $70\% / 40\% / 20\%$ demand management prevents premature tank outlet pipe closure, increasing total delivered water volume by $+36.2\%$ ($1,843.1\text{ m}^3$ vs. $1,353.5\text{ m}^3$) and reducing cumulative unmet demand by $-8.8\%$ ($5,979.7\text{ m}^3$ vs. $6,469.3\text{ m}^3$); and third, multi-factor sensitivity analysis reveals that EWM yields substantial net gains for source outages exceeding $18\text{ h}$ and in systems with constrained storage, whereas short outages ($< 12\text{ h}$) require minimal curtailment to avoid unnecessary service restriction.

### 5.3 Actionable Operational Recommendations for Water Utilities

Based on our quantitative findings, three actionable operational recommendations are proposed for municipal water utilities: first, water utilities should embed automated, threshold-triggered demand management protocols directly into existing SCADA/PLC control architectures rather than relying solely on passive alarm systems; second, municipalities should establish Standard Operating Procedures (SOPs) that categorize urban water demand into critical (e.g., hospitals, fire protection) and non-essential (e.g., irrigation, industrial washing) tiers, enabling automated AMI-driven load shedding during severe source disruptions; and third, utility engineers should calibrate water level risk thresholds based on system-specific reaction time windows and active storage volume, ensuring that emergency demand management is triggered before tank levels reach critical outlet submergence limits.

---

## References

1. Alexandra, C, Daniell, K A, Guillaume, J, Saraswat, C, Feldman, H R (2023). Cyber-physical systems in water management and governance. Current Opinion in Environmental Sustainability, 62, 101290.

2. Ande, R, Adebisi, B, Hammoudeh, M, Saleem, J (2020). Internet of Things: Evolution and technologies from a security perspective. Sustainable Cities and Society, 54, 101728.

3. Arghandeh, R, Von Meier, A, Mehrmanesh, L, Mili, L (2016). On the definition of cyber-physical resilience in power systems. Renewable and Sustainable Energy Reviews, 58, 1060-1069.

4. Argyroudis, S A, Mitoulis, S A, Chatzi, E, Baker, J W, Brilakis, I, Gkoumas, K, Linkov, I (2022). Digital technologies can enhance climate resilience of critical infrastructure. Climate Risk Management, 35, 100387.

5. Bhardwaj, A, Gupta, A, Khatri, S K (2021). Cyber-physical system security in smart water networks: A review. IEEE Transactions on Industrial Informatics, 17(10): 7125-7136.

6. Boltz, F, Poff, N L, Folke, C, Kete, N, Brown, C M, Freeman, S S G, Rockstrom, J (2019). Water is a master variable: Solving for resilience in the modern era. Water Security, 8, 100048.

7. Cai, B, Zhang, Y, Wang, H, Liu, Y, Ji, R, Gao, C, Liu, J (2021). Resilience evaluation methodology of engineering systems with dynamic-Bayesian-network-based degradation and maintenance. Reliability Engineering & System Safety, 209, 107464.

8. Casal-Campos, A, Sadr, S M, Fu, G, Butler, D (2018). Reliable, resilient and sustainable urban drainage systems: An analysis of robustness under deep uncertainty. Environmental Science & Technology, 52(16): 9008-9021.

9. Chen, B, Li, H, Sun, G (2025). Seismic resilience assessment method and multi-objective optimal recovery strategy for large-scale urban water distribution network system. International Journal of Disaster Risk Reduction, 127, 105689.

10. Chen, Z, Zhang, S, Dui, H (2025). Importance-based risk evaluation methodology in transportation cyber-physical systems. Frontiers of Engineering Management, 12(2): 291-304.

11. Creaco, E, Franchini, M, Walski, T (2016). Accounting for pressure-driven demand in water distribution network optimization. Journal of Water Resources Planning and Management, 142(9): 04016030.

12. Cui, Z, Guo, W, Zhang, T (2022). Superposition control of extreme water levels in surge tanks of pumped storage power station with two turbines under combined operating conditions. Journal of Energy Storage, 56, 105894.

13. Garcia-Perez, A, Cegarra-Navarro, J G, Sallos, M P, Martinez-Caro, E, Chinnaswamy, A (2023). Resilience in healthcare systems: Cyber security and digital transformation. Technovation, 121, 102583.

14. Hassanzadeh, A, Rasekh, A, Galelli, S, Aez, M, Taormina, R, Ostfeld, A, Banks, M K (2020). A review of cybersecurity incidents in the water sector. Journal of Environmental Engineering, 146(5): 03120003.

15. He, S, Zhou, Y, Yang, Y, Liu, T, Zhou, Y, Li, J, Guan, X (2024). Cascading failure in cyber-physical systems: A review on failure modeling and vulnerability analysis. IEEE Transactions on Cybernetics, 54(12): 7936-7954.

16. He, Z, Huang, H, Choi, H, Bilgihan, A (2023). Building organizational resilience with digital transformation. Journal of Service Management, 34(1): 147-171.

17. Holling, C S (1973). Resilience and stability of ecological systems. Annual Review of Ecology and Systematics, 4(1): 1-23.

18. Hosseini, S, Barker, K, Ramirez-Marquez, J E (2016). A review of definitions and measures of system resilience. Reliability Engineering & System Safety, 145, 47-61.

19. Hou, B, Huang, J, Miao, H, Zhao, X, Wu, S (2023). Seismic resilience evaluation of water distribution systems considering hydraulic and water quality performance. International Journal of Disaster Risk Reduction, 93, 103756.

20. Jiang, L, Hu, Y, Li, H, Shao, X, Zhang, X, Kan, Q, Kang, G (2025). A cGAN-based fatigue life prediction of 316 austenitic stainless steel in high-temperature and high-pressure water environments. International Journal of Fatigue, 190, 108633.

21. Juan-Garcia, P, Butler, D, Comas, J, Darch, G, Sweetapple, C, Thornton, A, Corominas, L (2017). Resilience theory incorporated into urban wastewater systems management: State of the art. Water Research, 115, 149-161.

22. Khan, R, Zakarya, M, Balasubramanian, V, Jan, M A, Menon, V G (2020). Smart sensing-enabled decision support system for water scheduling in orange orchard. IEEE Sensors Journal, 21(16): 17492-17499.

23. Khattak, Z H (2024). Cybersecurity vulnerability and resilience of cooperative driving automation for energy efficiency and flow stability in smart cities. Sustainable Cities and Society, 106, 105368.

24. Liao, C, Chen, X, Gao, Z (2025). Toward smart charging, synergistic infrastructure and storable grid for coordinated power and transportation systems. Frontiers of Engineering Management, 12(3): 704-709.

25. Liserra, T, Maglionico, M, Ciriello, V, Di Federico, V (2014). Evaluation of reliability indicators for WDNs with demand-driven and pressure-driven models. Water Resources Management, 28(5): 1201-1217.

26. Liu, D (2019). Evaluating the dynamic resilience process of a regional water resource system through the nexus approach and resilience routing analysis. Journal of Hydrology, 578, 124028.

27. Liu, L, Mijic, A (2025). Performance-based resilience assessment in integrated water systems: Challenges and opportunities. Journal of Hydrology, 630, 134042.

28. Liu, L, Zhou, X, Duenas-Osorio, L, Stadler, L, Li, Q (2023). Hybrid wastewater treatment and reuse enhances urban water system resilience to disruptive incidents. Nature Water, 1(12): 1048-1058.

29. Liu, W, Song, Z, Ouyang, M, Li, J (2020). Recovery-based seismic resilience enhancement strategies of water distribution networks. Reliability Engineering & System Safety, 203, 107088.

30. Liu, Z, Xu, W, Wang, Y (2023). Resilience assessment and enhancement of urban water supply systems under critical component failures. Frontiers of Engineering Management, 10(2): 245-258.

31. Madiziyire, S, Stagner, J, Carriveau, R, Biswas, N, Johnson, K, Fisk, A (2025). Evaluation of response measures for water cutoffs using pressure driven analysis simulations. Water Research, 268, 124737.

32. Meng, F, Fu, G, Farmani, R, Sweetapple, C, Butler, D (2018). Topological ranking of water distribution networks for resilience assessment. Water Research, 129, 316-328.

33. Mignot, E, Dewals, B (2022). Hydraulic modelling of inland urban flooding: Recent advances. Journal of Hydrology, 609, 127763.

34. Ministry of Housing and Urban-Rural Development of China (MOHURD) (2018). Standard for Outdoor Water Supply Engineering (GB 50013-2018). China Architecture & Building Press, Beijing, China.

35. Mohebbi, S, Zhang, Q, Wells, E C, Zhao, T, Nguyen, H, Li, M, Ou, X (2020). Cyber-physical-social interdependencies and organizational resilience: A review of water, transportation, and cyber infrastructure systems and processes. Sustainable Cities and Society, 62, 102327.

36. Moreno-Sader, K, Jain, P, Tenorio, L C B, Mannan, M S, El-Halwagi, M M (2019). Integrated approach of safety, sustainability, reliability, and resilience analysis via a return on investment metric. ACS Sustainable Chemistry & Engineering, 7(24): 19522-19536.

37. Ostfeld, A, Salomons, E (2004). Optimal layout of water distribution networks security sensors. Journal of Water Resources Planning and Management, 130(5): 377-385.

38. Roach, T, Kapelan, Z (2017). Infrastructure resilience assessment using pressure-dependent hydraulic modeling of water distribution networks. Water Resources Management, 31(11): 3505-3519.

39. Roach, T, Kapelan, Z, Ledbetter, R (2018). Resilience-based performance metrics for water resources management under uncertainty. Advances in Water Resources, 116, 18-28.

40. Sadien, M, Doorga, J R, Rughooputh, S D (2024). Assessment of tangible coastal inundation damage related to critical infrastructure and buildings: The case of Mauritius Island. International Journal of Disaster Risk Reduction, 114, 104909.

41. Savic, D A, Banyard, J K (Eds) (2024). Water Supply and Distribution Systems. Emerald Group Publishing, Leeds, UK.

42. Sitzenfrei, R (2021). Using complex network analysis for water quality assessment in large water distribution systems. Water Research, 201, 117359.

43. Sun, H, Yang, M, Wang, H (2022). Resilience-based approach to maintenance asset and operational cost planning. Process Safety and Environmental Protection, 162, 987-997.

44. Taiwo, R, Ben Seghier, M E A, Zayed, T (2023). Toward sustainable water infrastructure: The state-of-the-art for modeling the failure probability of water pipes. Water Resources Research, 59(4), e2022WR033256.

45. Taormina, R, Galelli, S, Tippenhauer, N O, Salomons, E, Ostfeld, A, Eliades, D G, Ohar, Z (2018). Battle of the attack detection algorithms: Disclosing cyber attacks on water distribution networks. Journal of Water Resources Planning and Management, 144(8): 04018048.

46. Walski, T M, Brill, E D, Gessler, J, Goulter, I C, Jeppson, R M, Lansey, K, Ormsbee, L (1987). Battle of the network models: Epilogue. Journal of Water Resources Planning and Management, 113(2): 191-203.

47. Walski, T M, Chase, D V, Savic, D A, Grayman, W, Beckwith, S, Koelle, E (2003). Advanced Water Distribution Modeling and Management. Haestad Methods, Waterbury, CT, USA.

48. Wang, B, Shen, C (2023). A time-varying observer-based approach to equilibrium estimation and compensation for synchronization of heterogeneous nonlinear cyber-physical systems. IEEE Transactions on Automatic Control, 68(10): 6176-6183.

49. Wardropper, C, Brookfield, A (2022). Decision-support systems for water management. Journal of Hydrology, 610, 127928.

50. World Health Organization (WHO) (2022). Guidelines for Drinking-Water Quality: Fourth Edition Incorporating the First and Second Addenda. World Health Organization, Geneva, Switzerland.

51. Wu, G, Li, Z S (2021). Cyber-Physical Power System (CPPS): A review on measures and optimization methods of system resilience. Frontiers of Engineering Management, 8(4): 503-518.

52. Xu, W, Zhou, X, Xin, K, Boxall, J, Yan, H, Tao, T (2020). Disturbance extraction for burst detection in water distribution networks using pressure measurements. Water Resources Research, 56(5), e2019WR025526.

53. Yadav, G, Paul, K (2021). Architecture and security of SCADA systems: A review. International Journal of Critical Infrastructure Protection, 34, 100433.

54. Zhang, C, Chen, R, Wang, S, Dui, H, Zhang, Y (2022). Resilience efficiency importance measure for the selection of a component maintenance strategy to improve system performance recovery. Reliability Engineering & System Safety, 217, 108070.

55. Zhang, J, Qiu, W, Wang, Q, Yao, T, Hu, C, Liu, Y (2024). Extreme water level of surge chamber in hydropower plant under combined operating conditions. Chaos, Solitons & Fractals, 178, 114362.

56. Zhang, Y, Yin, H, Liu, M, Kong, F, Xu, J (2025). Evaluating the effectiveness of environmental sustainability indicators in optimizing green-grey infrastructure for sustainable stormwater management. Water Research, 272, 122932.

57. Zou, X Y, Peng, X Y, Zhao, X X, Chang, C P (2023). The impact of extreme weather events on water quality: International evidence. Natural Hazards, 115(1): 1-21.
