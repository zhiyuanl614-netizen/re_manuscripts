## References

1. Alexandra, C, Daniell, K A, Guillaume, J, Saraswat, C, Feldman, H R (2023). Cyber-physical systems in water management and governance. Current Opinion in Environmental Sustainability, 62, 101290.

2. Ande, R, Adebisi, B, Hammoudeh, M, Saleem, J (2020). Internet of Things: Evolution and technologies from a security perspective. Sustainable Cities and Society, 54, 101728.

3. Arghandeh, R, Von Meier, A, Mehrmanesh, L, Mili, L (2016). On the definition of cyber-physical resilience in power systems. Renewable and Sustainable Energy Reviews, 58, 1060-1069.

4. Argyroudis, S A, Mitoulis, S A, Chatzi, E, Baker, J W, Brilakis, I, Gkoumas, K, Linkov, I (2022). Digital technologies can enhance climate resilience of critical infrastructure. Climate Risk Management, 35, 100387.

5. Bhardwaj, A, Gupta, A, Khatri, S K (2021). Cyber-physical system security in smart water networks: A review. IEEE Transactions on Industrial Informatics, 17(10): 7125-7136.

6. Boltz, F, Poff, N L, Folke, C, Kete, N, Brown, C M, Freeman, S S G, Rockstrom, J (2019). Water is a master variable: Solving for resilience in the modern era. Water Security, 8, 100048.

7. Cai, B, Zhang, Y, Wang, H, Liu, Y, Ji, R, Gao, C, Liu, J (2021). Resilience evaluation methodology of engineering systems with dynamic-Bayesian-network-based degradation and maintenance. Reliability Engineering & System Safety, 209, 107464.

8. Casal-Campos, A, Sadr, S M, Fu, G, Butler, D (2018). Reliable, resilient and sustainable urban drainage systems: An analysis of robustness under deep uncertainty. Environmental Science & Technology, 52(16): 9008-9021.

9. Chen, B, Li, H, Sun, G (2025). Seismic resilience assessment method and multi-objective optimal recovery strategy for large-scale urban water distribution network system. International Journal of Disaster Risk Reduction, 127, 105689.

10. Chen, Z, Zhang, S, Dui, H (2025). Importance-based risk evaluation methodology in transportation cyber-physical systems. Frontiers of Engineering Management, 12(2): 291-304.

11. Creaco, E, Franchini, M, Walski, T (2016). Accounting for pressure-driven demand in water distribution network optimization. Journal of Water Resources Planning and Management, 142(9): 04016030.

12. Cui, Z, Guo, W, Zhang, T (2022). Superposition control of extreme water levels in surge tanks of pumped storage power station with two turbines under combined operating conditions. Journal of Energy Storage, 56, 105894.

13. Garcia-Perez, A, Cegarra-Navarro, J G, Sallos, M P, Martinez-Caro, E, Chinnaswamy, A (2023). Resilience in healthcare systems: Cyber security and digital transformation. Technovation, 121, 102583.

14. Hassanzadeh, A, Rasekh, A, Galelli, S, Aez, M, Taormina, R, Ostfeld, A, Banks, M K (2020). A review of cybersecurity incidents in the water sector. Journal of Environmental Engineering, 146(5): 03120003.

15. He, S, Zhou, Y, Yang, Y, Liu, T, Zhou, Y, Li, J, Guan, X (2024). Cascading failure in cyber-physical systems: A review on failure modeling and vulnerability analysis. IEEE Transactions on Cybernetics, 54(12): 7936-7954.

16. He, Z, Huang, H, Choi, H, Bilgihan, A (2023). Building organizational resilience with digital transformation. Journal of Service Management, 34(1): 147-171.

17. Holling, C S (1973). Resilience and stability of ecological systems. Annual Review of Ecology and Systematics, 4(1): 1-23.

18. Hosseini, S, Barker, K, Ramirez-Marquez, J E (2016). A review of definitions and measures of system resilience. Reliability Engineering & System Safety, 145, 47-61.

19. Hou, B, Huang, J, Miao, H, Zhao, X, Wu, S (2023). Seismic resilience evaluation of water distribution systems considering hydraulic and water quality performance. International Journal of Disaster Risk Reduction, 93, 103756.

20. Jiang, L, Hu, Y, Li, H, Shao, X, Zhang, X, Kan, Q, Kang, G (2025). A cGAN-based fatigue life prediction of 316 austenitic stainless steel in high-temperature and high-pressure water environments. International Journal of Fatigue, 190, 108633.

21. Juan-Garcia, P, Butler, D, Comas, J, Darch, G, Sweetapple, C, Thornton, A, Corominas, L (2017). Resilience theory incorporated into urban wastewater systems management: State of the art. Water Research, 115, 149-161.

22. Khan, R, Zakarya, M, Balasubramanian, V, Jan, M A, Menon, V G (2020). Smart sensing-enabled decision support system for water scheduling in orange orchard. IEEE Sensors Journal, 21(16): 17492-17499.

23. Khattak, Z H (2024). Cybersecurity vulnerability and resilience of cooperative driving automation for energy efficiency and flow stability in smart cities. Sustainable Cities and Society, 106, 105368.

24. Liao, C, Chen, X, Gao, Z (2025). Toward smart charging, synergistic infrastructure and storable grid for coordinated power and transportation systems. Frontiers of Engineering Management, 12(3): 704-709.

25. Liserra, T, Maglionico, M, Ciriello, V, Di Federico, V (2014). Evaluation of reliability indicators for WDNs with demand-driven and pressure-driven models. Water Resources Management, 28(5): 1201-1217.

26. Liu, D (2019). Evaluating the dynamic resilience process of a regional water resource system through the nexus approach and resilience routing analysis. Journal of Hydrology, 578, 124028.

27. Liu, L, Mijic, A (2025). Performance-based resilience assessment in integrated water systems: Challenges and opportunities. Journal of Hydrology, 630, 134042.

28. Liu, L, Zhou, X, Duenas-Osorio, L, Stadler, L, Li, Q (2023). Hybrid wastewater treatment and reuse enhances urban water system resilience to disruptive incidents. Nature Water, 1(12): 1048-1058.

29. Liu, W, Song, Z, Ouyang, M, Li, J (2020). Recovery-based seismic resilience enhancement strategies of water distribution networks. Reliability Engineering & System Safety, 203, 107088.

30. Liu, Z, Xu, W, Wang, Y (2023). Resilience assessment and enhancement of urban water supply systems under critical component failures. Frontiers of Engineering Management, 10(2): 245-258.

31. Madiziyire, S, Stagner, J, Carriveau, R, Biswas, N, Johnson, K, Fisk, A (2025). Evaluation of response measures for water cutoffs using pressure driven analysis simulations. Water Research, 268, 124737.

32. Meng, F, Fu, G, Farmani, R, Sweetapple, C, Butler, D (2018). Topological ranking of water distribution networks for resilience assessment. Water Research, 129, 316-328.

33. Mignot, E, Dewals, B (2022). Hydraulic modelling of inland urban flooding: Recent advances. Journal of Hydrology, 609, 127763.

34. Ministry of Housing and Urban-Rural Development of China (MOHURD) (2018). Standard for Outdoor Water Supply Engineering (GB 50013-2018). China Architecture & Building Press, Beijing, China.

35. Mohebbi, S, Zhang, Q, Wells, E C, Zhao, T, Nguyen, H, Li, M, Ou, X (2020). Cyber-physical-social interdependencies and organizational resilience: A review of water, transportation, and cyber infrastructure systems and processes. Sustainable Cities and Society, 62, 102327.

36. Moreno-Sader, K, Jain, P, Tenorio, L C B, Mannan, M S, El-Halwagi, M M (2019). Integrated approach of safety, sustainability, reliability, and resilience analysis via a return on investment metric. ACS Sustainable Chemistry & Engineering, 7(24): 19522-19536.

37. Ostfeld, A, Salomons, E (2004). Optimal layout of water distribution networks security sensors. Journal of Water Resources Planning and Management, 130(5): 377-385.

38. Roach, T, Kapelan, Z (2017). Infrastructure resilience assessment using pressure-dependent hydraulic modeling of water distribution networks. Water Resources Management, 31(11): 3505-3519.

39. Roach, T, Kapelan, Z, Ledbetter, R (2018). Resilience-based performance metrics for water resources management under uncertainty. Advances in Water Resources, 116, 18-28.

40. Sadien, M, Doorga, J R, Rughooputh, S D (2024). Assessment of tangible coastal inundation damage related to critical infrastructure and buildings: The case of Mauritius Island. International Journal of Disaster Risk Reduction, 114, 104909.

41. Savic, D A, Banyard, J K (Eds) (2024). Water Supply and Distribution Systems. Emerald Group Publishing, Leeds, UK.

42. Sitzenfrei, R (2021). Using complex network analysis for water quality assessment in large water distribution systems. Water Research, 201, 117359.

43. Sun, H, Yang, M, Wang, H (2022). Resilience-based approach to maintenance asset and operational cost planning. Process Safety and Environmental Protection, 162, 987-997.

44. Taiwo, R, Ben Seghier, M E A, Zayed, T (2023). Toward sustainable water infrastructure: The state-of-the-art for modeling the failure probability of water pipes. Water Resources Research, 59(4), e2022WR033256.

45. Taormina, R, Galelli, S, Tippenhauer, N O, Salomons, E, Ostfeld, A, Eliades, D G, Ohar, Z (2018). Battle of the attack detection algorithms: Disclosing cyber attacks on water distribution networks. Journal of Water Resources Planning and Management, 144(8): 04018048.

46. Walski, T M, Brill, E D, Gessler, J, Goulter, I C, Jeppson, R M, Lansey, K, Ormsbee, L (1987). Battle of the network models: Epilogue. Journal of Water Resources Planning and Management, 113(2): 191-203.

47. Walski, T M, Chase, D V, Savic, D A, Grayman, W, Beckwith, S, Koelle, E (2003). Advanced Water Distribution Modeling and Management. Haestad Methods, Waterbury, CT, USA.

48. Wang, B, Shen, C (2023). A time-varying observer-based approach to equilibrium estimation and compensation for synchronization of heterogeneous nonlinear cyber-physical systems. IEEE Transactions on Automatic Control, 68(10): 6176-6183.

49. Wardropper, C, Brookfield, A (2022). Decision-support systems for water management. Journal of Hydrology, 610, 127928.

50. World Health Organization (WHO) (2022). Guidelines for Drinking-Water Quality: Fourth Edition Incorporating the First and Second Addenda. World Health Organization, Geneva, Switzerland.

51. Wu, G, Li, Z S (2021). Cyber-Physical Power System (CPPS): A review on measures and optimization methods of system resilience. Frontiers of Engineering Management, 8(4): 503-518.

52. Xu, W, Zhou, X, Xin, K, Boxall, J, Yan, H, Tao, T (2020). Disturbance extraction for burst detection in water distribution networks using pressure measurements. Water Resources Research, 56(5), e2019WR025526.

53. Yadav, G, Paul, K (2021). Architecture and security of SCADA systems: A review. International Journal of Critical Infrastructure Protection, 34, 100433.

54. Zhang, C, Chen, R, Wang, S, Dui, H, Zhang, Y (2022). Resilience efficiency importance measure for the selection of a component maintenance strategy to improve system performance recovery. Reliability Engineering & System Safety, 217, 108070.

55. Zhang, J, Qiu, W, Wang, Q, Yao, T, Hu, C, Liu, Y (2024). Extreme water level of surge chamber in hydropower plant under combined operating conditions. Chaos, Solitons & Fractals, 178, 114362.

56. Zhang, Y, Yin, H, Liu, M, Kong, F, Xu, J (2025). Evaluating the effectiveness of environmental sustainability indicators in optimizing green-grey infrastructure for sustainable stormwater management. Water Research, 272, 122932.

57. Zou, X Y, Peng, X Y, Zhao, X X, Chang, C P (2023). The impact of extreme weather events on water quality: International evidence. Natural Hazards, 115(1): 1-21.
