## 2. Methodology

### 2.1 Benchmark Water Distribution Network and Co-Simulation Platform

The proposed Cyber-Physical System (CPS) co-simulation and resilience evaluation framework is demonstrated on the benchmark Anytown urban water distribution network (Walski et al., 1987). As illustrated in **Fig. 1**, the physical network topology comprises 19 demand junction nodes, 34 distribution pipelines, 2 elevated storage tanks ($T1$ and $T2$), a primary water reservoir $R1$, and a main pumping station equipped with two identical parallel pumps ($P1$ and $P2$). Water is drawn from reservoir $R1$ and pumped through main transmission mains into the distribution grid. Elevated storage tanks $T1$ and $T2$ are positioned at opposite ends of the network to balance peak demand and maintain distribution pressure. Both tanks share symmetrical physical specifications, with a base elevation of $66.54\text{ m}$, a cylindrical tank diameter of $9.95\text{ m}$, a maximum operating depth of $10.67\text{ m}$, and an initial pre-fault water level of $3.051\text{ m}$. SCADA water level sensors are installed at both $T1$ and $T2$ to provide real-time storage telemetry, while SCADA pressure and flow sensors monitor junction heads and pump operating statuses across the network.

![Fig. 1 Topology and SCADA sensor/actuator configuration](figures/Fig1.png)  
**Fig. 1. Topology and SCADA sensor/actuator configuration of the benchmark Anytown water distribution network, showing junction nodes, pipelines, reservoir R1, parallel pumps P1/P2, tanks T1/T2, and SCADA telemetry points.**

The co-simulation engine couples the EPANET 2.2 Pressure-Driven Analysis (PDA) solver with Python-based SCADA control logic wrapped within the Water Network Tool for Resilience (WNTR) framework. As depicted in the co-simulation workflow diagram in **Fig. 2**, the simulation operates across a five-stage closed loop during each 300-s ($5\text{-min}$) timestep over a 72-h continuous horizon: first, the EPANET 2.2 PDA engine solves non-linear hydraulic equations to compute junction pressure heads, pipe flows, and tank storage levels; second, high-frequency SCADA sensors poll current tank water levels $H_{\text{tank}}(t)$ and pump operational statuses $S_{\text{pump}}(t)$, logging state variables into a central SQLite relational database; third, the cyber observer logic continuously compares $H_{\text{tank}}(t)$ against pre-set operational risk thresholds ($5.0\text{ m}, 4.0\text{ m}, 2.0\text{ m}, 0.50\text{ m}$) during an active water source outage; fourth, upon detecting threshold crossings, the cyber controller enforces a monotonic ratchet rule ($\gamma_t \le \gamma_{t-1}$) to prevent control chattering and transmits updated demand curtailment multipliers ($\gamma \in \{1.00, 0.70, 0.40, 0.20\}$) to network nodes; and fifth, automated AMI smart meters and pressure-reducing valves throttle nodal demand accordingly for the subsequent simulation timestep.

![Fig. 2 Integrated WNTR/EPANET 2.2 co-simulation workflow](figures/Fig3.png)  
**Fig. 2. Integrated WNTR/EPANET 2.2 co-simulation workflow and SCADA control loop, detailing the five-stage interaction between EPANET 2.2 PDA execution, SQLite SCADA logging, EWM observer evaluation, ratchet control enforcement, and actuator execution.**

### 2.2 Idealized Modeling Assumptions and Scope Boundaries

To establish a rigorous baseline for quantifying proactive cyber-physical resilience, the co-simulation model incorporates several idealized assumptions regarding cyber communication, control execution, and hydraulic behavior. Table 1 explicitly delineates these assumptions, assesses their potential impacts on practical engineering implementations, and outlines corresponding engineering mitigation measures.

**Table 1: Explicit declaration of modeling assumptions, engineering impacts, and mitigation measures**

| Assumption Domain | Idealized Assumption | Potential Impact on Engineering Practice | Practical Engineering Mitigation Measure |
| :--- | :--- | :--- | :--- |
| **Cyber Sensing** | Sensors provide continuous, error-free SCADA telemetry of tank levels and pump states. | Measurement noise or sensor drift could cause premature or delayed EWM triggering. | Implement local Kalman filtering and dual-redundant sensor polling at tank sites. |
| **Communication Network** | Zero transmission latency, zero packet loss, and infinite bandwidth between SCADA and PLCs. | Network congestion or signal packet loss may delay demand reduction commands by seconds to minutes. | Deploy edge-computing PLCs capable of autonomous threshold evaluation during network outages. |
| **Control Execution** | Nodal demand curtailment is executed instantaneously and uniformly across all customer nodes. | Physical valve throttling at customer service connections requires finite mechanical actuation time. | Implement automated AMI-enabled smart meters and pressure-reducing valves (PRVs) with pre-set emergency routines. |
| **Hydraulic Water Quality** | Water quality (e.g., chlorine residual, age) is assumed non-degrading during emergency supply. | Low-flow velocity during severe demand curtailment may increase water age and stagnation. | Limit CRITICAL state duration and enforce post-event pipe flushing protocols. |
| **Disturbance Scenario** | Water source outage is modeled as a deterministic, step-function total pump shutdown ($24\text{--}48\text{ h}$). | Real-world power outages or pipe bursts may exhibit partial or cascading failure dynamics. | Conduct multi-factor sensitivity analysis across varying outage durations ($12\text{--}48\text{ h}$). |

### 2.3 Cyber-Physical Early Warning Mechanism (EWM) and Graded Demand Management

Rather than functioning merely as a passive status logger or alarm monitor, the Cyber-Physical Early Warning Mechanism (EWM) operationalizes early risk detection into concrete, closed-loop emergency hydraulic interventions. As illustrated in the three-layer CPS architecture in **Fig. 3**, the system integrates three tightly coupled layers: the Cyber Sensing Layer, where SCADA sensors poll tank water levels $H_{\text{tank}}(t)$ and pump operational statuses $S_{\text{pump}}(t)$ at $300\text{-s}$ intervals, transmitting telemetry signals through a gateway interface to the cyber control layer; the Cyber Control Layer, where upon receiving confirmation of a water source outage (pump shutdown $S_{\text{pump}} = 0$ at $t = 24\text{ h}$), the cyber controller evaluates current tank levels against pre-established operational risk thresholds ($5.0\text{ m}, 4.0\text{ m}, 2.0\text{ m}, 0.50\text{ m}$), enforcing a monotonic ratchet constraint ($\gamma_t \le \gamma_{t-1}$) to prevent control chattering and issuing state-dependent demand reduction multipliers ($\gamma \in \{1.00, 0.70, 0.40, 0.20\}$); and the Physical Hydraulic Layer, where demand reduction commands are executed at distribution junctions, throttling consumer outflow, slowing tank volumetric drainage ($d H_{\text{tank}} / dt = (Q_{\text{in}} - Q_{\text{out}}) / A_{\text{tank}}$), keeping tank outlet pipes submerged above $0.50\text{ m}$, and maintaining pipeline pressure above the $0.10\text{ MPa}$ ($\approx 10\text{ m}$) emergency threshold.

$$\text{Demand}(j, t) = \gamma(t) \cdot \text{BaseDemand}(j) \cdot \text{Pattern}(t)$$

![Fig. 3 Three-layer Cyber-Physical System architecture](figures/Fig2.png)  
**Fig. 3. Three-layer Cyber-Physical System (CPS) architecture illustrating closed-loop interaction among Sensing Layer (SCADA telemetry polling), Control Layer (EWM risk observer, ratchet rule enforcement, demand multiplier selection), and Physical Hydraulic Layer (junction demand throttling, tank level preservation, pipeline head maintenance).**

**Table 2: Operational trigger logic and demand management actions of EWM**

| Risk State | Tank Level Threshold ($H_{\text{tank}}$) | Pump Status ($S_{\text{pump}}$) | Demand Multiplier ($\gamma$) | Operational Action & Hydraulic Effect |
| :--- | :--- | :---: | :---: | :--- |
| **NORMAL** | $H_{\text{tank}} \ge 5.0\text{ m}$ | Operational ($S=1$) | $1.00$ | Standard supply; 100% nominal demand delivered. |
| **WARNING** | $H_{\text{tank}} < 5.0\text{ m}$ | Outage ($S=0$) | $0.70$ | Level 1 curtailment; 30% non-essential demand shed; slows initial storage drawdown. |
| **ALERT** | $H_{\text{tank}} < 4.0\text{ m}$ | Outage ($S=0$) | $0.40$ | Level 2 curtailment; 60% demand shed; preserves pressure above critical supply head ($0.10\text{ MPa}$). |
| **CRITICAL** | $H_{\text{tank}} < 2.0\text{ m}$ | Outage ($S=0$) | $0.20$ | Level 3 curtailment; 80% demand shed; maintains minimum emergency head and prevents tank dry-out. |
| **OUTLET FAILURE** | $H_{\text{tank}} < 0.50\text{ m}$ | Outage ($S=0$) | $0.00$ | Physical pipe closure; outlet valve shuts to prevent cavitation and air entrainment. |

The rationale for setting these specific water level risk thresholds ($5.0\text{ m}, 4.0\text{ m}, 2.0\text{ m}, 0.50\text{ m}$) integrates physical, operational, and regulatory constraints. First, the Outlet Failure threshold ($0.50\text{ m}$) is dictated by the physical crown elevation of tank outlet pipes, below which vortexing, air entrainment, and pump cavitation occur, requiring immediate isolation (Zhang et al., 2024). Second, the Normal threshold ($5.0\text{ m}$) aligns strictly with the baseline SCADA pump start setpoint ($H \le 5.0\text{ m}$ start, $H \ge 8.0\text{ m}$ stop), establishing operational self-consistency across routine and emergency modes. Third, the intermediate Warning ($5.0\text{ m}$), Alert ($4.0\text{ m}$), and Critical ($2.0\text{ m}$) thresholds evenly divide the active storage depth, providing progressive reaction time windows ($\sim 1.0\text{--}3.5\text{ h}$) that allow the network to step down demand in a controlled manner, ensuring that system pressure remains above the $0.10\text{ MPa}$ ($\approx 10\text{ m}$) minimum service head required by national engineering standards (MOHURD, 2018).

### 2.4 Experimental Control and Fairness of Comparison

To guarantee complete experimental rigor and eliminate potential bias in resilience quantification, the 'Without EWM' (baseline) and 'With EWM' (intervened) simulation scenarios are executed on an identical hydraulic modeling baseline. Both cases are evaluated using the EPANET 2.2 Pressure-Driven Analysis (PDA) solver wrapped within the WNTR Python framework. Both scenarios share identical network topology, pipe roughness, node elevations, initial tank levels ($3.051\text{ m}$), hydraulic step sizes ($\Delta t = 300\text{ s}$), and physical tank outlet protection thresholds ($H_{\text{outlet}} = 0.50\text{ m}$).

The abrupt pressure drop observed in the baseline case is not an assumed binary failure rule, but rather the deterministic hydraulic outcome of uncurtailed 100% demand under total source interruption: high outflow drains the tank storage within $\sim 6\text{ h}$, causing water level to drop below $0.50\text{ m}$, which forces the physical closure of tank outlet pipes to prevent pump/pipe cavitation. The single controlled experimental variable between the two scenarios is the activation of early-warning-triggered demand management. Table 3 lists the side-by-side experimental control matrix.

**Table 3: Comparative experimental control matrix between Without EWM and With EWM scenarios**

| Simulation Parameter / Rule | Baseline Scenario (Without EWM) | Proposed Scenario (With EWM) | Experimental Control Status |
| :--- | :--- | :--- | :--- |
| **Hydraulic Solver Engine** | WNTR / EPANET 2.2 (PDA) | WNTR / EPANET 2.2 (PDA) | **Identical** |
| **Simulation Horizon / Step** | $72\text{ h}$ total / $\Delta t = 300\text{ s}$ | $72\text{ h}$ total / $\Delta t = 300\text{ s}$ | **Identical** |
| **Disruption Scenario** | Total pump outage ($t=24\text{--}48\text{ h}$) | Total pump outage ($t=24\text{--}48\text{ h}$) | **Identical** |
| **Tank Outlet Closure Rule** | Closed when $H_{\text{tank}} < 0.50\text{ m}$ | Closed when $H_{\text{tank}} < 0.50\text{ m}$ | **Identical** |
| **Baseline System Head ($P_0$)** | $55.23\text{ m}$ ($0.541\text{ MPa}$) | $55.23\text{ m}$ ($0.541\text{ MPa}$) | **Identical** |
| **Demand Management Multiplier** | Constant $\gamma = 1.00$ (No intervention) | Dynamic $\gamma \in \{1.00, 0.70, 0.40, 0.20\}$ | **Single Controlled Variable** |

### 2.5 Dual Resilience Metrics and Volumetric Accounting Formulation

To distinguish between pipeline pressure maintenance and actual water service delivery, a dual-metric resilience evaluation framework is established. The actual delivered nodal flow $Q_{\text{del}, j}(t)$ is governed by EPANET Pressure-Driven Analysis (PDA):

$$Q_{\text{del}, j}(t) = \begin{cases} Q_{\text{req}, j}(t), & \text{if } H_j(t) \ge H_{\text{req}} \\ Q_{\text{req}, j}(t) \cdot \left(\frac{H_j(t) - H_{\text{min}}}{H_{\text{req}} - H_{\text{min}}}\right)^{\alpha}, & \text{if } H_{\text{min}} < H_j(t) < H_{\text{req}} \\ 0, & \text{if } H_j(t) \le H_{\text{min}} \end{cases}$$

1. **Pressure Resilience Index ($RI_{\text{pressure}}$)**: Evaluates physical hydraulic head preservation relative to baseline pressure $P_0$:

$$RI_{\text{pressure}} = \frac{1}{T_{\text{fault}}} \int_{t_{\text{start}}}^{t_{\text{end}}} \frac{\bar{P}(t)}{P_0} \, dt$$

2. **Service Resilience Index ($RI_{\text{service}}$)**: Evaluates water service continuity based on the Demand Satisfaction Ratio ($DSR(t)$):

$$DSR(t) = \frac{\sum Q_{\text{del}, j}(t)}{\sum Q_{\text{nom}, j}(t)}, \quad RI_{\text{service}} = \frac{1}{T_{\text{fault}}} \int_{t_{\text{start}}}^{t_{\text{end}}} DSR(t) \, dt$$

3. **Cumulative Unmet Demand ($V_{\text{unmet}}$)**: Quantifies total water supply deficit ($m^3$):

$$V_{\text{unmet}} = \int_{t_{\text{start}}}^{t_{\text{end}}} \left( \sum Q_{\text{nom}, j}(t) - \sum Q_{\text{del}, j}(t) \right) \, dt$$
