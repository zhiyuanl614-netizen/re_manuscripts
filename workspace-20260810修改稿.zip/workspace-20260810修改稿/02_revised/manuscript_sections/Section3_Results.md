## 3. Results

### 3.1 Tank Water Level Dynamics and Risk State Transitions

The water storage tank level drawdown trajectories and EWM risk state transitions for Tanks T1 and T2 under Without EWM and With EWM scenarios are visually demonstrated in **Fig. 4**. Under the uncurtailed baseline scenario, high uncurtailed consumer demand ($100\%$ load) causes rapid, steep water level drawdown in both Tank T1 (**Fig. 4(a)**, left upper panel) and Tank T2 (**Fig. 4(b)**, right upper panel). Starting from an initial level of $3.051\text{ m}$, water levels in T1 and T2 drop rapidly across $2.50\text{ h}$ and $2.42\text{ h}$ respectively, breaching the $0.50\text{ m}$ Outlet Failure threshold at $t = 29.50\text{ h}$ (T1) and $t = 29.42\text{ h}$ (T2). This triggers automatic physical outlet valve closure to prevent air entrainment and pump cavitation, leaving both tanks completely isolated and drained for the remaining $18.50\text{ h}$ and $18.58\text{ h}$ of the $24\text{-h}$ source outage.

In stark contrast, under the proposed EWM scenario, the activation of graded demand curtailment significantly alters the drawdown trajectory. As water levels drop below the $5.0\text{ m}$ Warning threshold upon pump outage at $t = 24\text{ h}$, demand is immediately reduced to $70\%$ ($\gamma = 0.70$), flattening the initial drawdown slope. As storage drops further across the $4.0\text{ m}$ Alert threshold ($t = 25.0\text{ h}$) and $2.0\text{ m}$ Critical threshold ($t = 28.5\text{ h}$), demand is progressively stepped down to $40\%$ ($\gamma = 0.40$) and $20\%$ ($\gamma = 0.20$). As shown in the state progression bands in **Fig. 4(a)** and **Fig. 4(b)**, this progressive demand reduction extends the active water discharge duration of Tanks T1 and T2 from $5.46\text{ h}$ to $11.83\text{ h}$, delaying Outlet Failure until $t = 35.83\text{ h}$ and reducing the total Outlet Failure duration from $18.50\text{--}18.58\text{ h}$ down to $12.17\text{ h}$ for both tanks, representing an effective expansion of the operational reaction window by $6.33\text{ h}$. Table 4 summarizes the exact state duration values and Outlet Failure timings.

![Fig. 4 Water storage tank water level dynamics and early warning risk state transitions](figures/Fig4.png)  
**Fig. 4. Water storage tank water level dynamics and early warning risk state transitions under a 24-h water source outage ($t = 24\text{--}48\text{ h}$). Upper panels illustrate water level drawdown for Tank T1 (a, left) and Tank T2 (b, right) under Without EWM and With EWM scenarios. Lower state bands show the temporal progression of EWM risk states: NORMAL ($\ge 5.0\text{ m}$), WARNING ($< 5.0\text{ m}$), ALERT ($< 4.0\text{ m}$), CRITICAL ($< 2.0\text{ m}$), and OUTLET FAILURE ($< 0.50\text{ m}$). The EWM demand management delays Outlet Failure, expanding the operational reaction window by $6.33\text{ h}$.**

**Table 4: Tank state durations and Outlet Failure timings for Tanks T1 and T2**

| Scenario | Tank ID | Normal ($\ge 5.0\text{ m}$) | Warning ($< 5.0\text{ m}$) | Alert ($< 4.0\text{ m}$) | Critical ($< 2.0\text{ m}$) | Outlet Failure ($< 0.50\text{ m}$) | Total Outflow Duration |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Without EWM** | **T1** | $0.00\text{ h}$ | $0.00\text{ h}$ | $2.50\text{ h}$ | $3.00\text{ h}$ | $18.50\text{ h}$ | **$5.50\text{ h}$** |
| | **T2** | $0.00\text{ h}$ | $0.00\text{ h}$ | $2.42\text{ h}$ | $3.00\text{ h}$ | $18.58\text{ h}$ | **$5.42\text{ h}$** |
| **With EWM** | **T1** | $0.00\text{ h}$ | $1.00\text{ h}$ | $3.50\text{ h}$ | $7.33\text{ h}$ | $12.17\text{ h}$ | **$11.83\text{ h}$** |
| | **T2** | $0.00\text{ h}$ | $1.00\text{ h}$ | $3.50\text{ h}$ | $7.33\text{ h}$ | $12.17\text{ h}$ | **$11.83\text{ h}$** |

### 3.2 System Pressure Trajectories and Dual-Metric Volumetric Accounting

The network-wide average junction pressure $P_{\text{avg}}(t)$ and system performance trajectory over the $72\text{-h}$ simulation timeline are illustrated in **Fig. 5**. During the pre-fault phase ($0\text{--}24\text{ h}$), average system pressure remains stably elevated at $55.23\text{ m}$ ($0.541\text{ MPa}$). Upon pump shutdown at $t = 24\text{ h}$, the baseline curve without EWM exhibits a steep pressure drop as uncurtailed demand drains the tanks. At $t = 30.2\text{ h}$, complete tank dry-out triggers physical outlet pipe closure, causing network pressure to collapse abruptly to zero ($0.00\text{ MPa}$) and creating a complete zero-supply blackout for the remaining $17.8\text{ h}$ of the outage.

Conversely, the performance trajectory under EWM intervention in **Fig. 5** demonstrates the dynamic pressure stabilization achieved through proactive load control. As demand is progressively curtailed ($70\% \to 40\% \to 20\%$), line head loss decreases and storage depletion slows, maintaining $P_{\text{avg}}(t)$ consistently above the dashed horizontal line representing the critical $0.10\text{ MPa}$ ($\approx 10\text{ m}$) emergency service threshold throughout the entire $24\text{-h}$ outage ($24\text{--}48\text{ h}$). The shaded region between the intervened and baseline performance curves visually highlights the integrated system performance area preserved by EWM, raising the Pressure Resilience Index ($RI_{\text{pressure}}$) from $0.22$ to $0.84$ ($\Delta = +0.62$).

![Fig. 5 Network-wide average junction pressure and performance trajectory](figures/Fig5.png)  
**Fig. 5. Network-wide average junction pressure $P_{\text{avg}}(t)$ and system performance trajectory $P(t)$ during the 72-h simulation horizon under Without EWM and With EWM scenarios, showing pressure preservation above the critical service threshold ($0.10\text{ MPa} \approx 10\text{ m}$, dashed horizontal line) throughout the 24-h outage period.**

To resolve the potential distortion of evaluating resilience solely through pressure preservation, **Fig. 6** provides a side-by-side comparison of the dual resilience indices and the volumetric water accounting results over the disruption period ($V_{\text{req}} = 7,822.8\text{ m}^3$). In **Fig. 6(a)**, the bar chart compares $RI_{\text{pressure}}$ ($0.22$ vs. $0.84$) alongside $RI_{\text{service}}$ ($0.23$ vs. $0.29$). While $RI_{\text{pressure}}$ exhibits a massive $+0.62$ jump due to pipeline head preservation, $RI_{\text{service}}$ reflects the actual Demand Satisfaction Ratio ($DSR$), showing a modest but meaningful $+0.058$ improvement.

**Fig. 6(b)** details the volumetric water accounting bars, contrasting total delivered water volume $V_{\text{del}}$ against cumulative unmet demand $V_{\text{unmet}}$. Without EWM, uncurtailed $100\%$ demand drains tanks within $6\text{ h}$, yielding a total delivered volume of only $1,353.5\text{ m}^3$ followed by $18\text{ h}$ of total blackout. Under EWM, graded curtailment maintains continuous low-rate supply across all $24\text{ h}$, delivering $1,843.1\text{ m}^3$ of water. As quantified in **Fig. 6(b)**, EWM achieves a **$+36.2\%$ net gain in total delivered water** ($+489.6\text{ m}^3$) and an **$-8.8\%$ net reduction in cumulative unmet demand** ($5,979.7\text{ m}^3$ vs. $6,469.3\text{ m}^3$), proving that continuous low-rate emergency supply delivers significantly more water than short-lived full-rate supply followed by prolonged blackout. Table 5 summarizes these quantitative metrics.

![Fig. 6 Dual-metric resilience comparison and volumetric water accounting](figures/Fig6.png)  
**Fig. 6. Dual-metric resilience comparison and volumetric water accounting ($t=24\text{--}48\text{ h}$). Panel (a) compares Pressure Resilience Index ($RI_{\text{pressure}}$) and Service Resilience Index ($RI_{\text{service}}$). Panel (b) illustrates cumulative delivered water volume ($V_{\text{del}}$) and unmet demand ($V_{\text{unmet}}$), quantifying the $+36.2\%$ net gain in delivered water.**

**Table 5: Dual-metric resilience assessment and volumetric water accounting ($t=24\text{--}48\text{ h}$)**

| Metric Category | Performance Indicator | Baseline (Without EWM) | Proposed (With EWM) | Net Change ($\Delta$) | Physical & Operational Significance |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **Resilience Index** | Pressure Index ($RI_{\text{pressure}}$) | $0.22$ | $0.84$ | $+0.62$ | Pipeline head maintained above critical threshold. |
| | Service Index ($RI_{\text{service}}$) | $0.23$ | $0.29$ | $+0.058$ | Continuity of actual delivered water service. |
| **Water Accounting** | Delivered Volume ($V_{\text{del}}$) | $1,353.5\text{ m}^3$ | $1,843.1\text{ m}^3$ | **$+489.6\text{ m}^3$ (+36.2%)** | **Net gain in actual water delivered to consumers.** |
| | Unmet Demand ($V_{\text{unmet}}$) | $6,469.3\text{ m}^3$ | $5,979.7\text{ m}^3$ | **$-8.8\%$ (-489.6 $\text{m}^3$)** | **Net reduction in municipal water deficit.** |
| | Nominal Demand ($V_{\text{req}}$) | $7,822.8\text{ m}^3$ | $7,822.8\text{ m}^3$ | $0.0\text{ m}^3$ | Shared uncurtailed baseline water demand. |

### 3.3 Multi-Factor Sensitivity Analysis and Operational Application Boundaries

To evaluate model robustness and identify operational application boundaries, a multi-factor sensitivity analysis was executed across risk threshold shifts ($\Delta H \in [-1.0, +1.0]\text{ m}$), tank storage scaling ($D_{\text{tank}} \in [0.6\times, 1.4\times]$), and outage durations ($T_{\text{fault}} \in [12\text{--}48\text{ h}]$). The visual trajectories and performance trade-offs are depicted in **Fig. 7** and **Fig. 8**, with quantitative metrics summarized in Table 6.

**Fig. 7** illustrates the sensitivity of delivered water volume gain across varying outage durations in **Fig. 7(a)** and tank storage capacities in **Fig. 7(b)**:
- **Outage Duration Sensitivity (Fig. 7(a))**: The response trajectory reveals a critical operational application boundary at $T_{\text{fault}} = 18\text{ h}$. For short outages ($T_{\text{fault}} = 12\text{ h}$), passive tank storage is sufficient to maintain supply without reaching outlet closure; active demand curtailment under EWM causes unnecessary service restriction, resulting in a slight net reduction in delivered volume ($-4.7\%$, represented by the over-curtailment region below $0\%$). Beyond $18\text{ h}$, however, as uncurtailed tanks dry out, EWM yields massive positive gains, reaching $+36.2\%$ at $24\text{ h}$ and $+117.9\%$ at $48\text{ h}$.
- **Tank Capacity Sensitivity (Fig. 7(b))**: The curve exhibits a steep negative slope, demonstrating a strong inverse storage dependency. In storage-constrained networks ($0.6\times$ diameter), passive storage exhausts rapidly, making EWM essential and yielding a massive **$+208.2\%$ gain in delivered water volume**. Conversely, in systems with large storage tanks ($1.4\times$ diameter), passive storage alone buffers the outage, rendering active load shedding redundant ($+0.09\%$ gain).

![Fig. 7 Sensitivity of delivered water volume gain across outage durations and tank sizes](figures/Fig7.png)  
**Fig. 7. Sensitivity of delivered water volume gain and unmet demand reduction across outage durations ($12\text{--}48\text{ h}$, a) and tank storage capacities ($0.6\times\text{--}1.4\times$, b), highlighting the $18\text{-h}$ over-curtailment boundary and inverse storage dependency.**

**Fig. 8** presents the response of Pressure Resilience Index ($RI_{\text{pressure}}$) and Service Resilience Index ($RI_{\text{service}}$) across risk threshold shifts ($\Delta H \in [-1.0, +1.0]\text{ m}$). Both metrics exhibit smooth, monotonic increases as thresholds are shifted upward ($+1.0\text{ m}$ conservative triggering), with $RI_{\text{pressure}}$ rising from $0.81$ to $0.87$ and $RI_{\text{service}}$ rising from $0.27$ to $0.30$. Crucially, delivered volume gains remain robustly positive ($+27.1\%$ to $+45.3\%$) across all threshold levels, proving that EWM performance is highly tolerant to threshold calibration variations.

![Fig. 8 Sensitivity of Pressure Resilience Index and Service Resilience Index](figures/Fig8.png)  
**Fig. 8. Sensitivity of Pressure Resilience Index ($RI_{\text{pressure}}$) and Service Resilience Index ($RI_{\text{service}}$) across risk threshold shifts ($\Delta H \in [-1.0, +1.0]\text{ m}$), demonstrating model robustness against threshold calibration uncertainty.**

**Table 6: Multi-factor sensitivity analysis and operational application boundaries**

| Sensitivity Factor | Factor Level | $RI_{\text{pressure}}$ (No / With) | $RI_{\text{service}}$ (No / With) | Delivered Volume Gain (%) | Unmet Demand Reduction (%) | Operational Boundary & Performance Regime |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **Threshold Shift ($\Delta H$)** | $-1.0\text{ m}$ | $0.22 / 0.81$ | $0.23 / 0.27$ | $+27.1\%$ | $-5.8\%$ | **Robust Positive Gain**: High tolerance to threshold calibration. |
| | $0.0\text{ m}$ (Baseline) | $0.22 / 0.84$ | $0.23 / 0.29$ | $+36.2\%$ | $-8.8\%$ | **Optimal Baseline**: Balanced pressure and service gains. |
| | $+1.0\text{ m}$ | $0.22 / 0.87$ | $0.23 / 0.30$ | $+45.3\%$ | $-9.9\%$ | **Conservative Trigger**: Earlier curtailment preserves more storage. |
| **Tank Diameter ($D_{\text{tank}}$)** | $0.6\times$ | $0.09 / 0.77$ | $0.09 / 0.22$ | **$+208.2\%$** | $-18.7\%$ | **Critical EWM Value**: Essential for storage-constrained networks. |
| | $1.0\times$ (Baseline) | $0.22 / 0.84$ | $0.23 / 0.29$ | $+36.2\%$ | $-8.8\%$ | **Moderate EWM Value**: Substantial service continuity gain. |
| | $1.4\times$ | $0.51 / 0.90$ | $0.51 / 0.53$ | $+0.09\%$ | $-0.08\%$ | **Low EWM Value**: Passive physical storage dominates. |
| **Fault Duration ($T_{\text{fault}}$)** | $12\text{ h}$ | $0.43 / 0.89$ | $0.46 / 0.43$ | **$-4.7\%$** | $+1.4\%$ | **Over-Curtailment Boundary**: Unnecessary for minor outages. |
| | $24\text{ h}$ (Baseline) | $0.22 / 0.84$ | $0.23 / 0.29$ | $+36.2\%$ | $-8.8\%$ | **High EWM Value**: Prevents complete zero-supply collapse. |
| | $48\text{ h}$ | $0.11 / 0.79$ | $0.11 / 0.22$ | **$+117.9\%$** | $-13.6\%$ | **Vital EWM Value**: Maintains lifeline water supply during prolonged events. |
