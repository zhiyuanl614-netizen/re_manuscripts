import docx
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

def create_omml_fraction(num_text, den_text):
    return f'<m:f><m:num><m:r><m:t>{num_text}</m:t></m:r></m:num><m:den><m:r><m:t>{den_text}</m:t></m:r></m:den></m:f>'

def create_omml_integral(sub_text, super_text, body_text):
    return (
        f'<m:nary>'
        f'<m:naryPr><m:chr m:val="∫"/><m:limLoc m:val="subSup"/></m:naryPr>'
        f'<m:sub><m:r><m:t>{sub_text}</m:t></m:r></m:sub>'
        f'<m:sup><m:r><m:t>{super_text}</m:t></m:r></m:sup>'
        f'<m:e><m:r><m:t>{body_text}</m:t></m:r></m:e>'
        f'</m:nary>'
    )

doc = docx.Document()

# Test 1: Demand equation
p1 = doc.add_paragraph()
p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
xml1 = f'''<m:oMathPara {nsdecls("m")}>
  <m:oMath>
    <m:r><m:t>Demand(j, t) = γ(t) · BaseDemand(j) · Pattern(t)</m:t></m:r>
  </m:oMath>
</m:oMathPara>'''
p1._p.append(parse_xml(xml1))

# Test 2: RI_pressure equation
p2 = doc.add_paragraph()
p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
frac1 = create_omml_fraction("1", "T_fault")
frac2 = create_omml_fraction("P̄(t)", "P_0")
integ = create_omml_integral("t_start", "t_end", f"({frac2}) dt")

xml2 = f'''<m:oMathPara {nsdecls("m")}>
  <m:oMath>
    <m:r><m:t>RI_pressure = </m:t></m:r>
    {frac1}
    <m:r><m:t> · </m:t></m:r>
    {integ}
  </m:oMath>
</m:oMathPara>'''
p2._p.append(parse_xml(xml2))

doc.save('/home/user/test_omml_eqs.docx')
print("Saved test_omml_eqs.docx successfully!")
