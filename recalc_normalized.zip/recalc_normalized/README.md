# Recalculated demand model (does not replace legacy code)

Original / first-revision scripts stay in:

- `02_revised/code/sim_revised.py`
- `02_revised/code/sensitivity.py`

This folder is the **corrected** implementation:

```
recalc_normalized/
  code/demand_patterns.py     # citable 24-h patterns
  code/sim_normalized.py      # single-scale λ, DSR denom = uncurtailed
  code/calibrate_lambda.py    # pick λ* so no-EWM outlet ≈ 6 h
  input/anytown.inp           # copy of the network file
  docs/Citable_Demand_Pattern.md
```

## Demand equation

\[
q_i(t)=q_{i,\mathrm{inp}}\cdot\hat m(t)\cdot\lambda\cdot\alpha(t)
\]

- \(\hat m\): mean-1 Anytown 8×3 h ADD pattern (default)
- \(\lambda\): intensity, **once** (no 1.5²)
- \(\alpha\): EWM only; **not** in the DSR denominator

## Locked calibration

- Recommendation A: EPANET pattern = 1; \(m(t)\cdot\lambda\cdot\alpha\) in `base_value` (clock-correct)
- \(\lambda^\ast = 0.12\) (no-EWM outlet ≈ 6.17 h after A)
- Base case: \(RI_p\) 0.247→0.887, \(RI_s\) 0.264→0.328, delivery **+61.3%**
- Main-text sensitivity = **threshold / tank size / fault duration** (`docs/Sensitivity_Results.md`)
- Default `python3 sensitivity_normalized.py` runs only those three; `--all` adds λ and pattern (SI)

## Run (needs `wntr`)

```bash
cd code
python3 calibrate_lambda.py           # optional re-grid
python3 sensitivity_normalized.py     # five-factor sweep (uses LAMBDA_STAR=0.12)
```
