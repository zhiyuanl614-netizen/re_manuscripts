"""
Citable 24-h demand multipliers for the recalculated co-simulation.

Primary pattern (default)
-------------------------
ANYTOWN_ADD_3H  — eight 3-hour average-day factors of the Anytown benchmark,
                  expanded to 24 hourly multipliers (piecewise constant).

  Blocks (local clock time):
    00–03  0.70    03–06  0.60    06–09  1.20    09–12  1.30
    12–15  1.20    15–18  1.10    18–21  1.00    21–24  0.90

  Mean of the eight blocks = 1.00 (already normalised). Peak = 1.30 (09:00–12:00).

  Citations (use all three in the manuscript):
    Walski T M, Brill E D, Gessler J, Goulter I C, Jeppson R M, Lansey K,
      Lee H L, Liebman J C, Mays L, Morgan D R, Ormsbee L (1987).
      Battle of the network models: Epilogue. Journal of Water Resources
      Planning and Management, 113(2): 191–203.
      — Origin of Anytown; average-day, instantaneous peak (1.8×ADD) and
        fire (1.3×ADD) loadings.
    Farmani R, Walters G A, Savic D A (2005). Trade-off between total cost
      and reliability for Anytown water distribution network. Journal of
      Water Resources Planning and Management, 131(3): 161–171.
      — Standard EPS treatment of the eight 3-h average-day factors.
    Siew C, Tanyimboh T T, Seyoum A G (2016). Penalty-free multi-objective
      evolutionary approach to optimization of Anytown water distribution
      network. Water Resources Management, 30: 3671–3688.
      — Confirms eight 3-h factors and that 1.30 is the highest ADD factor
        (occurring at the 10th hour, i.e. the 09:00–12:00 block).

Secondary patterns (sensitivity / R2.5 “demand patterns”)
---------------------------------------------------------
FLAT_PAT1       — constant 1.0, identical to PAT1 in the bundled anytown.inp.
SHIFT_PLUS8     — ANYTOWN_ADD_3H rolled by +8 h so the 1.30 peak falls inside
                  the 24–48 h outage window (methodological variant; not a
                  new empirical curve).
LEGACY_UNNORM   — undocumented 24-vector from the original submission
                  (NOT for the revised base case; kept only for audit).
"""

from __future__ import annotations

# Eight 3-h Anytown average-day factors (mean = 1.0, peak = 1.3).
_ANYTOWN_BLOCKS = [0.70, 0.60, 1.20, 1.30, 1.20, 1.10, 1.00, 0.90]
ANYTOWN_ADD_3H = [v for v in _ANYTOWN_BLOCKS for _ in range(3)]

FLAT_PAT1 = [1.0] * 24

def _roll(values, hours):
    h = hours % 24
    return values[h:] + values[:h]

SHIFT_PLUS8 = _roll(ANYTOWN_ADD_3H, 8)

# Original submission vector (mean ≈ 0.065). Do not use as the revised base case.
LEGACY_UNNORM = [
    0.046, 0.031, 0.038, 0.025, 0.046, 0.072,
    0.076, 0.110, 0.111, 0.083, 0.066, 0.074,
    0.066, 0.060, 0.073, 0.063, 0.064, 0.080,
    0.071, 0.073, 0.059, 0.050, 0.062, 0.063,
]

PATTERNS = {
    "anytown_add_3h": ANYTOWN_ADD_3H,
    "flat": FLAT_PAT1,
    "shift_plus8": SHIFT_PLUS8,
    "legacy_unnorm": LEGACY_UNNORM,
}

DEFAULT_PATTERN = "anytown_add_3h"


def normalised(name: str):
    """Return a 24-vector with mean 1.0."""
    raw = list(PATTERNS[name])
    mu = sum(raw) / len(raw)
    if mu <= 0:
        raise ValueError(f"pattern {name} has non-positive mean")
    return [x / mu for x in raw]


def describe(name: str) -> str:
    v = PATTERNS[name]
    n = normalised(name)
    return (
        f"{name}: n={len(v)}, raw_mean={sum(v)/len(v):.4f}, "
        f"raw_min={min(v):.3f}, raw_max={max(v):.3f}, "
        f"norm_peak={max(n):.3f}"
    )
