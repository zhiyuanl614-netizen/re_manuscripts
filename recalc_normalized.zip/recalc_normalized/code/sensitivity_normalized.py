"""
Sensitivity on the corrected demand model (R2.5).

Main-text factors (default):
  1) threshold shift (m)
  2) tank diameter scale
  3) fault duration (h)

Optional (python3 sensitivity_normalized.py --all):
  intensity λ and pattern shape — keep as supplementary only.

Run after setting LAMBDA_STAR from results/lambda_calibration.csv.
"""
import os
import numpy as np
import pandas as pd

import sim_normalized as S

INP = "../input/anytown.inp"
OUT = "../results"
os.makedirs(OUT, exist_ok=True)

# Placeholder: overwrite after calibration (closest no-EWM outlet ≈ 6 h).
LAMBDA_STAR = 0.12
PATTERN_STAR = "anytown_add_3h"
TIMESTEP = 300


def run_config(mode, intensity_lambda=LAMBDA_STAR, pattern_name=PATTERN_STAR,
               fault_duration=24 * 3600, threshold_shift=0.0, diameter_scale=1.0,
               fault_start=24 * 3600, duration=3 * 24 * 3600, tag="cfg"):
    db_path = os.path.join(OUT, f"_sens_{tag}_{mode}.db")
    if os.path.exists(db_path):
        os.remove(db_path)
    fault = S.WaterSourceInterruption(fault_start, fault_duration, affected_pumps=None)
    SimClass = S.NoEWSim if mode == "no_ew" else S.EWSim
    sim = SimClass(
        INP, db_path, TIMESTEP, fault_scenario=fault, verbose=False,
        intensity_lambda=intensity_lambda, pattern_name=pattern_name,
    )
    if abs(diameter_scale - 1.0) > 1e-9:
        for t in sim.tanks:
            sim.wn.get_node(t).diameter *= diameter_scale
    if mode == "ew" and abs(threshold_shift) > 1e-9:
        new_levels = []
        for name, thr, rd, rank in sim.ews.LEVELS:
            new_levels.append((name, max(0.6, thr + threshold_shift), rd, rank))
        sim.ews.LEVELS = new_levels
        sim.ews.THRESHOLD_MAP = {lv: thr for lv, thr, _, _ in new_levels}
        sim.ews.REDUCTION_MAP = {lv: rd for lv, _, rd, _ in new_levels}
        sim.ews.REDUCTION_MAP["NORMAL"] = 1.0
    sim.run(duration)
    sim.close()
    fault_end = fault_start + fault_duration
    ri_p = S.calc_RI(db_path, fault_start, fault_end, col="RI")
    ri_s = S.calc_RI(db_path, fault_start, fault_end, col="RI_service")
    unmet, req_v, del_v = S.unmet_demand_volume(db_path, fault_start, fault_end)
    os.remove(db_path)
    return dict(RI_p=ri_p, RI_s=ri_s, unmet=unmet, req=req_v, deliv=del_v)


def compare(**kw):
    n = run_config("no_ew", **kw)
    e = run_config("ew", **kw)
    return dict(
        RI_p_no=n["RI_p"], RI_p_ew=e["RI_p"], dRI_p=e["RI_p"] - n["RI_p"],
        RI_s_no=n["RI_s"], RI_s_ew=e["RI_s"], dRI_s=e["RI_s"] - n["RI_s"],
        deliv_no=n["deliv"], deliv_ew=e["deliv"],
        deliv_gain_pct=(e["deliv"] - n["deliv"]) / n["deliv"] * 100 if n["deliv"] else np.nan,
        unmet_no=n["unmet"], unmet_ew=e["unmet"],
        unmet_red_pct=(n["unmet"] - e["unmet"]) / n["unmet"] * 100 if n["unmet"] else np.nan,
    )


def sweep(name, param, values, fixed):
    rows = []
    for v in values:
        kw = dict(fixed)
        kw[param] = v
        print(f"  [{name}] {param}={v} ...", flush=True)
        r = compare(**kw, tag=f"{name}_{v}")
        rows.append({param: v, **r})
    df = pd.DataFrame(rows)
    path = os.path.join(OUT, f"sensitivity_{name}.csv")
    df.to_csv(path, index=False, encoding="utf-8-sig")
    print("  ->", path)
    return df


if __name__ == "__main__":
    import sys
    BASE = dict(
        intensity_lambda=LAMBDA_STAR,
        pattern_name=PATTERN_STAR,
        fault_duration=24 * 3600,
        threshold_shift=0.0,
        diameter_scale=1.0,
    )
    print("λ* =", LAMBDA_STAR, "pattern =", PATTERN_STAR)
    print("Main-text sweeps: threshold, tank size, fault duration")
    sweep("threshold", "threshold_shift", [-1.0, -0.5, 0.0, 0.5, 1.0], BASE)
    sweep("tanksize", "diameter_scale", [0.6, 0.8, 1.0, 1.2, 1.4], BASE)
    sweep("faultdur", "fault_duration",
          [12 * 3600, 18 * 3600, 24 * 3600, 36 * 3600, 48 * 3600], BASE)
    if "--all" in sys.argv:
        print("Supplementary sweeps: intensity, pattern")
        sweep("intensity", "intensity_lambda",
              [0.6 * LAMBDA_STAR, 0.8 * LAMBDA_STAR, LAMBDA_STAR,
               1.2 * LAMBDA_STAR, 1.4 * LAMBDA_STAR], BASE)
        sweep("pattern", "pattern_name",
              ["anytown_add_3h", "flat", "shift_plus8"], BASE)
    print("DONE")
