"""
Calibrate tank diameter (both T1 and T2, same scale) so that WITHOUT EWM
both tanks reach H < 0.50 m about TARGET_H hours after the pump trip.

Demand: official Anytown 8-block pattern at full scale (lambda = 1).
PLC and EWM levels stay 5 / 8 / 4 / 2 / 0.50 m.

Usage:  python3 calibrate_diameter.py
"""
import os
import pandas as pd
import sim_normalized as S

INP = "../input/anytown.inp"
OUT = "../results"
TARGET_H = 6.0
FAULT_START = 24 * 3600
# Volume ~ 1/0.12 => diameter ~ sqrt(8.33) ~ 2.9
SCALES = [2.2, 2.5, 2.7, 2.9, 3.1, 3.3, 3.6]


def outlet_h(db, tank="T1"):
    import sqlite3
    conn = sqlite3.connect(db)
    df = pd.read_sql(
        f"SELECT timestamp, value FROM sensor_data WHERE sensor_id='{tank}' "
        f"AND timestamp>={FAULT_START} ORDER BY timestamp",
        conn,
    )
    conn.close()
    hit = df[df["value"] < 0.50]
    if hit.empty:
        return None
    return float(hit["timestamp"].iloc[0] - FAULT_START) / 3600.0


def run_noew(scale):
    os.makedirs(OUT, exist_ok=True)
    db = os.path.join(OUT, f"_calD_{scale}.db")
    if os.path.exists(db):
        os.remove(db)
    fault = S.WaterSourceInterruption(FAULT_START, 24 * 3600)
    sim = S.NoEWSim(
        INP, db, 300, fault_scenario=fault,
        intensity_lambda=1.0, pattern_name="anytown_add_3h",
    )
    for t in sim.tanks:
        sim.wn.get_node(t).diameter *= scale
    d_m = sim.wn.get_node("T1").diameter
    sim.run(3 * 24 * 3600)
    sim.close()
    t1, t2 = outlet_h(db, "T1"), outlet_h(db, "T2")
    os.remove(db)
    return d_m, t1, t2


def main():
    rows = []
    print(f"lambda=1, pattern=anytown_add_3h, target no-EWM outlet ≈ {TARGET_H} h\n")
    for s in SCALES:
        print(f"  scale={s:.2f} ...", flush=True)
        d_m, t1, t2 = run_noew(s)
        print(f"      D={d_m:.3f} m  T1={t1} h  T2={t2} h")
        rows.append(dict(scale=s, diameter_m=d_m, T1_h=t1, T2_h=t2))
    df = pd.DataFrame(rows)
    path = os.path.join(OUT, "diameter_calibration.csv")
    df.to_csv(path, index=False)
    valid = df.dropna(subset=["T1_h"])
    if valid.empty:
        print("No scale emptied the tanks; expand the grid.")
    else:
        err = (valid["T1_h"] - TARGET_H).abs()
        best = valid.loc[err.idxmin()]
        print("\nRecommended D* (closest to 6 h):")
        print(best.to_string())
    print("saved", path)


if __name__ == "__main__":
    main()
