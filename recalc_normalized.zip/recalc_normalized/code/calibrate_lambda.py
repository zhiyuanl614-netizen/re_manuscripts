"""
Calibrate intensity λ so that, without EWM, both tanks reach H < 0.50 m
about TARGET_H hours after the pump trip (default 6 h).

Requires: wntr, epanet.

Usage (from this directory):
    python3 calibrate_lambda.py
"""
import os
import numpy as np
import pandas as pd

import sim_normalized as S
import demand_patterns as DP

INP = "../input/anytown.inp"
OUT = "../results"
TARGET_H = 6.0
FAULT_START = 24 * 3600
# Coarse then optional refine. λ=1 is full Anytown ADD and empties tanks in minutes.
LAMBDAS = [0.04, 0.06, 0.08, 0.10, 0.12, 0.15, 0.20, 0.30, 0.50]


def outlet_time_h(db_path, tank="T1"):
    import sqlite3
    conn = sqlite3.connect(db_path)
    df = pd.read_sql(
        f"SELECT timestamp, value FROM sensor_data WHERE sensor_id='{tank}' "
        f"AND timestamp>={FAULT_START} ORDER BY timestamp",
        conn,
    )
    conn.close()
    hit = df[df["value"] < 0.50]
    if hit.empty:
        return None
    return float(hit["timestamp"].iloc[0] - FAULT_START) / 3600.0


def main():
    os.makedirs(OUT, exist_ok=True)
    rows = []
    print(f"Pattern = {DP.DEFAULT_PATTERN}  ({DP.describe(DP.DEFAULT_PATTERN)})")
    print(f"Target no-EWM outlet time ≈ {TARGET_H} h after t=24 h\n")
    for lam in LAMBDAS:
        print(f"  λ = {lam:.3f} ...", flush=True)
        r = S.run_one(
            "no_ew",
            INP,
            base=OUT,
            intensity_lambda=lam,
            pattern_name=DP.DEFAULT_PATTERN,
        )
        t1 = outlet_time_h(r["db_path"], "T1")
        t2 = outlet_time_h(r["db_path"], "T2")
        rows.append(
            dict(
                intensity_lambda=lam,
                T1_outlet_h=t1,
                T2_outlet_h=t2,
                RI_p=r["RI"],
                RI_s=r["RI_service"],
                delivered_m3=r["delivered_m3"],
            )
        )
        print(f"      T1={t1} h  T2={t2} h  RI_p={r['RI']}  Vdel={r['delivered_m3']}")
        if os.path.exists(r["db_path"]):
            os.remove(r["db_path"])

    df = pd.DataFrame(rows)
    path = os.path.join(OUT, "lambda_calibration.csv")
    df.to_csv(path, index=False)
    # pick closest finite T1 time to TARGET_H
    valid = df.dropna(subset=["T1_outlet_h"])
    if valid.empty:
        print("No λ emptied the tanks; increase the grid.")
    else:
        err = (valid["T1_outlet_h"] - TARGET_H).abs()
        best = valid.loc[err.idxmin()]
        print("\nRecommended λ* (closest to 6 h no-EWM outlet):")
        print(best.to_string())
    print("saved", path)


if __name__ == "__main__":
    main()
