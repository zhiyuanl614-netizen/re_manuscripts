# Main-text sensitivity (three factors only)

R2.5 in the manuscript uses **threshold, tank size, and outage duration**.  
Intensity \(\lambda\) and diurnal **shape** stay in the CSV folder as supplementary; they are not the §3.3 headline.

Locked base: Recommendation A, \(\lambda^\ast=0.12\), Anytown 8×3 h ADD, 24–48 h window.

| | Without EWM | With EWM | Change |
|--|------------:|---------:|--------|
| \(RI_p\) | 0.247 | 0.887 | +0.640 |
| \(RI_s\) | 0.264 | 0.328 | +0.064 |
| Delivered volume | 1158.6 m³ | 1869.1 m³ | **+61.3%** |

## 1. Risk-threshold shift \(\Delta H\)

`results/sensitivity_threshold.csv`

| \(\Delta H\) | \(RI_s\) no / with | \(\Delta RI_s\) | Delivered gain |
|---:|---:|---:|---:|
| −1.0 m (later trigger) | 0.264 / 0.354 | +0.090 | **+71.9%** |
| −0.5 m | 0.264 / 0.342 | +0.078 | +66.8% |
| 0 (base) | 0.264 / 0.328 | +0.064 | +61.3% |
| +0.5 m | 0.264 / 0.314 | +0.051 | +55.7% |
| +1.0 m (earlier) | 0.264 / 0.302 | +0.038 | **+50.3%** |

Volume gain stays positive. Earlier (more conservative) triggers **reduce** the gain. \(RI_p\) with EWM is 0.88–0.89 throughout.

## 2. Tank diameter

`results/sensitivity_tanksize.csv`

| Scale | \(RI_s\) no / with | \(\Delta RI_s\) | Delivered gain |
|---:|---:|---:|---:|
| 0.6× | 0.219 / 0.251 | +0.033 | **+66.2%** |
| 0.8× | 0.229 / 0.238 | +0.009 | +51.6% |
| 1.0× | 0.264 / 0.328 | +0.064 | +61.3% |
| 1.2× | 0.333 / 0.382 | +0.049 | +27.0% |
| 1.4× | 0.441 / 0.468 | +0.027 | **+3.9%** |

EWM is most useful when storage is tight; at 1.4× passive storage already covers most of the 24 h outage.

## 3. Outage duration

`results/sensitivity_faultdur.csv`

| Hours | \(RI_s\) no / with | \(\Delta RI_s\) | Delivered gain |
|---:|---:|---:|---:|
| 12 | 0.528 / 0.456 | **−0.072** | +3.2% |
| 18 | 0.352 / 0.371 | +0.019 | +35.0% |
| 24 | 0.264 / 0.328 | +0.064 | +61.3% |
| 36 | 0.258 / 0.285 | +0.027 | +51.1% |
| 48 | 0.194 / 0.264 | +0.071 | **+92.2%** |

At 12 h, \(RI_s\) falls (over-curtailment) even though volume is slightly up. From 18 h the service index turns positive. No-EWM delivery plateaus near 1159 m³ once tanks empty (~6 h).

## What to claim in §3.3 / R2.5

EWM is not unconditionally beneficial. On the three main-text axes:

- **Threshold:** ±1 m changes the 24 h volume gain from +50% to +72%; sign stays positive; earlier triggers are not better.
- **Storage:** gain is large for small tanks and nearly vanishes at 1.4× diameter.
- **Duration:** 12 h is an over-curtailment boundary on \(RI_s\); ≥18 h EWM raises both service index and delivered volume.

\(RI_p\) with EWM remains >0.83 in every row and is **not** used as the robustness metric.

Intensity and pattern CSVs remain on disk if the response letter needs a one-sentence “we also scanned load factor and peak timing”.
