# Citable 24-h demand pattern (revised base case)

## Recommended default

**Anytown average-day, eight 3-hour factors** (piecewise constant → 24 hourly multipliers).

| Clock | 00–03 | 03–06 | 06–09 | 09–12 | 12–15 | 15–18 | 18–21 | 21–24 |
|-------|------:|------:|------:|------:|------:|------:|------:|------:|
| Factor | 0.70 | 0.60 | 1.20 | **1.30** | 1.20 | 1.10 | 1.00 | 0.90 |

- Mean of the eight blocks = **1.00** (already normalised).
- Peak = **1.30** at 09:00–12:00 (the 10th hour), matching Siew et al. (2016).
- Instantaneous peak loading of the original competition (**1.8 × ADD**) is a *separate design case* and is **not** used as the EPS diurnal peak.

Implemented in `code/demand_patterns.py` as `anytown_add_3h`.

## Citations to put in §2.1

1. **Walski T M, Brill E D, Gessler J, Goulter I C, Jeppson R M, Lansey K, Lee H L, Liebman J C, Mays L, Morgan D R, Ormsbee L (1987).** Battle of the network models: Epilogue. *Journal of Water Resources Planning and Management*, 113(2): 191–203.  
   Origin of Anytown; average-day, instantaneous peak (1.8×ADD) and fire (1.3×ADD) loadings.

2. **Farmani R, Walters G A, Savic D A (2005).** Trade-off between total cost and reliability for Anytown water distribution network. *Journal of Water Resources Planning and Management*, 131(3): 161–171.  
   Standard extended-period use of the eight 3-h average-day factors.

3. **Siew C, Tanyimboh T T, Seyoum A G (2016).** Penalty-free multi-objective evolutionary approach to optimization of Anytown water distribution network. *Water Resources Management*, 30: 3671–3688.  
   States explicitly that there are eight 3-h ADD factors and that **1.30 is the highest**, occurring at the 10th hour.

## What this is *not*

- It is **not** PAT1 in the bundled `anytown.inp` (that file is all 1.0s; title “Anytown master file for rl-wds”).
- It is **not** the undocumented `[0.046, 0.031, …]` vector of the original submission.
- Walski (1987) specifies *design loadings* (ADD / peak hour / fire). The **eight 3-h EPS blocks** are the community standard reconstruction used by Farmani/Savic and Siew/Tanyimboh; cite them as such.

## Sensitivity shapes (R2.5)

| Name | Role |
|------|------|
| `anytown_add_3h` | Base case |
| `flat` | PAT1 / constant demand |
| `shift_plus8` | Same curve, peak moved into the 24–48 h outage (tests timing, not a new empirical pattern) |

## Intensity λ

After normalisation, **λ is applied once** to the `.inp` nodal bases.

λ = 1 means “mean demand = Anytown design ADD”. With the present tank geometry that empties storage in far less than 6 h. Calibrate λ* with:

```text
cd recalc_normalized/code
python3 calibrate_lambda.py
```

so that *without EWM* both tanks hit 0.50 m about **6 h** after the pump trip. Report λ* as a storage-matched operating load, not as “1.5 times Anytown demand”.
