#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement

OUT = "/home/user/re_manuscript/02_revised/recalc_normalized/docs/Response_to_Reviewers_EN_with_CN_notes.docx"
NAVY = RGBColor(0x1F, 0x3A, 0x5F)
GRAY = RGBColor(0x55, 0x55, 0x55)
RED = RGBColor(0x8B, 0x00, 0x00)

def font(run, size=11, bold=False, italic=False, color=None, east="宋体"):
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east)
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = color

def p(doc, text, size=11, bold=False, italic=False, color=None, first=False, after=8, align="justify"):
    x = doc.add_paragraph()
    x.paragraph_format.space_after = Pt(after)
    x.paragraph_format.space_before = Pt(0)
    x.paragraph_format.line_spacing = 1.15
    if align == "justify":
        x.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    elif align == "center":
        x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if first:
        x.paragraph_format.first_line_indent = Cm(0)
    r = x.add_run(text)
    font(r, size=size, bold=bold, italic=italic, color=color)
    return x

def note(doc, text):
    x = doc.add_paragraph()
    x.paragraph_format.space_after = Pt(12)
    x.paragraph_format.line_spacing = 1.1
    r = x.add_run("【作者注释·勿上传】" + text)
    font(r, size=9.5, italic=True, color=RED, east="宋体")

def quote(doc, text):
    p(doc, text, italic=True, color=GRAY, first=True, after=6)

def h(doc, text, level=1):
    hd = doc.add_heading(text, level=level)
    for r in hd.runs:
        r.font.color.rgb = NAVY
        r.font.name = "Times New Roman"

def shade(cell, hexcol):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:fill"), hexcol)
    sh.set(qn("w:val"), "clear")
    tcPr.append(sh)

def table(doc, headers, rows):
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.style = "Table Grid"
    for i, h0 in enumerate(headers):
        c = t.rows[0].cells[i]
        c.text = ""
        r = c.paragraphs[0].add_run(h0)
        font(r, size=8.5, bold=True, color=RGBColor(255, 255, 255), east="黑体")
        shade(c, "1F3A5F")
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            c = t.rows[i + 1].cells[j]
            c.text = ""
            r = c.paragraphs[0].add_run(str(v))
            font(r, size=8)
            if i % 2:
                shade(c, "F4F7FB")
    doc.add_paragraph()

doc = Document()
for s in doc.sections:
    s.top_margin = s.bottom_margin = s.left_margin = s.right_margin = Cm(2.4)

p(doc, "Response to Reviewers", size=16, bold=True, align="center", first=True, after=4)
p(doc, "Manuscript ID: FEM-2026-0130", size=12, bold=True, align="center", first=True, after=2)
p(doc, "Proactive Resilience of Urban Water Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early-Warning Management Perspective", size=11, italic=True, align="center", first=True, after=2)
p(doc, "Frontiers of Engineering Management  ·  Major revision", size=11, align="center", first=True, after=10)
note(doc, "本稿为投稿用英文回复。红色【作者注释】仅供内部核对，上传前请全文删除。数字一律用推荐A、λ*=0.12：RIp 0.247→0.887，RIs 0.264→0.328，交付+61.3%。勿混入旧稿0.22/0.84或+36.2%。")

p(doc, "Dear Editor and Reviewers,", first=True)
p(doc, "We thank the editorial office and both reviewers for the assessment of FEM-2026-0130. The comments identified genuine weaknesses in the original submission: early warning was described as classification rather than an operational intervention; the with/without comparison was not shown to share one hydraulic rule set; the resilience index was pressure-only and could record preserved head under demand curtailment; cyber non-idealities were not modelled; and evidence was a single deterministic case. We have rewritten the methods, recomputed the case with clock-correct diurnal demand (Recommendation A: hourly multipliers are written into nodal base demand so that 300 s solver restarts do not lock onto hour 0), adopted a dual-metric evaluation, and added a three-factor sensitivity analysis. Changes in the manuscript are marked in red.")
p(doc, "All scalar resilience indices are integrated only over the disruption window (24–48 h in the base case). Headline numbers are: RI_pressure 0.247 → 0.887; RI_service 0.264 → 0.328; delivered volume 1,158.6 → 1,869.1 m³ (+61.3%); unmet volume −13.6%.")

h(doc, "Revision map", 1)
table(doc,
      ["ID", "Action", "Where"],
      [
          ["R1.1", "Abstract rewritten (<250 words): scenario, EWM as graded curtailment, dual metrics, stress boundary", "Abstract"],
          ["R1.2", "Comparative review; three contributions at end of §1", "§1"],
          ["R1.3", "New §2.2 assumption table; water-level (not pressure) basis for five states", "§2.2–2.3, Tables 1–2"],
          ["R1.4", "0.50 m physical; 5.0 m = PLC; 4.0/2.0 m partition + ΔH trial", "§2.3"],
          ["R1.5", "Figures redrawn; Critical Threshold corrected; T1/T2 both shown", "Figs. 1–8"],
          ["R1.6", "Sensing–control–hydraulic timeline with clock times of α steps", "§4.1, Fig. 3"],
          ["R1.7", "Quality, backflow, uniform α; quasi-steady snapshots", "§4.3"],
          ["R1.8", "Digital-twin extension of the present WNTR platform; adaptive ΔH, α", "§4.4"],
          ["R1.9", "Conclusions: theory / numbers / utility actions", "§5"],
          ["R1.10", "time-difference buffer only; copy-edit", "Entire MS"],
          ["R1.11", "Duplicates removed; FEM author–year; Walski/Farmani/Siew for ADD pattern", "References"],
          ["R2.1", "EWM = 70/40/20% ratchet; not an alarm", "§2.3, Table 2"],
          ["R2.2", "Shared PDA, Δt, outlet rule; only α differs", "§2.4, Table 3"],
          ["R2.3", "RI_service via DSR (uncurtailed denominator) + volumes", "§2.5, §3.2, Table 5"],
          ["R2.4", "Delay/loss out of scope; buffer = closed-loop use of storage", "§2.2, §4.1"],
          ["R2.5", "Main text: threshold, tank size, outage duration; SI: λ and shape", "§3.3, Table 6"],
          ["R2.6", "Both tanks reported; coupling explained; abstract uses paired times", "Abstract, Table 4, §3.1"],
      ])
note(doc, "此表给AE分发用。上传英文稿时保留此表，删注释即可。")

# ===================== R1 =====================
h(doc, "Part I. Response to Reviewer 1", 1)
p(doc, "We are grateful for the structured comments on presentation, assumptions, figures, mechanism, and practical value.", first=True)

h(doc, "Comment 1 — Abstract and keywords", 2)
quote(doc, "The abstract contains redundant descriptions and lengthy sentences. Please streamline the language, and concisely summarize the research scenario, core methodology, key findings and major innovations.")
p(doc, "Response. We agree. The abstract has been rewritten to under 250 words in four blocks: (i) scenario — Anytown CPS, complete source outage at 24–48 h; (ii) method — WNTR/EPANET 2.2 PDA co-simulation; EWM is graded demand retention 70%/40%/20% with a one-way ratchet; (iii) findings — delivered volume +61.3% (1,158.6 to 1,869.1 m³), RI_service 0.264 → 0.328, RI_pressure 0.247 → 0.887 (head preservation only); both tanks reach outlet isolation at 6.2 h without EWM and 10.6 h with EWM (within one 5 min step); (iv) boundary — gains are stress-dependent (over-curtailment at 12 h). Keywords now include graded demand management and pressure-driven analysis.")
note(doc, "摘要头条必须是+61.3%和RIs，RIp放后面并写head only。失效时长用两池同一步6.2→10.6 h，不要写单一Δt。")

h(doc, "Comment 2 — Introduction", 2)
quote(doc, "The literature review is superficial… three research objectives are scattered. Reorganize and condense them…")
p(doc, "Response. Section 1 is reorganised around three comparative gaps: (i) water CPS work concentrates on cybersecurity and leak localisation rather than operational control under total source outage; (ii) resilience metrics that are topology- or pressure-based overstate service when demand is curtailed; (iii) early-warning studies often stop at alarms and do not close the loop with graded demand management. One paragraph at the end of §1 states the problem (zero-supply collapse under uncurtailed drawdown), the model (PDA co-simulation with executable α), and the mechanism (time-difference buffer as closed-loop use of tank storage, with a stress-dependent boundary).")
note(doc, "R1.2不能只换数字。执行改稿时引言必须按三缺口对比写，文末问题–模型–机制与贡献对齐。这是编辑评估里点名的薄弱项。")

h(doc, "Comment 3 — Materials and methods (assumptions and thresholds)", 2)
quote(doc, "Add a dedicated section listing all ideal assumptions… specify the basis for five-level water-level thresholds. The pressure threshold refers to GB 50013-2018.")
p(doc, "Response. New §2.2 and Table 1 list the idealizations (error-free sensing; zero latency and loss; instantaneous uniform α; quasi-steady PDA snapshots; neglected water quality; deterministic total pump trip), their practical impact, and mitigations. We state that the present results are an upper bound on the benefit of timely intervention. Communication delay and packet loss are out of scope.")
p(doc, "We separate three quantities that were easy to conflate. (1) The 0.10 MPa emergency service head is taken from GB 50013-2018 and is used only to interpret network pressure — it does not trigger EWM. (2) PDA uses P_req = 20 m as the head at which full assigned demand is granted. (3) The five states are tank water levels, not pressure grades:")
p(doc, "• 0.50 m — physical outlet submergence (anti-vortex); identical in both arms, not an EWM decision.", first=True)
p(doc, "• 5.0 m — existing PLC pump-on set-point (on at H ≤ 5 m, off at H ≥ 8 m).", first=True)
p(doc, "• 4.0 m and 2.0 m — operational partition of the 5.0–0.50 m usable depth, paired with 40% and 20% retention. They are not a code prescription. A shift ΔH ∈ [−1.0, +1.0] m leaves the 24 h delivered-volume gain positive (+50% to +72%).", first=True)
p(doc, "The 70/40/20% multipliers are a graded operational policy (deeper cuts nearer the outlet), not an optimum claimed from literature.")
note(doc, "切勿写“五级风险压力阈值”或“4.0/2.0来自国标”。三套数必须分开。4.0/2.0只能写partition+trial。")

h(doc, "Comment 4 — Results (figures)", 2)
quote(doc, "Incomplete labels, missing legends and spelling mistakes (e.g., Critical Threbok) in Figs. 4 and 5…")
p(doc, "Response. All figures were regenerated. “Critical Threbok” is corrected to “Critical Threshold”. Fig. 4 shows both tanks and the five-state legend; Fig. 5 reports pressure in MPa with the 0.10 MPa line; Fig. 6 is dual metrics and volumes; Figs. 7–8 are the three-factor sensitivity. Abbreviations are defined at first use.")
note(doc, "图必须按新库重画，状态时长与6.2/10.6 h、水量+61.3%一致。未重画不算回应R1.5。")

h(doc, "Comment 5 — Discussion", 2)
quote(doc, "Decompose the linkage among sensing, control and hydraulic layers; expand limitations; make Digital Twin / AI directions specific.")
p(doc, "Response. §4.1 now follows one clock. Sensing samples H and pump status every 300 s. After the trip at t = 24 h, control issues α = 0.70 / 0.40 / 0.20 at t = 26.08 / 27.33 / 31.08 h under the ratchet. Hydraulics reduce outflow and delay outlet isolation from 6.2 h to 10.6 h. The time-difference buffer is this usable window from closed-loop spending of storage, not a modelled communications delay.")
p(doc, "§4.3 expands limitations: water age and disinfectant decay under low flow; local transient/backflow risk despite an acceptable network-average head; uniform α versus priority customers; quasi-steady 300 s snapshots (no water hammer); outages other than a total pump trip are not simulated.")
p(doc, "§4.4 specifies an extension of the present WNTR–EPANET platform to an online shadow model that updates ΔH and α(t) from short-horizon drawdown forecasts, with a multi-objective target (emergency head, delivered volume, equity) aimed at the 12 h over-curtailment mode.")
note(doc, "三层联动要用这条时间线，不要只写形容词。未来工作必须接到12 h过度限流，避免空泛AI。")

h(doc, "Comment 6 — Conclusions", 2)
quote(doc, "Remove repeated content; reorganize into theoretical findings, key simulation results and engineering implications; add operational suggestions.")
p(doc, "Response. Section 5 has three non-overlapping blocks. (1) Theory: under total source outage, resilience is produced when sensing, a ratchet and PDA hydraulics convert storage into a time-difference buffer. (2) Results: +61.3% delivered volume; RI_service +0.064; RI_pressure records head only; 12 h is an over-curtailment boundary on RI_service; gains shrink as tanks grow. (3) Implications: encode Table 2 in existing SCADA/PLC; calibrate ΔH to local storage and expected outage length; use later/milder triggers when a short restoration is likely; do not use pressure-only dashboards as the sole emergency KPI.")
note(doc, "结论不要重复讨论。三条建议对准处长能执行。")

h(doc, "Comment 7 — Language and references", 2)
quote(doc, "Proofread; unify time-difference buffer/window; delete duplicate references; follow ENGINEERING Management format.")
p(doc, "Response. The manuscript was copy-edited. We use “time-difference buffer” as the sole term (the quantified duration is written as hours, not as a second jargon). The reference list was rebuilt in FEM author–year style; duplicates were removed. Walski et al. (1987), Farmani et al. (2005) and Siew et al. (2016) are cited for the Anytown average-day 8×3 h factors.")
note(doc, "执行时核对正文引用与列表闭环；删掉与供水CPS无关的条目。")

# ===================== R2 =====================
h(doc, "Part II. Response to Reviewer 2", 1)
p(doc, "We thank Reviewer 2 for identifying the causal and metric issues that determined the revision. The original claim that warning signals alone raise RI from 0.22 to 0.84 was not supportable.", first=True)

h(doc, "Comment 1 — EWM must be an operational intervention", 2)
quote(doc, "Sections 2.2–2.4 mainly describe sensing and classification… what concrete action is taken in Warning/Alert/Critical? RI 0.22 → 0.84 cannot be produced by alarms alone.")
p(doc, "Response. We agree completely. An alarm without an actuator cannot change hydraulics. EWM is a graded demand-management policy, executed every 300 s once (i) the source is in outage and (ii) pumps are physically off: WARNING (H < 5.0 m) → α = 0.70; ALERT (H < 4.0 m) → α = 0.40; CRITICAL (H < 2.0 m) → α = 0.20. A monotonic ratchet forbids de-escalation during the outage; α returns to 1.0 after t = 48 h. Outlet closure at H < 0.50 m is a shared physical interlock, not an EWM decision (Table 2). Pressure and volume gains are the hydraulic consequence of slower tank drawdown, not of the warning bit. Wording that attributed the old RI jump to “alarms” has been removed.")
note(doc, "必须承认原稿不成立。图4标出26.08/27.33/31.08三个α台阶。")

h(doc, "Comment 2 — Transparency of the with/without comparison", 2)
quote(doc, "Fig. 5 baseline drops to zero while EWM stays high. The two cases may not share the same hydraulic / performance-assignment rule.")
p(doc, "Response. Both arms use WNTR + EPANET 2.2 PDA, the same .inp, Δt = 300 s, initial geometry, the same 0.50 m outlet rule, the same P0, and the same RI formulae (Table 3). The single controlled factor is α(t): identically 1.0 without EWM. The baseline collapse to 0 MPa at t ≈ 30.4 h is not a hand-imposed binary score: uncurtailed demand empties both tanks in about 6.2 h; the shared interlock then isolates the outlets and PDA reports zero flow. With EWM the same rule fires at 10.6 h because outflow is smaller. In the threshold sweep the no-EWM columns are numerically identical, which confirms that only the EWM arm is being moved.")
note(doc, "用“阈值扫描无EWM列不变”作为公平性的硬证据。")

h(doc, "Comment 3 — Performance function and unmet demand", 2)
quote(doc, "P(t) is qualitative and pressure-based. Maintaining pressure by curtailing demand means RI may record preserved pressure rather than delivered service.")
p(doc, "Response. This comment is correct and was the main validity issue. Junction head is a hydraulic state; it is not supply capacity under load shedding. We retain RI_pressure = time integral of P_avg(t)/P0 over the outage as a head-preservation index only. We define P(t) = DSR(t) = q_act(t)/q_nom(t), where q_nom is uncurtailed nominal demand (pattern × λ*, not reduced by α). RI_service is the same integral applied to DSR. Volumes V_del and V_unmet use that same denominator.")
p(doc, "Over 24–48 h: RI_pressure 0.247 → 0.887; RI_service only 0.264 → 0.328; V_del 1,158.6 → 1,869.1 m³ (+61.3%); V_unmet 5,256.4 → 4,543.6 m³ (−13.6%). Without EWM the two indices nearly coincide (collapse kills head and delivery together). With EWM they diverge: head stays near the tank gravity grade (~45 m) precisely because outflow is cut. Unmet demand remains large (4,544 m³); EWM’s value is a longer partial-service trajectory, not restored nominal demand. Fig. 6 reports RI_p versus RI_s and the two volumes; DSR is not plotted as a third index.")
note(doc, "分母不跟α走。不要把DSR再当第三个RI。摘要先报+61%和RIs。")

h(doc, "Comment 4 — Cyber-physical contribution versus tank storage", 2)
quote(doc, "No delay, sensing error, packet loss… The time-difference buffer seems to come from physical tank storage.")
p(doc, "Response. We accept that communication delay, packet loss and sensor noise are not modelled (Table 1). The cyber layer is an ideal threshold classifier plus a ratchet. Storage is the resource; the CPS contribution is when and at which α that resource is spent. The same tanks, under the same outlet rule, last 6.2 h without the policy and 10.6 h with it. Without the control layer the buffer is unused and the system still collapses. We do not attribute ΔT to modelled latency.")
note(doc, "题目仍是CPS，贡献必须收窄到“何时按何档花掉储量”，不要写通信层创造了缓冲。")

h(doc, "Comment 5 — Robustness / single scenario", 2)
quote(doc, "Evidence is one deterministic scenario… robust to different demand patterns, thresholds, tank sizes, or failure assumptions?")
p(doc, "Response. We agree that a single 24 h case cannot support a universal claim. We withdrew wording that EWM “universally” raises resilience. The main text reports three factors, each with and without EWM, with both RIs and volumes integrated on that run’s outage window (Table 6, Figs. 7–8).")
p(doc, "(1) Thresholds. Shifting the three water-level triggers by ΔH ∈ [−1.0, +1.0] m does not change the no-EWM trajectory. With EWM, delivered-volume gain stays positive (+50.3% to +71.9%). Earlier triggers reduce the gain; they do not reverse its sign.")
p(doc, "(2) Tank size. Scaling both diameters together from 0.6× to 1.4× (system storage): +66.2% delivered volume at 0.6× versus +3.9% at 1.4×, where passive storage already covers most of the 24 h outage.")
p(doc, "(3) Failure duration (total pump trip only). At 12 h, RI_service falls (−0.072) while volume is only +3.2% (over-curtailment). From 18 h the service index turns positive; at 24 h volume +61.3%. We treat longer-horizon volume increments as directional; the clean no-EWM plateau is the 12–24 h window (~1,159 m³ once tanks empty).")
p(doc, "Demand patterns. The base case already uses the published Anytown 8×3 h average-day factors with clock-correct assignment (Recommendation A). We also scanned intensity λ and two shapes (flat; peak shifted into the outage) as supplementary checks. Light load (0.6 λ*) cuts delivery by 37%; putting the 1.30 peak inside the outage shrinks the EWM volume gain to +11% because the uncontrolled arm already delivers more before empty. These scans follow the same stress-boundary logic and are not repeated as main-text figures. We did not simulate single-pump or pipe-break failures.")
note(doc, "不要写four factors all addressed。主文三因素；回复用这段把pattern和failure类型说诚实。不要把+92%当硬数。")

h(doc, "Comment 6 — T1/T2 durations and abstract wording", 2)
quote(doc, "Table 2 reports very similar state-duration values for T1 and T2… The abstract reports the failure-duration reduction using a single value.")
p(doc, "Response. T1 and T2 have identical geometry and the same PLC/EWM set-points. They sit on opposite sides of the looped Anytown network. After a total pump trip they act as coupled gravity reservoirs and equalize (mean |H_T1 − H_T2| ≈ 0.02 m in the outage). A 0.3 m offset remains at t = 24 h from pre-fault operation; state occupancies differ by at most one 5 min step. EWM applies one network-wide α from the worse tank, which further aligns the trajectories. The abstract now states that both tanks reach outlet isolation at 6.2 h without EWM and at 10.6 h with EWM (within one time step). Table 4 lists both tanks.")
p(doc, "The similarity is therefore a property of identical tanks plus hydraulic coupling under a total source outage, not a tabulation error. When we set the diameters to 0.6× (T1) and 1.4× (T2) as a check, Normal-state occupancy diverges (0.75 h vs 1.33 h without EWM) while fail times still differ by less than 0.6 h because the mesh lets the larger tank support the smaller tank’s side. Asymmetric storage is not used in the main R2.5 sweep, which concerns system storage.")
note(doc, "不对称算例只在回复里用，不上主文表6。摘要必须双池同时刻。")

h(doc, "Closing", 1)
p(doc, "We believe each numbered comment is answered either by new analysis or by an explicit scope statement. The causal story is now: graded demand management, fairly compared under one PDA rule set, increases delivered volume and delays isolation under medium-to-high stress, while pressure-only RI must not be used alone. We hope the revision meets the standards of Frontiers of Engineering Management.", first=True)
p(doc, "Sincerely,", first=True, after=4)
p(doc, "The authors", first=True)

doc.save(OUT)
print("wrote", OUT)
