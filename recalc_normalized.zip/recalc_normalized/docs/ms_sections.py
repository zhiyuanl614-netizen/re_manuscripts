# -*- coding: utf-8 -*-
"""Shared revised-manuscript blocks for the response letter and the full MS."""

TITLE = (
    "Proactive Resilience of Urban Water Supply Cyber-Physical Systems under "
    "Extreme Water Network Malfunctions: An Early-Warning Management Perspective"
)

ABSTRACT = (
    "Urban water supply cyber-physical systems (CPS) can raise proactive resilience "
    "by using the time gap between fast cyber sensing and slow hydraulic degradation. "
    "This study converts early warning into implementable operations during a complete "
    "source outage. A co-simulation on the Anytown benchmark couples WNTR, the EPANET 2.2 "
    "pressure-driven analysis (PDA) solver, and SCADA logic over 72 h, with pumps off at "
    "24–48 h. Early-warning management (EWM) is a graded demand-retention policy: 70%, 40% "
    "and 20% of uncurtailed demand in the Warning, Alert and Critical water-level states, "
    "with a one-way ratchet. Performance is measured by a pressure resilience index "
    "RI_pressure, a service resilience index RI_service based on the demand satisfaction "
    "ratio (PDA delivery over uncurtailed nominal demand), and delivered and unmet volumes, "
    "all integrated on the outage window only. Under the 24 h outage, EWM changes failure "
    "from abrupt collapse to controlled degradation: delivered volume rises by 61.3% "
    "(1,158.6 to 1,869.1 m³), unmet demand falls by 13.6%, RI_service rises from 0.264 to "
    "0.328, and RI_pressure rises from 0.247 to 0.887 (head preservation). Both tanks reach "
    "outlet isolation at 6.2 h without EWM and at 10.6 h with EWM (within one 5 min step). "
    "Sensitivity on water-level threshold shift, tank diameter and outage duration shows "
    "that gains are stress-dependent and that a 12 h outage can over-curtail service. "
    "The results support stress-aware emergency load shedding in municipal utilities."
)

KEYWORDS = (
    "Cyber-physical systems; Urban water supply; Proactive resilience; "
    "Early-warning management; Graded demand management; Pressure-driven analysis"
)

# --- §1 last paragraph (objectives) ---
INTRO_GAPS = (
    "Despite expanding research on smart water systems, three gaps persist. First, "
    "CPS studies in the water domain predominantly address cybersecurity, attack detection "
    "and leak localisation (Bhardwaj et al., 2021; Hassanzadeh et al., 2020; Taormina et al., "
    "2018; Yadav and Paul, 2021), with limited examination of operational control under "
    "total source outage. Second, mainstream resilience metrics are topological or "
    "pressure-preserving (Cai et al., 2021; Casal-Campos et al., 2018; Hosseini et al., 2016; "
    "Meng et al., 2018). Under emergency demand curtailment, pressure-only indices can "
    "overestimate consumer service. Third, early-warning work is frequently confined to "
    "alarm generation or routing support (Juan-Garcia et al., 2017; Liu and Mijic, 2025; "
    "Wardropper and Brookfield, 2022) and rarely closes the loop with graded demand "
    "management. The quantitative link from warning state to delivered volume, and the "
    "stress level at which that link turns negative, remains insufficiently characterized."
)

INTRO_AIMS = (
    "This study develops a WNTR–EPANET 2.2 PDA co-simulation of the Anytown network under "
    "complete source interruption and operationalises EWM as three demand-retention tiers "
    "(70%, 40%, 20%). The contributions are: (1) a closed-loop emergency policy that replaces "
    "uncontrolled tank emptying with staged outflow; (2) a transparent co-simulation that "
    "maps SCADA states to executable multipliers under a single hydraulic rule set; (3) "
    "dual-metric and volumetric evidence for a time-difference buffer and its "
    "stress-dependent boundary across threshold, storage and outage duration."
)

SEC22 = (
    "To isolate the effect of graded demand management, the co-simulation adopts the "
    "idealizations in Table 1. They define an upper bound on the benefit of timely "
    "intervention, not a field replica of non-ideal telemetry. Communication delay, "
    "packet loss and sensor noise are out of scope: the cyber layer is an ideal threshold "
    "classifier plus a ratchet controller."
)

SEC23_EWM = (
    "Rather than a passive alarm log, EWM translates risk detection into closed-loop "
    "demand management (Fig. 3, Table 2). Sensors sample tank level H and pump status "
    "every 300 s. After source interruption (pumps physically off at t = 24 h), the "
    "controller maps level to a demand-retention multiplier α ∈ {1.00, 0.70, 0.40, 0.20} "
    "and forbids de-escalation until t = 48 h (monotonic ratchet). Commands are applied "
    "as nodal base-demand updates in the PDA solver. Outlet closure at H < 0.50 m is a "
    "shared physical interlock, not an EWM decision."
)

SEC23_THR = (
    "Three quantities must not be conflated. The 0.10 MPa (≈ 10 m) emergency service head "
    "follows GB 50013-2018 and is used only to interpret network pressure; it does not "
    "trigger EWM. PDA uses a required head P_req = 20 m as the head at which full assigned "
    "demand is granted. The five states are tank water levels: 0.50 m is outlet-crown "
    "submergence (anti-vortex isolation), identical in both arms; 5.0 m coincides with the "
    "existing PLC pump-on set-point (on at H ≤ 5.0 m, off at H ≥ 8.0 m); 4.0 m and 2.0 m "
    "partition the 5.0–0.50 m usable depth and pair with 40% and 20% retention. The "
    "intermediate cuts are an operational partition and numerical trial, not a code "
    "prescription. A uniform shift ΔH ∈ [−1.0, +1.0] m leaves the 24 h delivered-volume "
    "gain positive (Table 6)."
)

SEC24 = (
    "Without-EWM and with-EWM runs share the solver, network, step, initial geometry, "
    "outlet rule and RI formulae (Table 3). The single controlled factor is α(t): identically "
    "1.0 without EWM. The baseline collapse to 0 MPa at t ≈ 30.4 h is the PDA outcome of "
    "uncurtailed demand emptying both tanks in about 6.2 h, after which the shared 0.50 m "
    "interlock isolates the outlets. In the threshold sweep the no-EWM columns are unchanged, "
    "confirming that only the EWM arm is moved."
)

SEC25 = (
    "Nodal delivery follows PDA. Let q_nom,i(t) be uncurtailed nominal demand "
    "(inp base × λ* × hourly factor) and q_act,i(t) the PDA delivery. "
    "DSR(t) = Σ q_act / Σ q_nom. The denominator does not follow α, so load shedding is "
    "counted as service loss. RI_pressure integrates P_avg(t)/P0 over the outage "
    "(head preservation). RI_service integrates DSR(t) over the same window. "
    "V_del and V_unmet are time integrals of delivery and of (q_nom − q_act). "
    "Pre- and post-outage indices are not included in the scalars. DSR is the performance "
    "function for RI_service, not a third resilience index."
)

SEC31 = (
    "Without EWM, T1 and T2 reach the 0.50 m outlet threshold at t = 30.17 h "
    "(6.2 h of outflow). With EWM, both tanks fail at t = 34.58 h (10.6 h of outflow). "
    "The two tanks have identical geometry and set-points. After a total pump trip they "
    "act as coupled gravity reservoirs on the looped Anytown network (mean |H_T1 − H_T2| ≈ "
    "0.02 m during the outage). A 0.3 m offset at t = 24 h remains from pre-fault operation; "
    "state occupancies differ by at most one 5 min step. EWM applies one network-wide α "
    "from the worse tank, which further aligns the trajectories. Table 4 reports both tanks. "
    "The abstract therefore uses the common isolation times rather than a single unexplained Δt. "
    "EWM steps occur at t = 26.08 h (α = 0.70), 27.33 h (0.40) and 31.08 h (0.20)."
)

SEC32 = (
    "Pre-fault network-average head is about 52 m. Without EWM, head reaches 0 MPa at "
    "t ≈ 30.4 h. With EWM, head remains near the tank gravity grade (~45 m) and above "
    "0.10 MPa throughout 24–48 h (Fig. 5). The corresponding RI_pressure is 0.247 → 0.887. "
    "Junction head is a hydraulic state, not supply capacity under load shedding: high head "
    "can be produced by cutting outflow. Fig. 6 and Table 5 separate head from service. "
    "RI_service rises only from 0.264 to 0.328. Delivered volume increases from 1,158.6 m³ "
    "to 1,869.1 m³ (+61.3%, +710.5 m³). Unmet demand falls from 5,256.4 m³ to 4,543.6 m³ "
    "(−13.6%) against the same reference demand 6,410.5 m³. Without EWM the two indices "
    "nearly coincide; with EWM they diverge because curtailment preserves static head while "
    "recording a standing service deficit. EWM replaces a short full-rate pulse plus blackout "
    "with a longer partial-service trajectory."
)

SEC33 = (
    "Main-text sensitivity varies water-level thresholds, tank diameter (both tanks together) "
    "and outage duration (Table 6). Threshold shifts ΔH ∈ [−1.0, +1.0] m leave the no-EWM "
    "columns unchanged. Delivered-volume gain stays positive (+50.3% to +71.9%); earlier "
    "triggers reduce the gain and do not reverse its sign. Scaling both tank diameters from "
    "0.6× to 1.4× yields +66.2% delivered volume at 0.6× and only +3.9% at 1.4×, where "
    "passive storage already covers most of the 24 h outage. For a 12 h outage, RI_service "
    "falls by 0.072 while volume rises only 3.2% (over-curtailment). From 18 h the service "
    "index turns positive; at 24 h volume +61.3%. We emphasise the 12–24 h window, in which "
    "no-EWM delivery plateaus at 1,158.6 m³ once tanks empty. RI_pressure with EWM remains "
    ">0.83 in every row and is not used as the robustness metric. Intensity and diurnal-shape "
    "scans (supplementary) follow the same stress-boundary logic and are not repeated as "
    "main figures. Failures other than a total pump trip are not simulated."
)

SEC41 = (
    "Gains do not come from inventing extra water. Sensing sees drawdown immediately after "
    "t = 24 h; control issues α at 26.08, 27.33 and 31.08 h; hydraulics slow outflow and "
    "delay isolation by 4.4 h. Storage is the resource; the CPS contribution is when and at "
    "which α that resource is spent. The same tanks last 6.2 h without the policy and 10.6 h "
    "with it. The time-difference buffer is this usable operational window. We do not attribute "
    "it to modelled latency or packet-loss recovery (Table 1)."
)

SEC42 = (
    "RI_pressure +0.640 versus RI_service +0.064 is expected once shedding is the actuator. "
    "Pressure- or topology-only frameworks therefore need a service companion whenever "
    "EWM-type policies are evaluated. The operational meaning is 61.3% more water and 13.6% "
    "less deficit, organised as long low-rate supply instead of a short full-rate pulse plus "
    "blackout."
)

SEC43 = (
    "The 12 h case is retained as a true negative on RI_service. Practical limits not simulated "
    "include water-age and disinfectant decay under low flow, local transients and backflow, "
    "and uniform α versus priority service to lifeline customers. The engine is called as "
    "300 s PDA snapshots with tank levels carried forward (quasi-steady co-simulation, not a "
    "single 72 h EPS). Hourly demand is written into nodal bases at the start of each step "
    "(Recommendation A) so that solver restarts do not lock onto hour 0; a 5 min stamp lag "
    "can appear at hour boundaries. Single-pump and pipe-break failures are outside scope."
)

SEC44 = (
    "A direct extension is to run the present WNTR–EPANET model as an online shadow twin "
    "that forecasts short-horizon drawdown and updates ΔH and α(t), specifically to avoid "
    "the 12 h over-curtailment mode, with a vector objective of emergency head, V_del and equity."
)

SEC5 = (
    "Theoretical findings. Under total source interruption, resilience is not a static property "
    "of tank volume. It is produced when sensing, a ratchet controller and PDA hydraulics "
    "convert passive storage into a time-difference buffer and change collapse into staged "
    "degradation.\n\n"
    "Key results. On Anytown with a 24 h outage, EWM raises RI_pressure from 0.247 to 0.887 "
    "and RI_service from 0.264 to 0.328, increases delivery by 61.3% and cuts unmet volume "
    "by 13.6%, and extends outflow of both tanks from 6.2 h to 10.6 h. A 12 h outage reduces "
    "RI_service; benefits shrink as tank diameter grows to 1.4× and remain positive under "
    "±1 m threshold shifts.\n\n"
    "Engineering implications. Utilities can encode Table 2 in existing SCADA/PLC logic; "
    "calibrate ΔH to local storage and expected outage length; prefer later triggers when "
    "a short restoration is likely; and not use pressure-only dashboards as the sole "
    "emergency KPI."
)
