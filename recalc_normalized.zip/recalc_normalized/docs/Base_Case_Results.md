# Recalculated base case (Recommendation A locked)

**Demand implementation:** EPANET `SIM_PATTERN ≡ 1`. Each 300 s step writes

\[
q_{\mathrm{base}}=q_{\mathrm{inp}}\cdot\lambda\cdot\alpha\cdot\hat m(\mathrm{hour})
\]

into nodal `base_value`. Hydraulics and the DSR denominator use the **same** clock hour. This replaces the previous bug where every restart used \(\hat m(0)=0.70\).

**Pattern:** Anytown 8×3 h ADD, mean 1, peak 1.30 (09:00–12:00).  
**Intensity:** \(\lambda^\ast=0.12\) (recalibrated after A).  
**No-EWM outlet:** T1 = T2 = **6.17 h** after the pump trip (target 6 h).  
**Indices:** integrated on 24–48 h only.

## Headline metrics — use these (not +28.2% / not the pre-A table)

| Indicator | Without EWM | With EWM | Change |
|-----------|------------:|---------:|--------|
| \(RI_p\) | 0.247 | 0.887 | +0.640 |
| \(RI_s\) | 0.264 | 0.328 | **+0.064** |
| \(V_{\mathrm{del}}\) | 1158.6 m³ | 1869.1 m³ | **+61.3%** (+710.5 m³) |
| \(V_{\mathrm{unmet}}\) | 5256.4 m³ | 4543.6 m³ | **−13.6%** |
| \(V_{\mathrm{req}}\) | 6410.5 m³ | 6410.5 m³ | 0 |

EWM steps: WARNING 26.08 h (α=0.70) → ALERT 27.33 h (0.40) → CRITICAL 31.08 h (0.20).

Outlet-failure occupancy (24–48 h): no EWM 17.92 h; with EWM 13.50 h.

## Why delivery gain rose vs pre-A (+28% → +61%)

Pre-A hydraulics sat on night factor 0.70 all day; the morning peak (1.20–1.30 from ~t=30 h) never entered EPANET. After A, no-EWM still dies at ~6 h (still in the night/early-morning blocks), but **EWM keeps tanks discharging into the 1.2–1.3 morning peak**, so extra delivered volume is larger. The DSR denominator now matches that peak, so \(RI_s\) also rises more (+0.064 vs +0.024).

## Stale files

`results/sensitivity_*.csv` were generated **before** Recommendation A. Re-run `sensitivity_normalized.py` before quoting them in the manuscript.

`results/lambda_calibration.csv` and `base_*.db` are post-A.
