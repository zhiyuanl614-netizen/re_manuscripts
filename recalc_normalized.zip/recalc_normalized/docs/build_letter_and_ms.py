#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "/home/user/re_manuscript/02_revised/recalc_normalized/docs")
import ms_sections as M
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
import os

FIG = "/home/user/re_manuscript/02_revised/figures"
OUTD = "/home/user/re_manuscript/02_revised/recalc_normalized/docs"
NAVY = RGBColor(0x1F, 0x3A, 0x5F)
GRAY = RGBColor(0x44, 0x44, 0x44)

def fr(run, size=11, bold=False, italic=False, color=None):
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = color

def setup(doc):
    for s in doc.sections:
        s.top_margin = s.bottom_margin = Cm(2.4)
        s.left_margin = s.right_margin = Cm(2.4)
        s.page_width, s.page_height = Cm(21.0), Cm(29.7)

def addp(doc, text, size=11, bold=False, italic=False, color=None,
         align="justify", first=True, after=8, before=0):
    x = doc.add_paragraph()
    pf = x.paragraph_format
    pf.space_after = Pt(after)
    pf.space_before = Pt(before)
    pf.line_spacing = 1.15
    if align == "justify":
        x.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        if first:
            pf.first_line_indent = Cm(0.74)
    elif align == "center":
        x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "left":
        x.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = x.add_run(text)
    fr(r, size, bold, italic, color)
    return x

def hd(doc, text, lv=1):
    h = doc.add_heading(text, lv)
    for r in h.runs:
        r.font.color.rgb = NAVY
        r.font.name = "Times New Roman"
    return h

def shade(cell, hx):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:fill"), hx)
    sh.set(qn("w:val"), "clear")
    tcPr.append(sh)

def tbl(doc, headers, rows, caption=None):
    if caption:
        addp(doc, caption, size=10, italic=True, bold=True, align="center", first=False, after=4)
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.style = "Table Grid"
    for i, h0 in enumerate(headers):
        c = t.rows[0].cells[i]
        c.text = ""
        r = c.paragraphs[0].add_run(h0)
        fr(r, 8, True, False, RGBColor(255, 255, 255))
        shade(c, "1F3A5F")
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            c = t.rows[i + 1].cells[j]
            c.text = ""
            r = c.paragraphs[0].add_run(str(v))
            fr(r, 8)
            if i % 2:
                shade(c, "F4F7FB")
    doc.add_paragraph()

def fig(doc, fn, cap):
    path = os.path.join(FIG, fn)
    x = doc.add_paragraph()
    x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if os.path.exists(path):
        x.add_run().add_picture(path, width=Inches(5.8))
    addp(doc, cap, size=10, italic=True, align="center", first=False, after=10)

# =====================================================================
# FULL MANUSCRIPT
# =====================================================================
def build_ms():
    doc = Document()
    setup(doc)
    addp(doc, M.TITLE, size=16, bold=True, align="center", first=False, after=8)
    addp(doc, "Revised manuscript (FEM-2026-0130). Changes relative to the original submission are marked in red in the journal copy; this file is the clean revised text aligned with the response letter.",
         size=9, italic=True, align="center", first=False, color=GRAY, after=12)

    hd(doc, "Abstract")
    addp(doc, M.ABSTRACT)
    addp(doc, "Keywords: " + M.KEYWORDS, italic=True, first=False)

    hd(doc, "1. Introduction")
    addp(doc, "Urban water supply systems are lifeline infrastructure for public health, fire safety and economic continuity. Digital transformation is turning conventional networks into cyber-physical systems in which reservoirs, pumps, mains and tanks are coupled to SCADA, PLCs, sensors and automated valves (Alexandra et al., 2023; Bhardwaj et al., 2021; Liao et al., 2025; Yadav and Paul, 2021). The same coupling widens the disruption set: extreme weather, blackouts and source contamination can remove primary pumping for hours to days (Argyroudis et al., 2022; Mohebbi et al., 2020). Unregulated demand then empties emergency storage and produces pressure collapse (He et al., 2024; Wu and Li, 2021). Practice remains largely a fail-and-repair paradigm (Holling, 1973; Hosseini et al., 2016). A shift to proactive resilience is required (Garcia-Perez et al., 2023).")
    addp(doc, "Water CPS contain an under-used time-scale mismatch. SCADA updates arrive in seconds; tank drawdown evolves over hours (Arghandeh et al., 2016; Hassanzadeh et al., 2020). If warning states are mapped to control actions, passive storage becomes an active time-difference buffer—the mechanism studied here.")
    addp(doc, M.INTRO_GAPS)
    addp(doc, M.INTRO_AIMS)

    hd(doc, "2. Methodology")
    hd(doc, "2.1 Benchmark network and co-simulation platform", 2)
    addp(doc, "The testbed is Anytown (Walski et al., 1987). Fig. 1 shows 19 demand junctions (zonal, not individual customers), 34 pipes, tanks T1 and T2, reservoir R and pumps P1/P2. Both tanks have base elevation 66.54 m, diameter 9.95 m and initial level 3.051 m in the input file. Junctions J20–J22 have zero demand. The bundled file uses a flat PAT1; extended-period demand uses the published eight 3-h average-day factors (0.70, 0.60, 1.20, 1.30, 1.20, 1.10, 1.00, 0.90; mean 1, peak 1.30 at 09:00–12:00) (Farmani et al., 2005; Siew et al., 2016), assigned clock-correctly by writing m(t)·λ·α into nodal bases while the EPANET pattern is identically 1 (Recommendation A), so that 300 s solver restarts do not lock onto hour 0. Intensity λ* = 0.12 is calibrated so that, without EWM, both tanks reach 0.50 m about 6.2 h after the pump trip; it is a storage-matched operating load, not a claim that the city uses 12% of design demand.")
    addp(doc, "The environment is WNTR with EPANET 2.2 PDA (P_min = 0, P_req = 20 m, exponent 0.5), horizon 72 h, step 300 s. Each step is a quasi-steady snapshot: tank levels are carried forward as initial conditions. This is a co-simulation, not a single 72 h EPS. Fig. 2 outlines the loop.")
    fig(doc, "Fig1.png", "Fig. 1. Anytown topology.")
    fig(doc, "Fig2.png", "Fig. 2. WNTR/EPANET 2.2 co-simulation and SCADA loop.")

    hd(doc, "2.2 Idealized assumptions and scope", 2)
    addp(doc, M.SEC22)
    tbl(doc, ["Domain", "Assumption", "Practical impact", "Mitigation"],
        [
            ["Sensing", "Error-free tank and pump telemetry", "Noise can trigger EWM early or late", "Filtering; redundant sensors"],
            ["Communications", "Zero latency and zero loss", "Commands may lag by seconds–minutes", "Edge PLC threshold logic"],
            ["Actuation", "Instant, uniform nodal α", "Finite valve/AMI time; unequal customers", "Pre-armed AMI/PRV; priority exemptions"],
            ["Hydraulics", "Quasi-steady PDA snapshots", "No water hammer or pipe filling", "Transient checks before field use"],
            ["Water quality", "Quality non-degrading", "Age and chlorine decay in Critical", "Cap Critical duration; flush"],
            ["Disturbance", "Deterministic total pump trip", "Real events may be partial", "Duration sweep 12–48 h"],
        ],
        "Table 1. Modelling assumptions, impacts and mitigations")

    hd(doc, "2.3 EWM as graded demand management", 2)
    addp(doc, M.SEC23_EWM)
    fig(doc, "Fig3.png", "Fig. 3. Three-layer CPS: sensing, control, hydraulics.")
    tbl(doc, ["State", "Tank level", "Pumps", "α", "Basis"],
        [
            ["Normal", "H ≥ 5.0 m", "—", "1.00", "PLC pump-on set-point"],
            ["Warning", "H < 5.0 m", "Off", "0.70", "Same set-point; first cut"],
            ["Alert", "H < 4.0 m", "Off", "0.40", "Partition of usable depth + trial"],
            ["Critical", "H < 2.0 m", "Off", "0.20", "Partition + trial"],
            ["Outlet failure", "H < 0.50 m", "Off", "valve closed", "Physical submergence; both arms"],
        ],
        "Table 2. Water-level states and EWM actions")
    addp(doc, M.SEC23_THR)

    hd(doc, "2.4 Experimental design and fairness", 2)
    addp(doc, M.SEC24)
    tbl(doc, ["Item", "Without EWM", "With EWM", "Status"],
        [
            ["Solver", "WNTR / EPANET 2.2 PDA", "Same", "Identical"],
            ["Horizon / step", "72 h / 300 s", "Same", "Identical"],
            ["Outage", "Pumps off 24–48 h", "Same", "Identical"],
            ["Outlet rule", "Close if H < 0.50 m", "Same", "Identical"],
            ["Demand α", "1.00 always", "0.70 / 0.40 / 0.20 ratchet", "Only factor"],
        ],
        "Table 3. Comparative control matrix")

    hd(doc, "2.5 Dual metrics and volumetric accounting", 2)
    addp(doc, M.SEC25)

    hd(doc, "3. Results")
    hd(doc, "3.1 Tank levels and risk-state occupancy", 2)
    addp(doc, M.SEC31)
    fig(doc, "Fig4.png", "Fig. 4. Tank risk states without and with EWM.")
    tbl(doc, ["Scenario", "Tank", "Warn (h)", "Alert (h)", "Crit. (h)", "Outlet fail (h)", "Outflow (h)"],
        [
            ["Without EWM", "T1", "0.83", "1.92", "1.25", "17.92", "6.17"],
            ["Without EWM", "T2", "0.83", "1.92", "1.33", "17.92", "6.17"],
            ["With EWM", "T1", "1.17", "3.75", "3.50", "13.50", "10.58"],
            ["With EWM", "T2", "1.25", "3.75", "3.50", "13.50", "10.58"],
        ],
        "Table 4. State durations (24–48 h). Outflow = time to H < 0.50 m after t = 24 h.")

    hd(doc, "3.2 Pressure trajectories and dual-metric accounting", 2)
    addp(doc, M.SEC32)
    fig(doc, "Fig5.png", "Fig. 5. Network-average pressure, 72 h.")
    fig(doc, "Fig6.png", "Fig. 6. Dual metrics and volumetric accounts, 24–48 h.")
    tbl(doc, ["Indicator", "Without EWM", "With EWM", "Change"],
        [
            ["RI_pressure", "0.247", "0.887", "+0.640 (head only)"],
            ["RI_service", "0.264", "0.328", "+0.064"],
            ["Delivered volume", "1,158.6 m³", "1,869.1 m³", "+710.5 m³ (+61.3%)"],
            ["Unmet volume", "5,256.4 m³", "4,543.6 m³", "−712.8 m³ (−13.6%)"],
            ["Reference demand", "6,410.5 m³", "6,410.5 m³", "0"],
        ],
        "Table 5. Dual-metric assessment and water accounting (t = 24–48 h)")

    hd(doc, "3.3 Multi-factor sensitivity and operational boundaries", 2)
    addp(doc, M.SEC33)
    fig(doc, "Fig7.png", "Fig. 7. Sensitivity of delivery gain (outage duration and tank size).")
    fig(doc, "Fig8.png", "Fig. 8. Sensitivity of RI_pressure and RI_service to ΔH.")
    tbl(doc, ["Factor", "Level", "RI_s no / with", "ΔRI_s", "Delivered gain"],
        [
            ["ΔH", "−1.0 m", "0.264 / 0.354", "+0.090", "+71.9%"],
            ["ΔH", "0 (base)", "0.264 / 0.328", "+0.064", "+61.3%"],
            ["ΔH", "+1.0 m", "0.264 / 0.302", "+0.038", "+50.3%"],
            ["Dtank", "0.6×", "0.219 / 0.251", "+0.033", "+66.2%"],
            ["Dtank", "1.4×", "0.441 / 0.468", "+0.027", "+3.9%"],
            ["Tfault", "12 h", "0.528 / 0.456", "−0.072", "+3.2%"],
            ["Tfault", "24 h", "0.264 / 0.328", "+0.064", "+61.3%"],
        ],
        "Table 6. Main-text sensitivity (selected levels)")

    hd(doc, "4. Discussion")
    hd(doc, "4.1 Three-layer linkage and the time-difference buffer", 2)
    addp(doc, M.SEC41)
    hd(doc, "4.2 Divergence between pressure and service resilience", 2)
    addp(doc, M.SEC42)
    hd(doc, "4.3 Operational boundaries and constraints", 2)
    addp(doc, M.SEC43)
    hd(doc, "4.4 Future work", 2)
    addp(doc, M.SEC44)

    hd(doc, "5. Conclusions")
    for block in M.SEC5.split("\n\n"):
        addp(doc, block)

    hd(doc, "References")
    refs = [
        "Alexandra C, Daniell K A, Guillaume J, Saraswat C, Feldman H R (2023). Cyber-physical systems in water management and governance. Current Opinion in Environmental Sustainability, 62: 101290.",
        "Arghandeh R, Von Meier A, Mehrmanesh L, Mili L (2016). On the definition of cyber-physical resilience in power systems. Renewable and Sustainable Energy Reviews, 58: 1060–1069.",
        "Argyroudis S A, Mitoulis S A, Chatzi E, Baker J W, Brilakis I, Gkoumas K, Linkov I (2022). Digital technologies can enhance climate resilience of critical infrastructure. Climate Risk Management, 35: 100387.",
        "Bhardwaj A, Gupta A, Khatri S K (2021). Cyber-physical system security in smart water networks: A review. IEEE Transactions on Industrial Informatics, 17(10): 7125–7136.",
        "Cai B, Zhang Y, Wang H, Liu Y, Ji R, Gao C, Liu J (2021). Resilience evaluation methodology of engineering systems with dynamic-Bayesian-network-based degradation and maintenance. Reliability Engineering & System Safety, 209: 107464.",
        "Casal-Campos A, Sadr S M, Fu G, Butler D (2018). Reliable, resilient and sustainable urban drainage systems: An analysis of robustness under deep uncertainty. Environmental Science & Technology, 52(16): 9008–9021.",
        "Farmani R, Walters G A, Savic D A (2005). Trade-off between total cost and reliability for Anytown water distribution network. Journal of Water Resources Planning and Management, 131(3): 161–171.",
        "Garcia-Perez A, Cegarra-Navarro J G, Sallos M P, Martinez-Caro E, Chinnaswamy A (2023). Resilience in healthcare systems: Cyber security and digital transformation. Technovation, 121: 102583.",
        "Hassanzadeh A, Rasekh A, Galelli S, Aghashahi M, Taormina R, Ostfeld A, Banks M K (2020). A review of cybersecurity incidents in the water sector. Journal of Environmental Engineering, 146(5): 03120003.",
        "He S, Zhou Y, Yang Y, Liu T, Zhou Y, Li J, Guan X (2024). Cascading failure in cyber-physical systems: A review. IEEE Transactions on Cybernetics, 54(12): 7936–7954.",
        "Holling C S (1973). Resilience and stability of ecological systems. Annual Review of Ecology and Systematics, 4(1): 1–23.",
        "Hosseini S, Barker K, Ramirez-Marquez J E (2016). A review of definitions and measures of system resilience. Reliability Engineering & System Safety, 145: 47–61.",
        "Juan-Garcia P, Butler D, Comas J, Darch G, Sweetapple C, Thornton A, Corominas L (2017). Resilience theory incorporated into urban wastewater systems management. Water Research, 115: 149–161.",
        "Liao C, Chen X, Gao Z (2025). Toward smart charging, synergistic infrastructure and storable grid. Frontiers of Engineering Management, 12(3): 704–709.",
        "Liu L, Mijic A (2025). Performance-based resilience assessment in integrated water systems. Journal of Hydrology, 630: 134042.",
        "Meng F, Fu G, Farmani R, Sweetapple C, Butler D (2018). Topological ranking of water distribution networks for resilience assessment. Water Research, 129: 316–328.",
        "Ministry of Housing and Urban-Rural Development of China (MOHURD) (2018). Standard for Outdoor Water Supply Engineering (GB 50013-2018). Beijing: China Architecture & Building Press.",
        "Mohebbi S, Zhang Q, Wells E C, Zhao T, Nguyen H, Li M, Ou X (2020). Cyber-physical-social interdependencies and organizational resilience. Sustainable Cities and Society, 62: 102327.",
        "Siew C, Tanyimboh T T, Seyoum A G (2016). Penalty-free multi-objective evolutionary approach to optimization of Anytown water distribution network. Water Resources Management, 30: 3671–3688.",
        "Taormina R, Galelli S, Tippenhauer N O, Salomons E, Ostfeld A, Eliades D G, Ohar Z (2018). Battle of the attack detection algorithms. Journal of Water Resources Planning and Management, 144(8): 04018048.",
        "Walski T M, Brill E D, Gessler J, Goulter I C, Jeppson R M, Lansey K, Ormsbee L (1987). Battle of the network models: Epilogue. Journal of Water Resources Planning and Management, 113(2): 191–203.",
        "Wardropper C, Brookfield A (2022). Decision-support systems for water management. Journal of Hydrology, 610: 127928.",
        "Wu G, Li Z S (2021). Cyber-Physical Power System (CPPS): A review on measures and optimization methods of system resilience. Frontiers of Engineering Management, 8(4): 503–518.",
        "Yadav G, Paul K (2021). Architecture and security of SCADA systems: A review. International Journal of Critical Infrastructure Protection, 34: 100433.",
    ]
    for ref in refs:
        x = doc.add_paragraph()
        x.paragraph_format.left_indent = Cm(0.75)
        x.paragraph_format.first_line_indent = Cm(-0.75)
        x.paragraph_format.space_after = Pt(3)
        r = x.add_run(ref)
        fr(r, 9)

    path = os.path.join(OUTD, "Revised_Manuscript_FEM-2026-0130.docx")
    doc.save(path)
    print("MS", path)
    return path

# =====================================================================
# RESPONSE LETTER — original format
# =====================================================================
def block(doc, title, reviewer, response, changes, cn):
    hd(doc, title, 2)
    addp(doc, "Reviewer Comment:", bold=True, first=False, after=2)
    addp(doc, reviewer, italic=True, color=GRAY, first=False)
    addp(doc, "Author Response:", bold=True, first=False, after=2)
    addp(doc, response, first=False)
    addp(doc, "Changes in Manuscript:", bold=True, first=False, after=2)
    addp(doc, changes, first=False)
    x = doc.add_paragraph()
    x.paragraph_format.space_after = Pt(14)
    x.paragraph_format.line_spacing = 1.15
    r = x.add_run("【中文注释·上传前删除】\n")
    fr(r, 10, True, False, RGBColor(0x8B, 0x00, 0x00))
    r2 = x.add_run(cn)
    fr(r2, 10, False, False, RGBColor(0x8B, 0x00, 0x00))

def build_letter():
    doc = Document()
    setup(doc)
    addp(doc, "Response to Reviewers", size=16, bold=True, align="center", first=False, after=4)
    addp(doc, "Manuscript ID: FEM-2026-0130", size=12, bold=True, align="center", first=False, after=2)
    addp(doc, M.TITLE, size=11, italic=True, align="center", first=False, after=2)
    addp(doc, "Journal: ENGINEERING Management (Frontiers of Engineering Management)",
         size=11, align="center", first=False, after=12)

    addp(doc, "Dear Editor,", first=False)
    addp(doc, "We sincerely appreciate you and the two anonymous reviewers for reviewing our manuscript (Manuscript ID: FEM-2026-0130). The comments identified defects in methodology, mechanism interpretation, scenario comparison, performance metrics and presentation. We have carried out a substantial revision. All modified contents in the revised manuscript are highlighted in red. Below we restate each comment and present the corresponding revisions, including the complete revised text blocks that have been incorporated into the manuscript.")
    addp(doc, "After revision we believe the critical issues have been addressed. We resubmit the revised manuscript and this point-by-point response, and hope that the revised version meets the publication standards of ENGINEERING Management.")
    x = doc.add_paragraph()
    r = x.add_run("【中文注释·上传前请全文查找并删除所有红字注释】本回复按审稿人顺序：R1共7条，R2共6条。每条结构为意见原文→答复→写入修改稿的完整段落→本条中文注释。数字一律用推荐A：RIp 0.247→0.887，RIs 0.264→0.328，交付+61.3%，两池6.2→10.6 h。")
    fr(r, 10, False, True, RGBColor(0x8B, 0x00, 0x00))
    addp(doc, "Kind regards,", first=False)
    addp(doc, "The authors", first=False, after=16)

    addp(doc, "Detailed Response to Reviewers", size=14, bold=True, align="center", first=False)
    addp(doc, "Manuscript ID: FEM-2026-0130", align="center", first=False, after=2)
    addp(doc, "Journal: ENGINEERING Management", align="center", first=False, after=12)

    hd(doc, "Part 1: Response to Reviewer 1")
    addp(doc, "We express our sincere gratitude to Reviewer 1 for the thorough and constructive comments. We respond to all 7 numbered points in sequence. Under each point we provide a candid response followed by the complete revised manuscript text that has been incorporated.", first=False)

    block(
        doc, "Comment 1: Abstract and Keywords",
        "The abstract contains redundant descriptions and lengthy sentences. Please streamline the language, and concisely summarize the research scenario, core methodology, key findings and major innovations.",
        "We agree. The original abstract was redundant. We rewrote it to under 250 words in four blocks (scenario, method, findings, boundary). EWM is defined as graded demand management. Headline service numbers are reported before RI_pressure, which is labelled as head preservation. Isolation times are given for both tanks. Keywords were updated.",
        "Abstract\n" + M.ABSTRACT + "\n\nKeywords: " + M.KEYWORDS,
        "审稿人要精简摘要并写清情景/方法/发现/创新。我们完全重写，压到250词内。务必先报交付+61.3%和RI_s（0.264→0.328），RI_p放后面并写明只反映保压，否则R2.3等于没回。两池隔离写成6.2 h→10.6 h（同一步），不要再用单一“缩短Δt”。禁止混入旧稿0.22/0.84或+36.2%。",
    )
    block(
        doc, "Comment 2: Introduction",
        "The literature review is superficial. Most references are simply listed without in-depth comparative analysis. Please sort out state-of-the-art studies on water supply CPS, resilience assessment and early warning technologies, and clearly clarify the marginal contributions of this work against existing literature. The three research objectives are scattered. Reorganize and condense them at the end of the introduction to clearly state the problems to be solved, models to be established and mechanisms to be revealed.",
        "We agree. Section 1 now compares three streams (CPS/security, pressure/topology resilience, alarm-only early warning) and states gaps against each stream. The end of §1 condenses problem, model and mechanism into one paragraph with three contributions.",
        M.INTRO_GAPS + "\n\n" + M.INTRO_AIMS,
        "审稿人嫌综述报流水账、三个目标散落。只改摘要数字、引言仍罗列文献，二审仍会打回。必须按三条缺口对比：CPS多写网络安全、韧性指标多看压力/拓扑、预警多停在报警。文末一段对齐问题–模型–机制与三条贡献。",
    )
    block(
        doc, "Comment 3: Materials and Methods",
        "The current model assumes ideal conditions including error-free sensors, zero communication delay and no data loss. Please add a dedicated section to list all ideal assumptions explicitly, and discuss their potential impacts on simulation results in practical engineering. The pressure threshold refers to GB 50013-2018, while the water level thresholds for five risk states (Normal, Warning, Alert, Critical, Outlet Failure) are given without explanation. Please specify the basis for threshold division (engineering experience, published literature or numerical trial calculation).",
        "We agree on both counts. New §2.2 and Table 1 list idealizations, impacts and mitigations; results are an upper bound on timely intervention. We separate GB 50013-2018 (0.10 MPa, evaluation only) from PDA P_req = 20 m and from the five tank-level states. 0.50 m is physical outlet submergence; 5.0 m matches the PLC pump-on set-point; 4.0 m and 2.0 m are an operational partition plus trial, tested by ΔH = ±1 m.",
        "§2.2\n" + M.SEC22 + "\n\n(Table 1 is included in the revised manuscript.)\n\n§2.3 threshold paragraph\n" + M.SEC23_THR,
        "此条含两问：理想假设专节，以及五级水位依据。切勿写成“五级风险压力阈值”。三套数必须分开：0.10 MPa=GB 50013仅用于评价管网应急水头；PDA的P_req=20 m是满需水水头；5/4/2/0.5 m才是水位触发。0.50 m为出流淹没（两臂相同）；5.0 m对齐PLC启泵；4.0与2.0只能写“运行分段+试算”，用ΔH±1 m证明不绑死这两点。不能说国标规定了五级水位。",
    )
    block(
        doc, "Comment 4: Results",
        "There are incomplete labels, missing legends and spelling mistakes (e.g., Critical Threbok should be Critical Threshold) in Figs. 4 and 5. Please check all figures, tables, abbreviations and captions thoroughly to unify the format and eliminate typos.",
        "We apologize for the typographical and labelling errors. All figures were regenerated. “Critical Threbok” is corrected. Fig. 4 shows both tanks and a five-state legend; Fig. 5 uses MPa and the 0.10 MPa line; Fig. 6 reports dual metrics and volumes; Figs. 7–8 report the three-factor sensitivity.",
        "Fig. 4–8 captions and Table 4–6 in the revised manuscript (complete Results text):\n\n" + M.SEC31 + "\n\n" + M.SEC32 + "\n\n" + M.SEC33,
        "改错字Critical Threshold、补图例、统一缩写。正文数字已换而图仍是旧曲线，二审一眼能看出来。投稿前必须按新库重绘Fig.4–8，状态时长与6.2/10.6 h、水量+61.3%一致。当前修改稿中嵌入的图可能仍是初修版，需替换。",
    )
    block(
        doc, "Comment 5: Discussion",
        "The concept of time-based performance compensation is proposed, but the linkage mechanism among cyber sensing layer, control layer and physical hydraulic layer is not decomposed. Combine the CPS three-layer architecture to elaborate the complete working mechanism of EWM. Expand the discussion on limitations: the model does not take water quality deterioration, negative pressure backflow and dynamic user water demand into account; supplement relevant explanations. The future research directions (AI, Digital Twin) are too general. Combine the current simulation framework to specify how to integrate Digital Twin technology and realize dynamic threshold adjustment.",
        "We thank the reviewer. §4.1 now follows the clock: sensing every 300 s; α = 0.70/0.40/0.20 at 26.08/27.33/31.08 h; isolation delayed from 6.2 h to 10.6 h. §4.3 expands quality, backflow, uniform α, quasi-steady snapshots and outage type. §4.4 specifies a shadow model on the present WNTR platform targeting the 12 h over-curtailment mode.",
        "§4.1\n" + M.SEC41 + "\n\n§4.3\n" + M.SEC43 + "\n\n§4.4\n" + M.SEC44,
        "“时间补偿”不能只写形容词，要用一条时间线：每300 s感知；26.08/27.33/31.08 h发α=0.70/0.40/0.20；隔离从6.2 h拖到10.6 h。ΔT是闭环花掉储量的窗口，不是通信延迟模型。局限补水质、负压、均一α、步进准稳态。数字孪生必须接到本WNTR平台和12 h过度限流，避免空泛AI。",
    )
    block(
        doc, "Comment 6: Conclusions",
        "Remove repeated content and reorganize the conclusions into three parts: theoretical findings, key simulation results and engineering implications for clearer logic. Add targeted operational suggestions for water supply management departments to enrich the practical guidance of this research.",
        "We agree. Section 5 is reorganised into theoretical findings, key results and operational recommendations; repeated discussion sentences were deleted.",
        "§5 Conclusions\n" + M.SEC5,
        "结论拆成理论/结果/工程建议三块，删与讨论重复的句子。建议对准供水部门能执行：SCADA嵌入表2、按库容和预计时长标定、短修复用更晚触发、压力看板不当唯一KPI。",
    )
    block(
        doc, "Comment 7: Language, Grammar and References",
        "Proofread the full text to correct spelling errors, grammatical mistakes and awkward long sentences. Unify the expression of professional terms (time-difference buffer / time-difference window). Sort out the reference list: delete duplicate literature entries, and revise references to comply with the formatting requirements of ENGINEERING Management.",
        "We completed a full copy-edit. We use “time-difference buffer” as the sole term. The reference list was rebuilt in FEM author–year style; duplicates were removed. Walski et al. (1987), Farmani et al. (2005) and Siew et al. (2016) support the Anytown 8×3 h ADD pattern. Every remaining entry is cited in the text.",
        "Terminology is unified throughout the revised manuscript. The reconstructed reference list is printed at the end of the attached revised manuscript.",
        "核对引用闭环。",
    )

    hd(doc, "Part 2: Reply to Reviewer 2")
    addp(doc, "We thank Reviewer 2 for the comments on intervention definition, comparative control, the performance metric, CPS scope and sensitivity. These comments determined the revision. The original claim that warning signals alone raise RI from 0.22 to 0.84 was not supportable.", first=False)

    block(
        doc, "Comment 1 — Early Warning Mechanism (EWM) as an Operational Intervention",
        "The early warning mechanism is not clearly specified as an operational intervention. Sections 2.2–2.4 mainly describe sensing, monitoring, risk classification, and the recording of state transitions. However, it is not clear what concrete action is taken once the system enters the Warning, Alert, or Critical state. Since the source interruption scenario states that the reservoir supply is lost and the tanks receive no replenishment during 24–48 h, the reported increase in RI from 0.22 to 0.84 and the higher maintained pressure cannot be explained by warning signals alone.",
        "We fully agree. An alarm cannot change hydraulics. EWM is graded demand management: α = 0.70 / 0.40 / 0.20 in Warning / Alert / Critical, with a one-way ratchet, executed only when pumps are physically off. Outlet closure at 0.50 m is shared by both arms. Gains come from slower drawdown, not from the warning bit. The old attribution of RI 0.22 → 0.84 to alarms has been removed.",
        "§2.3\n" + M.SEC23_EWM + "\n\n(Table 2 in the revised manuscript.)",
        "R2第一刀：预警之后到底做了什么。必须承认“报警把RI从0.22拉到0.84”不成立。EWM=70/40/20%限流+棘轮，且须故障期且泵物理关。0.50 m关阀是两臂相同的物理保护，不是预警决策。图4标出26.08/27.33/31.08三个台阶。",
    )
    block(
        doc, "Comment 2 — Transparency and Fairness of Scenario Comparison",
        "The comparison between the “Without EWM” and “With EWM” cases appears insufficiently transparent. In Fig. 5, the pressure curve without EWM drops abruptly to zero, whereas the curve with EWM remains relatively stable for a much longer period. This raises the concern that the two cases may not have been evaluated using the same hydraulic or performance-assignment rule. If the baseline is partly treated as a binary failure while the EWM case is treated as a gradual degradation process, the comparison would overstate the contribution of EWM.",
        "Both arms use the same PDA solver, network, step, outlet rule, P0 and RI formulae (Table 3). Only α(t) differs. The drop to 0 MPa at t ≈ 30.4 h is the PDA outcome of uncurtailed emptying in 6.2 h plus the shared 0.50 m interlock. In the threshold sweep the no-EWM columns are identical.",
        "§2.4\n" + M.SEC24 + "\n\n(Table 3 in the revised manuscript.)",
        "审稿人怀疑基线按“坏了就零”、EWM按渐变打分。回击：同一PDA、同一0.50 m关阀，只改α。基线30.4 h归零是未限流约6.2 h放空后的水力结果。硬证据：阈值扫描里无EWM各列数字完全不变。",
    )
    block(
        doc, "Comment 3 — Definition of Performance Function and Unmet Demand Metrics",
        "The performance function used to calculate the resilience index is not sufficiently defined. Section 2.5 describes P(t) in qualitative terms, and the results appear to rely mainly on pressure. However, in a source-interruption scenario, maintaining pressure may be achieved by reducing outflow or curtailing demand. If unmet demand is not included in the performance metric, the RI may reflect preserved pressure rather than actual delivered water service.",
        "We fully agree. Junction head is not supply capacity under shedding. We retain RI_pressure as a head index only and set P(t) = DSR(t) with an uncurtailed denominator (α does not shrink the bar). RI_service uses the same integral. Over 24–48 h: RI_pressure 0.247 → 0.887; RI_service 0.264 → 0.328; V_del +61.3%; V_unmet −13.6%. Without EWM the two indices nearly coincide; with EWM they diverge. Fig. 6 does not plot DSR as a third index.",
        "§2.5\n" + M.SEC25 + "\n\n§3.2\n" + M.SEC32 + "\n\n(Table 5 in the revised manuscript.)",
        "有效性核心：节点水头≠供水能力，限流保压必然制造缺水缺口。保留RI_p只当保压；RI_s的分母是未限流名义需水，绝不随α缩小（否则又变成自己降低及格线）。无EWM时两项接近，有EWM时分叉（0.887 vs 0.328）正是审稿人所说的现象。交付+61.3%，缺水仍有4544 m³。不要把DSR画成第三个韧性指数。",
    )
    block(
        doc, "Comment 4 — Cyber-Physical Contribution and Time-Difference Buffer Attribution",
        "The cyber-physical contribution is not fully operationalized in the model. The manuscript describes a three-layer CPS architecture with PLCs, SCADA, gateway, and sensing links, but the simulation seems to use the cyber layer mainly for threshold-based classification. There is no clear modeling of communication delay, sensing error, packet loss, PLC behavior, or feedback control. Therefore, the “time-difference buffer” seems to come mainly from physical tank storage rather than from a modeled cyber-physical mechanism.",
        "We accept that delay, loss and sensor noise are not modelled (Table 1). Storage is the resource; the CPS contribution is when and at which α it is spent. The same tanks last 6.2 h without the policy and 10.6 h with it. We do not attribute ΔT to modelled latency.",
        "§2.2 scope plus §4.1\n" + M.SEC41,
        "承认未建延迟/丢包/传感误差。储量是资源，CPS贡献是何时按哪一档α把储量花掉。同样两口池：无政策6.2 h见底，有政策10.6 h。不要写“通信层创造了时间差缓冲”，题目里的CPS才能站得住。",
    )
    block(
        doc, "Comment 5 — Sensitivity Analysis and Operational Boundaries",
        "The evidence is based on a single deterministic scenario with fixed thresholds. The risk thresholds for tank levels and the specific water-source interruption case strongly determine the transition times and ΔT values, but the manuscript does not show whether the conclusions are robust to different demand patterns, thresholds, tank sizes, or failure assumptions. This limits the generality of the reported resilience improvement.",
        "We accept the concern and withdraw any “universal” claim. The main text reports three factors (Table 6): threshold shift (gain +50.3% to +71.9%, sign unchanged; earlier triggers reduce the gain); both-tank diameter 0.6×–1.4× (+66.2% to +3.9%); outage duration (at 12 h RI_service −0.072 and volume +3.2%; from 18 h the service index turns positive; 24 h +61.3%). We emphasise the 12–24 h window. The base case already uses clock-correct Anytown 8×3 h ADD factors. Supplementary scans of λ and two shapes follow the same stress-boundary logic (0.6 λ* cuts delivery 37%; peak-in-outage shrinks the EWM gain to +11%). Failures other than a total pump trip are not simulated.",
        "§3.3\n" + M.SEC33 + "\n\n(Table 6 in the revised manuscript.)",
        "收回“普遍大涨”。主文只做阈值/水池/时长三项。回复必须点名demand pattern：主案例已是文献八时段+推荐A；λ与峰移有补充扫描（0.6λ*交付−37%；峰落入中断窗时增益只剩+11%），不上主图。failure只变了全停泵时长，不是爆管/单泵。12 h的RI_s为负是应用边界。不要把48 h +92%当硬数（36/48 h无EWM水量未完全闭合）。不要写“四类扰动都完整解决了”。",
    )
    block(
        doc, "Comment 6 — Clarification of Tank State Durations and Numerical Consistency",
        "Some reported results require further clarification. For example, Table 2 reports very similar state-duration values for T1 and T2, although the two tanks are located in different parts of the network. The abstract also reports the failure-duration reduction using a single value, while the table appears to contain separate values for the two tanks. These details make the numerical evidence less clear.",
        "T1 and T2 have identical geometry and set-points. After a total pump trip they equalize on the looped network (mean |ΔH| ≈ 0.02 m). Occupancies differ by at most one 5 min step. The abstract now states that both tanks reach outlet isolation at 6.2 h without EWM and 10.6 h with EWM (within one step). Table 4 lists both tanks. A check with diameters 0.6× and 1.4× splits Normal occupancy (0.75 h vs 1.33 h) while fail times still differ by <0.6 h because of mesh transfer. That check is not used as the R2.5 storage sweep.",
        "§3.1\n" + M.SEC31 + "\n\n(Table 4 in the revised manuscript.)",
        "不对称算例只在回复出现，不上表6。",
    )

    addp(doc, "We hope the revised manuscript and this point-by-point response meet the standards of ENGINEERING Management.", first=False, before=8)
    addp(doc, "Sincerely,", first=False)
    addp(doc, "The authors", first=False)

    path = os.path.join(OUTD, "Response_to_Reviewers_FEM-2026-0130.docx")
    doc.save(path)
    print("Letter", path)
    return path

if __name__ == "__main__":
    build_ms()
    build_letter()
