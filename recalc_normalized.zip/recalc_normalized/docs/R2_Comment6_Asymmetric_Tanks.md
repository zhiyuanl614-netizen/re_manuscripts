# R2.6 and tank-size design

## Do not replace the main tank sweep

The published sensitivity scales **T1 and T2 together** (0.6×–1.4×). That answers **R2.5**: how EWM depends on *system* storage. It is not meant to answer why the two tanks look alike.

## Optional one-off check for R2.6 (already run)

T1 diameter ×0.6, T2 ×1.4, otherwise the locked base case (λ*=0.12, 24 h outage, Recommendation A).

| | T1 time to H<0.50 m | T2 time to H<0.50 m | Normal-state hours (T1 / T2) |
|--|--:|--:|--|
| Symmetric, no EWM | 30.17 | 30.17 | 2.17 / 2.08 |
| **Asymmetric, no EWM** | **29.50** | **30.08** | **0.75 / 1.33** |
| Symmetric, EWM | 34.58 | 34.58 | 2.17 / 2.08 |
| **Asymmetric, EWM** | **35.42** | **35.67** | **0.75 / 1.50** |

- Occupancy **does** split: the larger tank stays in Normal almost twice as long.  
- Time-to-fail only splits by **0.25–0.58 h**, because the looped network still lets the big tank feed the small tank’s side.  
- EWM’s single network-wide α keeps them closer than the no-EWM arm.

So: similarity in the base table is **identical geometry + hydraulic coupling**, not a copy-paste error. Making sizes different proves the code can separate the tanks; it also shows coupling is strong enough that fail-times will never look like two isolated reservoirs.

## What to do in the paper

1. Keep the **symmetric** diameter sweep in §3.3 / Table 6 (R2.5).  
2. In the R2.6 reply (and one sentence in §3.1): report both tanks; explain coupling; optionally cite this one asymmetric run (*“when diameters are set to 0.6× and 1.4×, Normal occupancy diverges (0.75 h vs 1.33 h) while fail times still differ by less than 0.6 h because of network transfer”*).  
3. Do **not** rebuild the whole sensitivity on a 2-D (D1, D2) grid — that answers a different question and blurs R2.5.

System metrics for the asymmetric run (not for the main table): no EWM \(RI_s=0.26\), \(V_{\mathrm{del}}=1105\,\mathrm{m}^3\); with EWM \(RI_s=0.30\), \(V_{\mathrm{del}}=1740\,\mathrm{m}^3\) (+57%), same story as the symmetric base.
