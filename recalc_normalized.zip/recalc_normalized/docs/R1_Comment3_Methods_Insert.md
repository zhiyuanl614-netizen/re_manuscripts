# R1 Comment 3 — ready-to-paste methods text

Use in §2.2 (assumptions) and §2.3 (thresholds). English for the manuscript; keep the Chinese notes for the authors.

## 2.2 Idealized assumptions and scope (new subsection)

The co-simulation is built to isolate the effect of graded demand management under a total source outage. The following idealizations are therefore adopted. They define an **upper bound** on the benefit of *timely* intervention, not a field SCADA replica.

**Table. Modelling assumptions, practical impact, and mitigation**

| Domain | Idealized assumption | Impact if violated in practice | Engineering mitigation |
|--------|----------------------|--------------------------------|------------------------|
| Sensing | Tank level and pump status are error-free at every 300 s step | Noise/drift can trigger EWM early or late and change \(\alpha\) | Local filtering; redundant level sensors |
| Communications | Zero latency, zero loss between sensors, PLC and demand actuators | Commands delayed by seconds–minutes; missed packets skip a step | Edge evaluation of thresholds on the PLC |
| Actuation | Nodal demand is changed uniformly and instantly via \(\alpha\) | Valve stroke and AMI latency are finite; customers do not shed equally | Pre-armed AMI/PRV emergency routines; priority customers exempt |
| Hydraulics | Quasi-steady EPANET 2.2 PDA snapshots; no transients | Local negative-pressure spikes and filling/emptying of pipes are omitted | Transient checks on critical mains before field use |
| Water quality | Quality does not degrade during low flow | Water age and chlorine decay increase in the Critical state | Cap Critical duration; flush after the event |
| Disturbance | Deterministic total pump trip of prescribed length | Real events may be partial, cascading or uncertain in duration | Duration sweep (12–48 h) already reported |
| Demand process | Published Anytown 8×3 h ADD factors, intensity \(\lambda^\ast=0.12\) | A different peak timing changes how much water is delivered before empty | Shape/intensity kept supplementary; not claimed universal |

Communication delay, packet loss and sensor noise are **out of scope**. The cyber layer is an ideal threshold classifier plus a ratchet, not a networked-control simulation (see also R2.4).

## 2.3 Basis of the five *water-level* states (not pressure grades)

Three distinct quantities must not be conflated:

| Quantity | Role | Basis |
|----------|------|--------|
| 0.10 MPa (≈ 10 m) | *Evaluation only*: emergency service head on the network | GB 50013-2018 (minimum service head for the lowest storey class) |
| \(P_{\mathrm{req}}=20\,\mathrm{m}\) | EPANET PDA: head at which full nodal demand is granted | Solver setting, not a trigger |
| 5.0 / 4.0 / 2.0 / 0.50 m | *Triggers* on **tank water level** | Table below |

**Table. Water-level states**

| State | Tank level | \(\alpha\) | Type of basis | Justification |
|-------|------------|-----------:|---------------|----------------|
| Normal | \(H\ge 5.0\,\mathrm{m}\) | 1.00 | Existing operation | Coincides with the PLC pump-on set-point already in the Anytown controls (\(H\le 5\,\mathrm{m}\) start, \(H\ge 8\,\mathrm{m}\) stop) |
| Warning | \(H<5.0\,\mathrm{m}\) | 0.70 | Existing operation | First emergency cut begins where routine replenishment would already have been requested |
| Alert | \(H<4.0\,\mathrm{m}\) | 0.40 | Engineering partition + trial | Splits the 5.0–0.50 m usable depth into staged windows; 40% retention |
| Critical | \(H<2.0\,\mathrm{m}\) | 0.20 | Engineering partition + trial | Last window before outlet isolation; 20% retention |
| Outlet failure | \(H<0.50\,\mathrm{m}\) | outlet closed | Physical protection | Outlet-crown / anti-vortex submergence; **identical in both arms**, not an EWM decision |

The 4.0 m and 2.0 m cuts are **not** taken from GB 50013-2018 and are not a literature standard. They are a transparent operating partition of usable depth, paired with 70/40/20% demand retention (progressively deeper cuts rather than a single 80% shed at 5 m). A uniform shift \(\Delta H\in[-1.0,+1.0]\,\mathrm{m}\) leaves the 24 h delivered-volume gain positive (+50% to +72%). Intermediate thresholds are therefore a modelling choice, not a unique calibrated optimum.

## Author response (English, R1 Comment 3)

We agree. A dedicated subsection (§2.2, Table 1) now lists the idealizations (error-free sensing; zero communication delay and loss; instantaneous uniform curtailment; quasi-steady PDA; neglected water quality; deterministic total outage) together with their field impact and mitigations. Results are interpreted as an upper bound on timely intervention.

We also clarify that GB 50013-2018 supports only the **0.10 MPa emergency service head** used to interpret network pressure. It does **not** define the five tank-level states. Those states are water-level triggers: 0.50 m is physical outlet submergence; 5.0 m matches the existing PLC pump-on set-point; 4.0 m and 2.0 m partition usable depth and were tested by a \(\pm 1\,\mathrm{m}\) shift (Table 6). The 70/40/20% multipliers are a graded operational policy, not a code prescription.

---

中文备忘：不要把五级写成“风险压力阈值”；4.0/2.0 只能写成运行分段 + 敏感性，不能写成国标。
