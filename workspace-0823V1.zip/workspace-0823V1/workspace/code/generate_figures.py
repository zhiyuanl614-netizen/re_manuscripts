import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Times New Roman', 'Liberation Serif', 'DejaVu Sans']
plt.rcParams['font.serif'] = ['Times New Roman', 'Liberation Serif', 'DejaVu Serif']
plt.rcParams['font.family'] = 'serif'
plt.rcParams['text.color'] = 'black'
plt.rcParams['axes.labelcolor'] = 'black'
plt.rcParams['xtick.color'] = 'black'
plt.rcParams['ytick.color'] = 'black'
import matplotlib.patches as patches
from matplotlib.lines import Line2D
import numpy as np
import sqlite3, pandas as pd
import os
_HERE = os.path.dirname(os.path.abspath(__file__))
FIG_DIR = os.path.join(_HERE, '..', 'figures')
RESULTS_DIR = os.path.join(_HERE, '..', 'results')
os.makedirs(FIG_DIR, exist_ok=True)
C_NORMAL = '#75B956'
C_WARNING = '#AED6F1'
C_ALERT = '#5392CE'
C_CRITICAL = '#B165A6'
C_FAILURE = '#C64C3E'
C_BG = '#F4F6F7'
C_TEXT = '#2C3E50'
C_SHADE = '#D0ECE7'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['axes.edgecolor'] = '#BDC3C7'
plt.rcParams['axes.linewidth'] = 0.8
plt.rcParams['grid.color'] = '#E5E8E8'
plt.rcParams['grid.linestyle'] = '--'
con_no = sqlite3.connect(os.path.join(RESULTS_DIR, 'no_ew.db'))
con_ew = sqlite3.connect(os.path.join(RESULTS_DIR, 'ew.db'))
df_no = pd.read_sql('SELECT timestamp/3600 as time_h, avg_pressure, delivered, required FROM performance_data', con_no)
df_ew = pd.read_sql('SELECT timestamp/3600 as time_h, avg_pressure, delivered, required FROM performance_data', con_ew)
df_sensor_no = pd.read_sql('SELECT timestamp/3600 as time_h, sensor_id, value FROM sensor_data', con_no)
df_sensor_ew = pd.read_sql('SELECT timestamp/3600 as time_h, sensor_id, value FROM sensor_data', con_ew)
con_no.close()
con_ew.close()
df_t1_no = df_sensor_no[df_sensor_no['sensor_id'] == 'T1']
df_t1_ew = df_sensor_ew[df_sensor_ew['sensor_id'] == 'T1']
df_t2_no = df_sensor_no[df_sensor_no['sensor_id'] == 'T2']
df_t2_ew = df_sensor_ew[df_sensor_ew['sensor_id'] == 'T2']
node_coords = {'R': (9.2, 1.2), 'P1': (8.2, 2.0), 'P2': (8.2, 1.2), 'J20': (8.2, 1.2), 'J1': (6.8, 1.2), 'J2': (7.8, 3.2), 'J3': (7.5, 5.0), 'J4': (6.2, 5.2), 'J5': (5.0, 6.2), 'J6': (3.6, 5.8), 'J7': (2.8, 5.5), 'J8': (2.8, 4.2), 'J9': (0.5, 2.8), 'J10': (1.5, 1.2), 'J11': (3.0, 0.5), 'J12': (4.8, 1.2), 'J13': (6.5, 2.2), 'J14': (6.5, 3.5), 'J15': (5.2, 4.2), 'J16': (3.8, 3.2), 'J17': (2.2, 2.2), 'J18': (4.2, 2.2), 'J19': (5.2, 2.8), 'J21': (6.2, 4.2), 'J22': (2.2, 1.5), 'T1': (6.2, 4.7), 'T2': (1.8, 3.2)}
edges = [('R', 'J20'), ('J20', 'J1'), ('J1', 'J2'), ('J1', 'J12'), ('J1', 'J13'), ('J2', 'J3'), ('J2', 'J13'), ('J2', 'J14'), ('J3', 'J4'), ('J4', 'J5'), ('J4', 'J8'), ('J4', 'J15'), ('J4', 'T1'), ('T1', 'J21'), ('J21', 'J14'), ('J5', 'J6'), ('J6', 'J7'), ('J6', 'J8'), ('J7', 'J8'), ('J8', 'J9'), ('J8', 'J15'), ('J8', 'J16'), ('J8', 'J17'), ('J9', 'J10'), ('J10', 'J11'), ('J10', 'J17'), ('J11', 'J12'), ('J12', 'J18'), ('J13', 'J14'), ('J13', 'J19'), ('J14', 'J15'), ('J14', 'J19'), ('J15', 'J16'), ('J15', 'J19'), ('J16', 'J17'), ('J16', 'J18'), ('J17', 'J18'), ('J17', 'J22'), ('J17', 'T2'), ('T2', 'J22'), ('J18', 'J19')]
fig, ax = plt.subplots(figsize=(9, 6), facecolor='#FFFFFF')
ax.set_facecolor('#FFFFFF')
for u, v in edges:
    if u in node_coords and v in node_coords:
        x1, y1 = node_coords[u]
        x2, y2 = node_coords[v]
        ax.plot([x1, x2], [y1, y2], color='#888888', lw=1.2, zorder=1)
for name, (x, y) in node_coords.items():
    if name.startswith('J'):
        ax.scatter(x, y, color='#2F5597', s=70, zorder=3)
        ax.text(x - 0.15, y - 0.25, name, fontsize=8, fontweight='bold', color='#1B365D')
rx, ry = node_coords['R']
ax.scatter(rx, ry, color='#C65911', marker='s', s=100, zorder=4)
ax.text(rx + 0.15, ry, 'R', fontsize=9, fontweight='bold', color='#C65911')
for tank in ['T1', 'T2']:
    tx, ty = node_coords[tank]
    ax.scatter(tx, ty, color='#385723', marker='D', s=100, zorder=4)
    ax.text(tx + 0.2, ty, tank, fontsize=9, fontweight='bold', color='#385723')
px, py = node_coords['P1']
ax.scatter(px, py, color='#555555', marker='o', s=80, facecolors='none', edgecolors='#333333', lw=1.5, zorder=4)
ax.text(px, py + 0.25, 'P1', fontsize=8.5, fontweight='bold', color='#333333')
px2, py2 = node_coords['P2']
ax.scatter(px2, py2, color='#555555', marker='o', s=80, facecolors='none', edgecolors='#333333', lw=1.5, zorder=4)
ax.text(px2, py2 - 0.35, 'P2', fontsize=8.5, fontweight='bold', color='#333333')
legend_elements = [Line2D([0], [0], marker='o', color='w', label='Demand Nodes', markerfacecolor='#2F5597', markersize=8), Line2D([0], [0], marker='s', color='w', label='Reservoir', markerfacecolor='#C65911', markersize=9), Line2D([0], [0], marker='D', color='w', label='Tanks', markerfacecolor='#385723', markersize=9), Line2D([0], [0], marker='o', color='w', label='Pumps', markerfacecolor='none', markeredgecolor='#333333', markeredgewidth=1.5, markersize=8)]
ax.legend(handles=legend_elements, loc='upper right', frameon=True, facecolor='#FFFFFF', edgecolor='#BDC3C7', fontsize=8.5)
ax.set_xlim(-0.2, 10.2)
ax.set_ylim(-0.2, 6.8)
ax.axis('off')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig1.png'), dpi=300, bbox_inches='tight')
plt.close()
fig, ax = plt.subplots(figsize=(9, 7.2), facecolor=C_BG)
ax.set_facecolor(C_BG)
ax.set_xlim(0, 10)
ax.set_ylim(0, 9.5)
ax.axis('off')
box_cyber_bg = patches.FancyBboxPatch((0.5, 6.4), 9.0, 2.7, boxstyle='round,pad=0.1', fc='#D9E1F2', ec='#8FAADC', lw=1.5, ls='--')
ax.add_patch(box_cyber_bg)
ax.text(5.0, 8.8, 'Cyber Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='#1B365D')
box_scada = patches.FancyBboxPatch((1.2, 6.7), 3.4, 1.8, boxstyle='round,pad=0.1', fc='#2F5597', ec='#1B365D', lw=1.5)
ax.add_patch(box_scada)
ax.text(2.9, 8.1, 'SCADA Server', ha='center', va='center', fontsize=10, fontweight='bold', color='#FFFFFF')
ax.text(2.9, 7.3, '• Risk Classification\n• Graded Early Warning\n• Fast Cyber Sensing (300 s)', ha='left', va='center', fontsize=8.5, color='#FFFFFF')
box_plc = patches.FancyBboxPatch((5.4, 6.7), 3.4, 1.8, boxstyle='round,pad=0.1', fc='#2F5597', ec='#1B365D', lw=1.5)
ax.add_patch(box_plc)
ax.text(7.1, 8.1, 'PLC Network', ha='center', va='center', fontsize=10, fontweight='bold', color='#FFFFFF')
ax.text(7.1, 7.3, '• Tank PLCs\n• Pump PLCs\n• Junction PLCs', ha='left', va='center', fontsize=8.5, color='#FFFFFF')
ax.annotate('', xy=(5.4, 7.7), xytext=(4.6, 7.7), arrowprops=dict(arrowstyle='->', lw=1.2, color='#FFFFFF'))
ax.annotate('', xy=(4.6, 7.1), xytext=(5.4, 7.1), arrowprops=dict(arrowstyle='->', lw=1.2, color='#FFFFFF'))
box_coup_bg = patches.FancyBboxPatch((0.5, 3.4), 9.0, 2.5, boxstyle='round,pad=0.1', fc='#E2EFDA', ec='#A9D18E', lw=1.5, ls='--')
ax.add_patch(box_coup_bg)
ax.text(5.0, 5.5, 'Coupling Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='#274E13')
box_m1 = patches.FancyBboxPatch((1.0, 3.7), 3.8, 1.5, boxstyle='round,pad=0.1', fc='#FFFFFF', ec='#385723', lw=1.2)
ax.add_patch(box_m1)
ax.text(2.9, 4.45, '• State Mapping (H, P → Risk Levels)\n• Temporal Buffer Generation\n• Warning / Alert / Critical Buffer Zones', ha='left', va='center', fontsize=8.0, color='#274E13')
box_m2 = patches.FancyBboxPatch((5.2, 3.7), 3.8, 1.5, boxstyle='round,pad=0.1', fc='#FFFFFF', ec='#385723', lw=1.2)
ax.add_patch(box_m2)
ax.text(7.1, 4.45, '• Graceful Degradation Mechanism\n• Closed-loop Feedback Control\n• Ratchet Anti-chatter Logic', ha='left', va='center', fontsize=8.0, color='#274E13')
box_phys_bg = patches.FancyBboxPatch((0.5, 0.3), 9.0, 2.5, boxstyle='round,pad=0.1', fc='#FCE4D6', ec='#F4B183', lw=1.5, ls='--')
ax.add_patch(box_phys_bg)
ax.text(5.0, 2.4, 'Physical Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='#833C0C')
box_p1 = patches.FancyBboxPatch((1.0, 0.6), 3.8, 1.2, boxstyle='round,pad=0.1', fc='#C65911', ec='#833C0C', lw=1.2)
ax.add_patch(box_p1)
ax.text(2.9, 1.4, 'Hydraulic Degradation Process', ha='center', va='center', fontsize=9, fontweight='bold', color='#FFFFFF')
ax.text(2.9, 0.9, '• Tank Level (H) ↓ → Pressure (P) ↓', ha='center', va='center', fontsize=8.0, color='#FFFFFF')
box_p2 = patches.FancyBboxPatch((5.2, 0.6), 3.8, 1.2, boxstyle='round,pad=0.1', fc='#C65911', ec='#833C0C', lw=1.2)
ax.add_patch(box_p2)
ax.text(7.1, 1.4, 'Physical Buffer', ha='center', va='center', fontsize=9, fontweight='bold', color='#FFFFFF')
ax.text(7.1, 0.9, '• Tank Storage  • Pipeline Residual Water', ha='center', va='center', fontsize=8.0, color='#FFFFFF')
ax.annotate('Sensing Dependency', xy=(5.0, 6.4), xytext=(5.0, 5.9), ha='center', va='center', fontsize=8.5, fontweight='bold', color='#1B365D', arrowprops=dict(arrowstyle='<->', lw=1.5, color='#2F5597'))
ax.annotate('Warning Dependency', xy=(5.0, 3.4), xytext=(5.0, 2.8), ha='center', va='center', fontsize=8.5, fontweight='bold', color='#833C0C', arrowprops=dict(arrowstyle='<->', lw=1.5, color='#C65911'))
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig2.png'), dpi=300, bbox_inches='tight')
plt.close()
fig, ax = plt.subplots(figsize=(8.5, 7.2), facecolor=C_BG)
ax.set_facecolor(C_BG)
ax.set_xlim(0, 10)
ax.set_ylim(0, 9.5)
ax.axis('off')
box_top_hdr = patches.Rectangle((0.5, 8.5), 9.0, 0.7, fc='#2F5597', ec='#1B365D', lw=1.2)
box_top_body = patches.Rectangle((0.5, 6.5), 9.0, 2.0, fc='#B4C6E7', ec='#1B365D', lw=1.2)
ax.add_patch(box_top_body)
ax.add_patch(box_top_hdr)
ax.text(5.0, 8.85, 'Cyber SCADA Module (Decision Layer)', ha='center', va='center', fontsize=11, fontweight='bold', color='#FFFFFF')
ax.text(1.0, 7.5, '• Real-time State Acquisition (H, P)\n• Pressure Trend Monitoring (300 s)\n• Status Transition Detection\n• Temporal Buffer Calculation', ha='left', va='center', fontsize=8.5, color='#1B365D')
ax.text(5.5, 7.5, '• Graded Risk Classification\n  - Normal\n  - Warning\n  - Alert\n  - Critical\n  - Outlet Failure', ha='left', va='center', fontsize=8.5, color='#1B365D')
box_mid_hdr = patches.Rectangle((0.5, 5.4), 9.0, 0.6, fc='#385723', ec='#274E13', lw=1.2)
box_mid_body = patches.Rectangle((0.5, 3.5), 9.0, 1.9, fc='#A9D18E', ec='#274E13', lw=1.2)
ax.add_patch(box_mid_body)
ax.add_patch(box_mid_hdr)
ax.text(5.0, 5.7, 'Synchronization Database Layer (SQLite)', ha='center', va='center', fontsize=11, fontweight='bold', color='#FFFFFF')
box_db1 = patches.Rectangle((0.8, 3.7), 2.5, 1.5, fc='#C6E0B4', ec='#385723', lw=1)
ax.add_patch(box_db1)
ax.text(2.05, 4.45, '• Physical State Table\n  - Tank Levels (H)\n  - Nodal Pressures (P)\n  - Flow Rates (Q)', ha='center', va='center', fontsize=7.5, color='#274E13')
box_db2 = patches.Rectangle((3.6, 3.7), 2.8, 1.5, fc='#C6E0B4', ec='#385723', lw=1)
ax.add_patch(box_db2)
ax.text(5.0, 4.45, '• Event & Transition Log\n  - Risk Level Changes\n  - Timestamp Records\n  - Duration of Each State', ha='center', va='center', fontsize=7.5, color='#274E13')
box_db3 = patches.Rectangle((6.7, 3.7), 2.5, 1.5, fc='#C6E0B4', ec='#385723', lw=1)
ax.add_patch(box_db3)
ax.text(7.95, 4.45, 'Temporal Buffer & Metrics\nDual Resilience Metrics\n(T_press, R_w)', ha='center', va='center', fontsize=7.5, color='#274E13')
box_bot_hdr = patches.Rectangle((0.5, 2.4), 9.0, 0.6, fc='#C65911', ec='#833C0C', lw=1.2)
box_bot_body = patches.Rectangle((0.5, 0.3), 9.0, 2.1, fc='#F8CBAD', ec='#833C0C', lw=1.2)
ax.add_patch(box_bot_body)
ax.add_patch(box_bot_hdr)
ax.text(5.0, 2.7, 'Physical Simulation Module', ha='center', va='center', fontsize=11, fontweight='bold', color='#FFFFFF')
box_wntr = patches.Rectangle((0.8, 0.5), 2.2, 1.7, fc='#F2F2F2', ec='#833C0C', lw=1)
ax.add_patch(box_wntr)
ax.text(1.9, 1.6, 'WNTR / EPANET 2.2\n(300 s timestep)', ha='center', va='center', fontsize=8, fontweight='bold', color='#833C0C')
ax.annotate('', xy=(1.9, 0.8), xytext=(1.9, 1.3), arrowprops=dict(arrowstyle='->', lw=1.5, color='#C65911'))
ax.text(1.9, 0.65, 'PDA Hydraulics', ha='center', va='center', fontsize=7.5, color='#833C0C')
ax.text(4.5, 1.3, '• Governing Equations\n• Source Interruption Scenario (24-48 h)\n• Hydraulic Degradation Process', ha='left', va='center', fontsize=8, color='#833C0C')
ax.text(7.5, 1.3, '• Outputs\n  - Tank Water Levels (H)\n  - Nodal Pressures (P)\n  - Flow Rates (Q)', ha='left', va='center', fontsize=8, color='#833C0C')
ax.annotate('', xy=(3.0, 6.1), xytext=(3.0, 6.5), arrowprops=dict(arrowstyle='->', lw=2, color='#385723'))
ax.annotate('', xy=(7.0, 6.5), xytext=(7.0, 6.1), arrowprops=dict(arrowstyle='->', lw=2, color='#2F5597'))
ax.annotate('', xy=(3.0, 3.0), xytext=(3.0, 3.5), arrowprops=dict(arrowstyle='->', lw=2, color='#C65911'))
ax.annotate('', xy=(7.0, 3.5), xytext=(7.0, 3.0), arrowprops=dict(arrowstyle='->', lw=2, color='#385723'))
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig3.png'), dpi=300, bbox_inches='tight')
plt.close()
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 7.8), facecolor=C_BG, gridspec_kw={'height_ratios': [1.1, 1]})
ax1.set_facecolor(C_BG)
ax2.set_facecolor(C_BG)
t_hrs = df_t1_no['time_h'].values

def classify_state(h):
    if h >= 5.0:
        return 'Normal'
    if h >= 3.5:
        return 'WARNING'
    if h >= 2.0:
        return 'ALERT'
    if h >= 0.5:
        return 'CRITICAL'
    return 'Outlet Failure'
state_colors = {'Normal': '#75B956', 'WARNING': '#AED6F1', 'ALERT': '#5392CE', 'CRITICAL': '#B165A6', 'Outlet Failure': '#C64C3E'}
t1_no_vals = df_t1_no['value'].values
t1_ew_vals = df_t1_ew['value'].values
t2_no_vals = df_t2_no['value'].values
t2_ew_vals = df_t2_ew['value'].values
y_positions = [4, 3, 2, 1]
y_labels = ['T2 - With EWM', 'T2 - Without EWM', 'T1 - With EWM', 'T1 - Without EWM']
series_data = [t2_ew_vals, t2_no_vals, t1_ew_vals, t1_no_vals]
for idx, (y_pos, vals) in enumerate(zip(y_positions, series_data)):
    for i in range(len(t_hrs) - 1):
        st = classify_state(vals[i])
        c = state_colors[st]
        ax1.barh(y_pos, width=t_hrs[i + 1] - t_hrs[i], left=t_hrs[i], height=0.55, color=c, edgecolor='none')
ax1.set_yticks(y_positions)
ax1.set_yticklabels(y_labels, fontsize=8.5, fontweight='bold', color='black')
ax1.set_xlim(0, 72)
ax1.set_ylim(0.2, 6.4)
ax1.set_xlabel('Time (h)', fontsize=9, fontweight='bold', color='black')
ax1.text(-0.06, 1.05, '(a)', transform=ax1.transAxes, fontsize=11, fontweight='bold', color='black')
ax1.axvline(24, color='#2F5597', linestyle='-', lw=1.2, alpha=0.35)
ax1.axvline(48, color='#2F5597', linestyle='-', lw=1.2, alpha=0.35)
ax1.text(24, 0.45, 'Start (24h)', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#1F3A5F')
ax1.text(48, 0.45, 'End (48h)', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#1F3A5F')
legend_patches = [patches.Patch(color=state_colors['Normal'], label='Normal (≥ 5.0 m)'), patches.Patch(color=state_colors['WARNING'], label='WARNING (3.5–5.0 m)'), patches.Patch(color=state_colors['ALERT'], label='ALERT (2.0–3.5 m)'), patches.Patch(color=state_colors['CRITICAL'], label='CRITICAL (0.5–2.0 m)'), patches.Patch(color=state_colors['Outlet Failure'], label='Outlet Failure (< 0.5 m)')]
ax1.legend(handles=legend_patches, loc='upper left', ncol=1, fontsize=8, framealpha=0.95, edgecolor='#BDC3C7')
states_keys = ['Normal', 'WARNING', 'ALERT', 'CRITICAL', 'Outlet Failure']

def compute_durations(df_series):
    seg = df_series[(df_series['time_h'] >= 24.0) & (df_series['time_h'] < 48.0)]
    dur = {k: 0.0 for k in states_keys}
    for v in seg['value']:
        dur[classify_state(v)] += 300 / 3600.0
    return [dur[k] for k in states_keys]
durations_data = {'T1 Without EWM': compute_durations(df_t1_no), 'T1 With EWM': compute_durations(df_t1_ew), 'T2 Without EWM': compute_durations(df_t2_no), 'T2 With EWM': compute_durations(df_t2_ew)}
x_cats = ['T1\nWithout EWM', 'T1\nWith EWM', 'T2\nWithout EWM', 'T2\nWith EWM']
bottoms = np.zeros(4)
bar_width = 0.45
x_pos = [1, 2, 3.2, 4.2]
for state_idx, st in enumerate(states_keys):
    vals = [durations_data[k][state_idx] for k in ['T1 Without EWM', 'T1 With EWM', 'T2 Without EWM', 'T2 With EWM']]
    c = state_colors[st]
    bars = ax2.bar(x_pos, vals, bottom=bottoms, width=bar_width, color=c, edgecolor='white', lw=0.5, label=st)
    for b_idx, (p, v, b) in enumerate(zip(x_pos, vals, bottoms)):
        if v >= 0.5:
            ax2.text(p, b + v / 2.0, f'{v:.2f}h', ha='center', va='center', fontsize=7.5, color='white' if st in ['Normal', 'ALERT', 'CRITICAL', 'Outlet Failure'] else 'black', fontweight='bold')
    bottoms += np.array(vals)
ax2.set_xticks(x_pos)
ax2.set_xticklabels(x_cats, fontsize=8.5, fontweight='bold', color='black')
ax2.set_ylabel('Duration (h)', fontsize=9, fontweight='bold', color='black')
ax2.text(-0.06, 1.05, '(b)', transform=ax2.transAxes, fontsize=11, fontweight='bold', color='black')
ax2.set_ylim(0, 32)
ax2.legend(loc='upper right', ncol=2, fontsize=8, framealpha=0.95, edgecolor='#BDC3C7')
ax2.axhline(24.0, color='#888888', linestyle=':', lw=1)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig4.png'), dpi=300, bbox_inches='tight')
plt.close()
M_TO_MPA = 0.00980665
fig, ax = plt.subplots(figsize=(9, 4.8), facecolor='#FFFFFF')
ax.set_facecolor('#FFFFFF')
ax.plot(df_no['time_h'], df_no['avg_pressure'] * M_TO_MPA, '-', color='#C64C3E', lw=2, label='Without EWM')
ax.plot(df_ew['time_h'], df_ew['avg_pressure'] * M_TO_MPA, '-', color='#2E86C1', lw=2, label='With EWM')
ax.axhline(0.1, color='#2F5597', linestyle='--', lw=1.4, label='Critical Pressure (0.10 MPa)')
ax.axvspan(24, 48, color='#D0ECE7', alpha=0.5, label='Water-source outage (24-48 h)')
ax.set_xlabel('Time (h)', fontsize=10, fontweight='bold', color='black')
ax.set_ylabel('Network Average Pressure (MPa)', fontsize=10, fontweight='bold', color='black')
ax.set_xlim(0, 72)
ax.set_ylim(0, None)
ax.grid(True, color='#E5E8E8', linestyle='--')
ax.legend(loc='upper right', fontsize=9, framealpha=0.95, edgecolor='#BDC3C7')
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig5.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig5.png generated')
DB_NO = os.path.join(RESULTS_DIR, 'no_ew.db')
DB_EW = os.path.join(RESULTS_DIR, 'ew.db')

def _metric_map(db_path):
    con = sqlite3.connect(db_path)
    frame = pd.read_sql('SELECT metric, value FROM resilience_metrics', con)
    con.close()
    return dict(zip(frame['metric'], frame['value']))
m_no = _metric_map(DB_NO)
m_ew = _metric_map(DB_EW)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.8), facecolor='#FFFFFF')
width = 0.34
x1 = np.arange(1)
no_r_w = [m_no['R_w']]
ew_r_w = [m_ew['R_w']]
ax1.bar(x1 - width / 2, no_r_w, width, color='#D98880', label='Without EWM')
ax1.bar(x1 + width / 2, ew_r_w, width, color='#5DADE2', label='With EWM')
ax1.set_xticks(x1)
ax1.set_xticklabels(['R$_w$'])
ax1.set_ylabel('Standardized service resilience (-)', fontweight='bold')
ax1.set_ylim(0, 1.0)
ax1.grid(axis='y', color='#E5E8E8', linestyle='--')
ax1.legend(fontsize=8)
ax1.set_title('(a) Service-value dimension: R$_w$', fontweight='bold')
for xpos, value in zip(x1 - width / 2, no_r_w):
    ax1.text(xpos, value + 0.02, f'{value:.3f}', ha='center', fontsize=9)
for xpos, value in zip(x1 + width / 2, ew_r_w):
    ax1.text(xpos, value + 0.02, f'{value:.3f}', ha='center', fontsize=9)
x2 = np.arange(1)
no_t = [m_no['T_press_h']]
ew_t = [m_ew['T_press_h']]
ax2.bar(x2 - width / 2, no_t, width, color='#D98880', label='Without EWM')
ax2.bar(x2 + width / 2, ew_t, width, color='#5DADE2', label='With EWM')
ax2.set_xticks(x2)
ax2.set_xticklabels(['T$_{press}$'])
ax2.set_ylabel('Effective service duration (h)', fontweight='bold')
ax2.grid(axis='y', color='#E5E8E8', linestyle='--')
ax2.legend(fontsize=8)
ax2.set_title('(b) Temporal dimension: T$_{press}$', fontweight='bold')
for xpos, value in zip(x2 - width / 2, no_t):
    ax2.text(xpos, value + 0.2, f'{value:.2f} h', ha='center', fontsize=9)
for xpos, value in zip(x2 + width / 2, ew_t):
    ax2.text(xpos, value + 0.2, f'{value:.2f} h', ha='center', fontsize=9)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'Fig6.png'), dpi=300, bbox_inches='tight')
plt.close()
print('Fig6.png generated (two-metric base-case summary)')
PA_DIR = RESULTS_DIR

def _read_sensitivity(name):
    return pd.read_csv(os.path.join(PA_DIR, name))

def _error_range(frame, column):
    center = frame[column].to_numpy(dtype=float)
    low = frame[column + '_lo'].to_numpy(dtype=float)
    high = frame[column + '_hi'].to_numpy(dtype=float)
    return np.vstack((center - low, high - center))
required_csv = ['sensitivity_threshold.csv', 'sensitivity_diameter.csv', 'sensitivity_duration.csv', 'sensitivity_load.csv']
ready = all((os.path.exists(os.path.join(PA_DIR, name)) for name in required_csv))
if ready:
    threshold = _read_sensitivity('sensitivity_threshold.csv')
    diameter = _read_sensitivity('sensitivity_diameter.csv')
    duration = _read_sensitivity('sensitivity_duration.csv')
    load = _read_sensitivity('sensitivity_load.csv')
    diameter['x'] = diameter['key'].astype(float)
    duration['x'] = duration['key'].astype(float)
    load['x'] = load['key'].astype(float)
    expected = {f'{metric}_{scenario}{suffix}' for metric in ('t_press',) for scenario in ('no', 'ew') for suffix in ('', '_lo', '_hi')}
    for name, frame in [('threshold', threshold), ('diameter', diameter), ('duration', duration), ('load', load)]:
        missing = expected.difference(frame.columns)
        if missing:
            raise ValueError(f'{name}.csv is stale or incomplete; missing: {sorted(missing)}')
    panels = [(np.arange(len(threshold)), threshold, 'Threshold design', np.arange(len(threshold)), threshold['key'].astype(str).tolist()), (diameter['x'], diameter, 'Tank diameter scale', None, None), (duration['x'], duration, 'Outage duration (h)', None, None), (load['x'], load, 'Relative demand load', None, None)]

    def plot_metric_figure(metric, ylabel, filename, ylim=None):
        fig, axes = plt.subplots(2, 2, figsize=(12, 8.5), facecolor='#FFFFFF')
        labels = ['(a)', '(b)', '(c)', '(d)']
        for ax, panel, label in zip(axes.flat, panels, labels):
            xvals, frame, xlabel, ticks, ticklabels = panel
            ax.errorbar(xvals, frame[f'{metric}_no'], yerr=_error_range(frame, f'{metric}_no'), fmt='o--', color='#C64C3E', lw=2, ms=6, capsize=4, label='Without EWM')
            ax.errorbar(xvals, frame[f'{metric}_ew'], yerr=_error_range(frame, f'{metric}_ew'), fmt='s-', color='#2E86C1', lw=2, ms=6, capsize=4, label='With EWM')
            if ticks is not None:
                ax.set_xticks(ticks)
                ax.set_xticklabels(ticklabels)
            ax.set_xlabel(xlabel, fontsize=10, fontweight='bold')
            ax.set_ylabel(ylabel, fontsize=10, fontweight='bold')
            ax.set_title(f'{label} {xlabel}', fontsize=11, fontweight='bold')
            ax.grid(True, color='#E5E8E8', linestyle='--')
            if ylim is not None:
                ax.set_ylim(*ylim)
        axes.flat[0].legend(loc='best', fontsize=8, framealpha=0.95)
        plt.tight_layout()
        plt.savefig(os.path.join(FIG_DIR, filename), dpi=300, bbox_inches='tight')
        plt.close()
        print(f'{filename} generated ({metric} sensitivity)')
    plot_metric_figure('t_press', 'Effective service duration T$_{press}$ (h)', 'Fig7.png')
else:
    print('Latest phase_avg CSVs are missing; skipped Fig7.')


_REQUIRED_RAW = ['sensitivity_threshold_raw.csv', 'sensitivity_diameter_raw.csv', 'sensitivity_duration_raw.csv', 'sensitivity_load_raw.csv']
if all(os.path.exists(os.path.join(RESULTS_DIR, name)) for name in _REQUIRED_RAW):
    raw_threshold = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_threshold_raw.csv'), encoding='utf-8-sig')
    raw_diameter = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_diameter_raw.csv'), encoding='utf-8-sig')
    raw_duration = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_duration_raw.csv'), encoding='utf-8-sig')
    raw_load = pd.read_csv(os.path.join(RESULTS_DIR, 'sensitivity_load_raw.csv'), encoding='utf-8-sig')


    def _phase0(frame):
        sub = frame[frame['phase'] == 0].copy()
        sub['x'] = sub['key'].astype(float) if frame is not raw_threshold else sub['key'].astype(str)
        no = sub[sub['mode'] == 'no'].sort_values('x')
        ew = sub[sub['mode'] == 'ew'].sort_values('x')
        return no, ew


    fig, axes = plt.subplots(2, 2, figsize=(12, 8.5), facecolor='#FFFFFF')
    _raw_panels = [(_phase0(raw_threshold), 'Threshold design', np.arange(5), raw_threshold['key'].astype(str).drop_duplicates().tolist()), (_phase0(raw_diameter), 'Tank diameter scale', None, None), (_phase0(raw_duration), 'Outage duration (h)', None, None), (_phase0(raw_load), 'Relative demand load', None, None)]
    _raw_labels = ['(a)', '(b)', '(c)', '(d)']
    for ax, ((no, ew), xlabel, ticks, ticklabels), label in zip(axes.flat, _raw_panels, _raw_labels):
        ax.plot(no['x'], no['t_press'], 'o--', color='#C64C3E', lw=2, ms=7, label='Without EWM')
        ax.plot(ew['x'], ew['t_press'], 's-', color='#2E86C1', lw=2, ms=7, label='With EWM')
        if ticks is not None:
            ax.set_xticks(ticks)
            ax.set_xticklabels(ticklabels)
        ax.set_xlabel(xlabel, fontsize=10, fontweight='bold')
        ax.set_ylabel('Effective service duration T$_{press}$ (h)', fontsize=10, fontweight='bold')
        ax.set_title(f'{label} {xlabel}', fontsize=11, fontweight='bold')
        ax.grid(True, color='#E5E8E8', linestyle='--')
    axes.flat[0].legend(loc='best', fontsize=8, framealpha=0.95)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'Fig8.png'), dpi=300, bbox_inches='tight')
    plt.close()
    print('Fig8.png generated (t_press sensitivity, canonical alignment, no phase aggregation)')
else:
    print('Raw sensitivity CSVs are missing; skipped Fig8.')
