# FEM-2026-0130 返修工作空间(分类子文件夹结构 · 现行状态总览)

> 更新日期:2026-08-23(第5次整理:分类子文件夹) | 稿件:*Proactive Resilience of Urban Water
> Supply Cyber-Physical Systems under Extreme Water Network Malfunctions: An Early Warning
> Management Perspective* | 期刊:ENGINEERING Management | 返修截止:2026-09-14

## 一、现行口径(三项核心决策)

| 决策 | 内容 |
|---|---|
| **① 韧性指标 = 仅两项(方法已定格)** | **T_press (h)**(时间域)+ **R_w = W/(S*·α_max)**(价值域,2026-08-23 定格V3形态:锚=蓄量×最大时段权重,运行时逐情景计算;**w_j≡1 预留用户优先级窗口**;贪婪分配U_max=1491.85已废除)。RI_p、ΔT_iso、P_cov、RIv等已移除 |
| **② 敏感性分析 = 仅 T_press** | R_w 只作基准案例指标,**不做敏感性分析**;sensitivity_*.csv 仅含 t_press 列;敏感性图仅 Fig7 |
| **③ EWM = 仅原 D3 三级棘轮** | WARNING/ALERT/CRITICAL = 5.0/3.5/2.0 m,γ∈{0.70, 0.40, 0.20},单向棘轮。自适应方案已彻底移除 |

## 二、当前权威数值

**基准案例(故障@24h,24–48h窗口)**

| 指标 | No-EWM | EWM(D3) | 变化 |
|---|---|---|---|
| T_press | 6.17 h | 10.33 h | **+67.6%** |
| W 加权服务量(等效m³) | 745.3 | 916.2 | +22.9% |
| **R_w = W/(S*·α_max)** | **0.496** | **0.609** | **+23.0%** |
| 出口隔离时刻(物理事件) | 30.17 h | 34.33 h | 推迟 4.17 h |

方法定格参数(运行时捕获,入库可审计):S* = 1156.44 m³、α_max = 1.30、价值天花板 = 1503.37 m³·pattern;两情景共享同一锚。

**T_press 相位平均(4相位,敏感性口径)**:4.27 → 9.40 h(增益≈+5.1 h,全部维度为正)。
水量守恒审计 η≈1.0006(Vdel 1,095.2→1,088.3 m³,−0.6%:EWM 不造水,只重分配时机)。

## 三、目录导航(一级 workspace + 分类子文件夹)

```
workspace/
├── README.md        ← 本文件(现行状态单一入口)
├── code/            # 仿真代码
│   ├── sim_main.py                 # 主仿真:CPS步进闭环、水力求解、T_press与R_w计算
│   ├── demand_patterns.py          # Anytown 8×3h需水模式(唯一基准模式)
│   ├── generate_figures.py         # 绘图:生成Fig1–7(输出至figures/)
│   └── sensitivity_analysis_v2.py  # T_press×4维×4相位敏感性(输出至results/)
├── data/
│   └── anytown.inp                 # 修正后的Anytown基准管网(PDA模式)
├── results/                        # 仅保留权威结果
│   ├── no_ew.db / ew.db            # 基准仿真数据库(resilience_metrics表=权威数值)
│   ├── sensitivity_threshold/diameter/duration/load.csv  # 4相位平均敏感性(仅t_press列)
│   └── sensitivity_*_raw.csv             # 264次逐次原始值(Fig8数据源)
├── figures/                        # Fig1–8(已生成,含Fig8单纯敏感性图)
├── documents/
│   ├── 00_指标统一与勘误方案.md     # 历史文档:勘误裁决记录(内文路径为历史布局)
│   ├── 02_方法定格与R2稿件数值映射.md  # ★ 改稿总对照表(方法摘要/数值演化/摘要结论替换段/引用/图件映射)
│   ├── Revised_Section_2.5_Methods_EN.md   # 稿件章节:双指标定义
│   ├── Revised_Section_3_Results_EN.md     # 稿件章节:结果(基准+T_press敏感性)
│   ├── Revised_Section_4_Discussion_EN.md  # 稿件章节:讨论
│   ├── Response_Letter_Part2.md            # 审稿答复Part2(R2-C5~C8)
│   └── 4份原始PDF                          # 返修意见/原投稿/R1定稿/详细答复信
└── .local/          # 随包wntr 1.5.0运行环境(PYTHONPATH指向)
```

## 四、快速复现

```bash
cd workspace/code
export PYTHONPATH=/home/user/workspace/.local/lib/python3.13/site-packages   # 随包 wntr 1.5.0
python3 sim_main.py                  # 基准:T_press 6.1667→10.3333 h;R_w 0.4996→0.6141 → results/
python3 generate_figures.py          # 重新生成 Fig1–7 → figures/
python3 sensitivity_analysis_v2.py   # T_press敏感性(约30分钟)→ results/(脚本路径均为自身位置相对,任意cwd可运行)
```

依赖:`pip install wntr numpy pandas matplotlib`

## 五、指标解读要点(写作时注意)

1. **T_press 承担鲁棒性声明**:4个敏感性维度(阈值D1–D5/直径0.6–1.4×/时长12–48 h/负载
   0.6–1.4×)、全部水平上EWM增益为正(相位平均增益稳定≈+5.1 h)。
2. **R_w 仅报告基准值**(0.496→0.609,+22.9%),并在文中说明其对齐依赖性:基线自身R_w随
   故障起始相位在0.50–0.88间波动(V3逐情景锚实测),相位平均增益+1.1%;管理策略的本质是
   消除该方差并提升均值(§3.2末句已交代)。
3. **R_w 跨情景不做比较**(U_max 情景化规则见 §2.5)。
4. 总供水量不变是**特性而非缺陷**——直接回应R2-C3"保压≠供水"(水量收支论证见00号文档§四)。

## 六、关键标定参数(供复核)

*   **应急水头**:P_min = 0.10 MPa(约10.2 m),GB 50013-2018。
*   **需水块**:`[0.7, 0.6, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9]`(均值1.0,峰值1.30@09–12h)。
*   **水箱物理储量**:约1,156.4 m³(故障起始24h水位T1=7.625 m、T2=7.338 m,至最小水位0.05 m)。
*   **R_w锚(V3形态)**:S*·α_max = 1156.44×1.30 ≈ 1503.37 m³·pattern(全部蓄量供在
    最高价值时段的上限;W ≤ V_del·α_max ≤ S*·α_max 一行证明保证 R_w≤1);
    **w_j≡1**(所有节点,预留用户优先级研究窗口:医院/消防节点可设w_j>1,公式与代码零改动)。
*   **EWM触发(D3对称基线)**:WARNING<5.0 m→γ=0.70;ALERT<3.5 m→γ=0.40;
    CRITICAL<2.0 m→γ=0.20;OUTLET FAILURE<0.50 m→关阀;单向棘轮防抖。

## 七、验证记录

*   两指标重构、冗余清除、目录拍平三次变更后重跑,数值**逐位不变**:
    T_press 6.1667/10.3333 h,R_w 0.4996/0.6141;历史MD5(五指标时代):
    `no_ew.db 0fca7c75…`、`ew.db ba90f713…`。
*   sensitivity_*.csv 剥列(r_w 移除)后 t_press 数值与剥前逐位一致
    (仿真确定性已由 MD5 验证保证)。
*   质量守恒审计:水箱放出量 vs 节点实收量,两情景 η=1.0006。

## 八、变更记录

| 日期 | 变更 |
|---|---|
| 2026-08-23(1) | 解压 workspace-0822v2;裁决三代指标矛盾,统一权威数值(见00号历史文档) |
| 2026-08-23(2) | 指标精简为 T_press+R_w;EWM 暂保留 D3(自适应方案归档);图件 Fig1–8 |
| 2026-08-23(3) | 敏感性仅保留 T_press;自适应 EWM 彻底移除;代码净化(死导入/遗留参数/RIv遗留块/未用模式);图件精简 Fig1–7 |
| 2026-08-23(4) | 目录拍平尝试(后经第5次整理取代) |
| 2026-08-23(5) | **本次**:确立"一级workspace+分类子文件夹"结构——code/(代码)、data/(输入)、results/(仿真结果)、figures/(图件)、documents/(文档与原始PDF);脚本路径改为脚本位置相对;重跑复现值逐位不变 |
| 2026-08-23(10) | **修改稿文档同步(V3)**:§2.5重写(R_w=W/(S*·α_max),w_j≡1优先级窗口,锚一句话化);§3.2更新数值并补V3口径逐相位R_w实测(基线0.496–0.878,相位均值+1.1%);§3.3纳入Fig8双图口径;§4.2/4.4写入目标句+Yu et al.(2024 Nat.Commun.)引用;答复信R2-C7数值更新;新增《02_方法定格与R2稿件数值映射.md》(含摘要/结论整段EN替换文本) |
| 2026-08-23(9) | **本次**:敏感性脚本新增逐相位原始值导出(`sensitivity_*_raw.csv`,264次仿真重跑,均值/原始值均逐位复现);新增**Fig8单纯敏感性图**(规范对齐相位,无四相平均/最大/最小,基点6.17→10.33与Fig6一致) |
| 2026-08-23(8) | **方法定格(V3)**:R_w分母由固定U_max(1491.85,贪婪最优,情景错位时R_w>1)改为**运行时计算的价值天花板S*·α_max**;w_j≡1显式保留;新增S*/α_max/ceiling审计行入库;重跑基准(T_press逐位不变,R_w=0.4957/0.6094)与全部264次敏感性(t_press十二抽查点逐位一致);Fig1–7全部重新生成 |
| 2026-08-23(7) | 主程序全面检验:pyflakes静态分析(修复generate_figures.py两处未用导入、移除sim_main.py死方法write_metric);逐类人工逻辑审查(故障窗/棘轮/阀门隔离/步进求解/指标积分)无功能性错误;**移除全部注释与文档字符串**(AST法,字符串字面量零误伤);净化后四项运行验证全过:pyflakes清洁、基准仿真逐位复现(T_press 6.1667/10.3333,R_w 0.4996/0.6141)、敏感性模块导入正常、绘图管线输出Fig1–7(验证后已清除,figures/保持空) |
| 2026-08-23(6) | **本次**:内容精简——figures/清空全部图片(保留空文件夹,图件可由`generate_figures.py`随时重生成);documents/移除4份PDF的txt重复提取;results/移除2份运行日志(旧五指标日志+最新日志),仅保留权威db与敏感性CSV |
|
