## 2.5 Resilience Assessment Metrics

To quantitatively evaluate the efficacy of the proposed Early Warning Management (EWM) system under extreme cyber-physical disruptions, we define a dual-dimension resilience assessment framework consisting of exactly two complementary metrics: one capturing the **temporal** dimension of service continuity and one capturing the **service-value** dimension of delivered water. Following the principles of exogenous thresholding (Hashimoto et al., 1982) and functional integration (Cimellaro et al., 2010), the framework is deliberately kept minimal so that each metric remains independently interpretable and directly reproducible from the simulation database.

### 2.5.1 Effective Service Duration ($T_{press}$)

This metric quantifies the duration during which the network maintains an acceptable level of hydraulic service. We define the "satisfactory state" as the period where the average nodal pressure $\bar{P}(t)$ remains above the emergency service threshold $P_{min} = 0.10$ MPa (approximately 10.2 m), as specified in the GB 50013-2018 technical standard for urban water supply.

$$T_{press} = \int_{t_d}^{t_r} I(\bar{P}(t) \geq P_{min})\, dt$$

where $I(\cdot)$ is the indicator function, $t_d$ is the fault initiation time, and $t_r$ is the restoration time. $T_{press}$ directly measures how long emergency-grade supply is physically sustained, and is robust to the alignment between the fault onset and the diurnal demand blocks.

### 2.5.2 Standardized Service Resilience ($R_w$)

A duration-only index cannot distinguish between water delivered during critical high-demand periods and water consumed during low-value night hours. We therefore define a standardized service resilience metric, $R_w$, as the ratio of the time-weighted delivered service $W$ to the value ceiling of the available storage:

$$R_w = \frac{W}{S^* \cdot \alpha_{max}} = \frac{\displaystyle\int_{t_d}^{t_r}\sum_j w_j \cdot q_{del,j}(t)\cdot\alpha(t)\,dt}{S^*\cdot\alpha_{max}}$$

The numerator $W$ is the **time-weighted delivered service**: each cubic meter of actually delivered water is scored by the demand-pattern value weight $\alpha(t)$ of the timing of its delivery (normalized Anytown factors, $\alpha \in [0.60, 1.30]$, daily mean = 1.0). Because the weights are normalized to unit daily mean, $W$ equals the equivalent volume that would deliver the same service value if supplied entirely during average-value periods; it is a service-value quantity, not a physical volume (the physical volume is reported separately in the volumetric accounting). The node weights $w_j$ are set to unity for all junctions in this study; they constitute a **designed extension point** for priority-graded dispatch, whereby critical users (e.g., hospitals, firefighting) could be assigned $w_j > 1$ without any structural change to the metric or the framework.

The denominator is the **storage value ceiling**: $S^*$ denotes the usable tank storage at fault onset (water volume above the 0.05 m minimum level; 1,156 m³ in the baseline scenario, captured from the SCADA level record at runtime), and $\alpha_{max} = 1.30$ is the highest demand-block weight. This ceiling corresponds to the limiting case in which the entire storage is delivered during the most valuable demand block, and it guarantees $R_w \in [0, 1]$ through the one-line bound $W \le V_{del}\cdot\alpha_{max} \le S^*\cdot\alpha_{max}$. Unlike an unconstrained ideal-demand reference, the anchor is physical, scenario-adaptive (re-computed from the captured storage for every fault-onset phase, tank scale, and demand load), and cannot be inflated by demand suppression: curtailing demand only removes volume from the numerator, so "preserving pressure without delivering water" cannot raise $R_w$.

Two reporting rules apply. First, $R_w$ is reported for the canonical alignment (fault onset at 24 h) and interpreted as the fraction of the storage's value potential actually captured; cross-scenario comparisons are made only through the within-scenario EWM-versus-baseline change. Second, to eliminate alignment artifacts between the fault onset and the 3-hour demand blocks, the sensitivity analysis (Section 3.3), conducted for $T_{press}$, is reported both as single-run curves at the canonical alignment and as phase-averaged means over four fault-onset offsets (0, 6, 12, 18 h) with per-phase ranges disclosed.
